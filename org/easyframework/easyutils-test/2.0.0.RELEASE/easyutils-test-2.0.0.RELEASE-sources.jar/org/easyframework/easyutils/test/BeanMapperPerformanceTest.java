package org.easyframework.easyutils.test;

import org.easyframework.easyutils.BeanMapper;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.*;

/**
 * BeanMapper 全面性能测试
 * <p>
 * 覆盖 10+ 场景：对象映射、Map 互转、集合映射、基本类型、日期、枚举、
 * copyProperties、深克隆、数组转对象等，输出 TPS、平均延迟与堆内存变化。
 */
public class BeanMapperPerformanceTest {

    // ==================== 测试 POJO ====================

    public static class Src {
        private Long id;
        private String name;
        private Integer age;
        private BigDecimal salary;
        private BigInteger bigValue;
        private Date createTime;
        private LocalDate birthday;
        private LocalTime workStartTime;
        private LocalDateTime updateTime;
        private YearMonth period;
        private Boolean active;
        private Double score;
        private Status status;
        private SrcNested nested;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public Integer getAge() { return age; }
        public void setAge(Integer age) { this.age = age; }
        public BigDecimal getSalary() { return salary; }
        public void setSalary(BigDecimal salary) { this.salary = salary; }
        public BigInteger getBigValue() { return bigValue; }
        public void setBigValue(BigInteger bigValue) { this.bigValue = bigValue; }
        public Date getCreateTime() { return createTime; }
        public void setCreateTime(Date createTime) { this.createTime = createTime; }
        public LocalDate getBirthday() { return birthday; }
        public void setBirthday(LocalDate birthday) { this.birthday = birthday; }
        public LocalTime getWorkStartTime() { return workStartTime; }
        public void setWorkStartTime(LocalTime workStartTime) { this.workStartTime = workStartTime; }
        public LocalDateTime getUpdateTime() { return updateTime; }
        public void setUpdateTime(LocalDateTime updateTime) { this.updateTime = updateTime; }
        public YearMonth getPeriod() { return period; }
        public void setPeriod(YearMonth period) { this.period = period; }
        public Boolean getActive() { return active; }
        public void setActive(Boolean active) { this.active = active; }
        public Double getScore() { return score; }
        public void setScore(Double score) { this.score = score; }
        public Status getStatus() { return status; }
        public void setStatus(Status status) { this.status = status; }
        public SrcNested getNested() { return nested; }
        public void setNested(SrcNested nested) { this.nested = nested; }
    }

    public static class Dest {
        private Long id;
        private String name;
        private Integer age;
        private BigDecimal salary;
        private BigInteger bigValue;
        private Date createTime;
        private LocalDate birthday;
        private LocalTime workStartTime;
        private LocalDateTime updateTime;
        private YearMonth period;
        private Boolean active;
        private Double score;
        private Status status;
        private SrcNested nested;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public Integer getAge() { return age; }
        public void setAge(Integer age) { this.age = age; }
        public BigDecimal getSalary() { return salary; }
        public void setSalary(BigDecimal salary) { this.salary = salary; }
        public BigInteger getBigValue() { return bigValue; }
        public void setBigValue(BigInteger bigValue) { this.bigValue = bigValue; }
        public Date getCreateTime() { return createTime; }
        public void setCreateTime(Date createTime) { this.createTime = createTime; }
        public LocalDate getBirthday() { return birthday; }
        public void setBirthday(LocalDate birthday) { this.birthday = birthday; }
        public LocalTime getWorkStartTime() { return workStartTime; }
        public void setWorkStartTime(LocalTime workStartTime) { this.workStartTime = workStartTime; }
        public LocalDateTime getUpdateTime() { return updateTime; }
        public void setUpdateTime(LocalDateTime updateTime) { this.updateTime = updateTime; }
        public YearMonth getPeriod() { return period; }
        public void setPeriod(YearMonth period) { this.period = period; }
        public Boolean getActive() { return active; }
        public void setActive(Boolean active) { this.active = active; }
        public Double getScore() { return score; }
        public void setScore(Double score) { this.score = score; }
        public Status getStatus() { return status; }
        public void setStatus(Status status) { this.status = status; }
        public SrcNested getNested() { return nested; }
        public void setNested(SrcNested nested) { this.nested = nested; }
    }

    public static class SrcNested {
        private Long nestedId;
        private String nestedName;
        private BigDecimal price;

        public Long getNestedId() { return nestedId; }
        public void setNestedId(Long nestedId) { this.nestedId = nestedId; }
        public String getNestedName() { return nestedName; }
        public void setNestedName(String nestedName) { this.nestedName = nestedName; }
        public BigDecimal getPrice() { return price; }
        public void setPrice(BigDecimal price) { this.price = price; }
    }

    public enum Status {
        ACTIVE, INACTIVE, PENDING
    }

    /** 简易 POJO — 仅含基本类型，用于深克隆测试（避免 BigDecimal/BigInteger 无无参构造问题） */
    public static class SimplePOJO {
        private Long id;
        private String name;
        private Integer age;
        private Boolean active;
        private Double score;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public Integer getAge() { return age; }
        public void setAge(Integer age) { this.age = age; }
        public Boolean getActive() { return active; }
        public void setActive(Boolean active) { this.active = active; }
        public Double getScore() { return score; }
        public void setScore(Double score) { this.score = score; }
    }

    // ==================== 辅助方法 ====================

    private static Src buildSrc() {
        SrcNested nested = new SrcNested();
        nested.setNestedId(999L);
        nested.setNestedName("nested-item");
        nested.setPrice(new BigDecimal("99.99"));

        Src src = new Src();
        src.setId(1L);
        src.setName("张三");
        src.setAge(28);
        src.setSalary(new BigDecimal("15000.50"));
        src.setBigValue(BigInteger.valueOf(9999999999L));
        src.setCreateTime(new Date());
        src.setBirthday(LocalDate.of(1995, 6, 15));
        src.setWorkStartTime(LocalTime.of(9, 0, 0));
        src.setUpdateTime(LocalDateTime.now());
        src.setPeriod(YearMonth.of(2024, 1));
        src.setActive(true);
        src.setScore(95.5);
        src.setStatus(Status.ACTIVE);
        src.setNested(nested);
        return src;
    }

    /** 手动 get/set — 性能天花板 */
    private static Dest manualMap(Src src) {
        Dest t = new Dest();
        t.setId(src.getId());
        t.setName(src.getName());
        t.setAge(src.getAge());
        t.setSalary(src.getSalary());
        t.setBigValue(src.getBigValue());
        t.setCreateTime(src.getCreateTime());
        t.setBirthday(src.getBirthday());
        t.setWorkStartTime(src.getWorkStartTime());
        t.setUpdateTime(src.getUpdateTime());
        t.setPeriod(src.getPeriod());
        t.setActive(src.getActive());
        t.setScore(src.getScore());
        t.setStatus(src.getStatus());
        t.setNested(src.getNested());
        return t;
    }

    /** 预热 JIT */
    private static void warmup(Runnable task, int count) {
        for (int i = 0; i < count; i++) task.run();
    }

    /** 度量一次场景 */
    private static BenchmarkResult measure(String name, Runnable task, int iterations, int warmupCount) {
        // 预热
        warmup(task, warmupCount);
        System.gc();
        try { Thread.sleep(200); } catch (InterruptedException ignored) {}

        long memBefore = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();

        long start = System.nanoTime();
        for (int i = 0; i < iterations; i++) {
            task.run();
        }
        long elapsedNs = System.nanoTime() - start;

        long memAfter = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        long memDelta = memAfter - memBefore;

        double elapsedMs = elapsedNs / 1_000_000.0;
        double tps = iterations / (elapsedNs / 1_000_000_000.0);
        double avgLatencyNs = elapsedNs / (double) iterations;
        double avgLatencyUs = avgLatencyNs / 1000.0;

        return new BenchmarkResult(name, iterations, elapsedMs, tps, avgLatencyNs, avgLatencyUs, memDelta);
    }

    // ==================== BenchmarkResult ====================

    static class BenchmarkResult {
        final String name;
        final int iterations;
        final double elapsedMs;
        final double tps;
        final double avgLatencyNs;
        final double avgLatencyUs;
        final long memDelta;

        BenchmarkResult(String name, int iterations, double elapsedMs, double tps,
                        double avgLatencyNs, double avgLatencyUs, long memDelta) {
            this.name = name;
            this.iterations = iterations;
            this.elapsedMs = elapsedMs;
            this.tps = tps;
            this.avgLatencyNs = avgLatencyNs;
            this.avgLatencyUs = avgLatencyUs;
            this.memDelta = memDelta;
        }
    }

    // ==================== 主测试入口 ====================

    public static void main(String[] args) {
        List<BenchmarkResult> results = new ArrayList<>();

        int ITER_SMALL  = 100_000;    // 轻量场景
        int ITER_MEDIUM = 500_000;    // 中等场景
        int ITER_LARGE  = 1_000_000;  // 重量场景
        int WARMUP      = 10_000;

        Src src = buildSrc();

        // ────────────────────────────────────────────
        // 场景 1: 手动 get/set (性能天花板)
        // ────────────────────────────────────────────
        results.add(measure("1. 手动 get/set (基线)", () -> { Dest d = manualMap(src); }, ITER_LARGE, WARMUP));

        // ────────────────────────────────────────────
        // 场景 2: BeanMapper.map() Object → Object
        // ────────────────────────────────────────────
        results.add(measure("2. map Object→Object (14 字段)", () -> { Dest d = BeanMapper.map(src, Dest.class); }, ITER_MEDIUM, WARMUP));

        // ────────────────────────────────────────────
        // 场景 3: BeanMapper.map() Map → Object
        // ────────────────────────────────────────────
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("id", 1L);
        dataMap.put("name", "李四");
        dataMap.put("age", 30);
        dataMap.put("salary", new BigDecimal("20000.00"));
        dataMap.put("active", true);
        dataMap.put("score", 88.8);
        results.add(measure("3. map Map→Object", () -> { Dest d = BeanMapper.map(dataMap, Dest.class); }, ITER_SMALL, WARMUP));

        // ────────────────────────────────────────────
        // 场景 4: BeanMapper.map() Object → Map
        // ────────────────────────────────────────────
        results.add(measure("4. map Object→Map", () -> { Map m = BeanMapper.map(src, Map.class); }, ITER_SMALL, WARMUP));

        // ────────────────────────────────────────────
        // 场景 5: 集合映射 List<Src> → List<Dest>
        // ────────────────────────────────────────────
        List<Src> srcList = new ArrayList<>();
        for (int i = 0; i < 10; i++) srcList.add(buildSrc());
        results.add(measure("5. 集合映射 (10 元素)", () -> { List<Dest> list = BeanMapper.map(srcList, Dest.class); }, ITER_SMALL / 10, WARMUP / 10));

        // ────────────────────────────────────────────
        // 场景 6: 基本类型转换 String → Integer/Long/Double
        // ────────────────────────────────────────────
        results.add(measure("6. String→Integer", () -> { Integer v = BeanMapper.map("12345", Integer.class); }, ITER_SMALL, WARMUP));
        results.add(measure("   String→Long", () -> { Long v = BeanMapper.map("9876543210", Long.class); }, ITER_SMALL, WARMUP));
        results.add(measure("   String→Double", () -> { Double v = BeanMapper.map("3.1415926", Double.class); }, ITER_SMALL, WARMUP));

        // ────────────────────────────────────────────
        // 场景 7: 日期字符串 → 日期类型
        // ────────────────────────────────────────────
        results.add(measure("7. String→Date", () -> { Date d = BeanMapper.map("2024-01-15 10:30:00", Date.class); }, ITER_SMALL, WARMUP));
        results.add(measure("   String→LocalDate", () -> { LocalDate d = BeanMapper.map("2024-01-15", LocalDate.class); }, ITER_SMALL, WARMUP));
        results.add(measure("   String→LocalDateTime", () -> { LocalDateTime d = BeanMapper.map("2024-01-15 10:30:00", LocalDateTime.class); }, ITER_SMALL, WARMUP));

        // ────────────────────────────────────────────
        // 场景 8: 枚举转换
        // ────────────────────────────────────────────
        results.add(measure("8. String→Enum", () -> { Status s = BeanMapper.map("ACTIVE", Status.class); }, ITER_SMALL, WARMUP));

        // ────────────────────────────────────────────
        // 场景 9: copyProperties
        // ────────────────────────────────────────────
        Dest destForCopy = new Dest();
        results.add(measure("9. copyAll (全量覆盖)", () -> { BeanMapper.copyAll(src, destForCopy); }, ITER_SMALL, WARMUP));
        Dest destForNonNull = new Dest();
        results.add(measure("   copyNonNull (非空覆盖)", () -> { BeanMapper.copyNonNull(src, destForNonNull); }, ITER_SMALL, WARMUP));
        Dest destForFill = new Dest();
        results.add(measure("   fillNulls (填补空缺)", () -> { BeanMapper.fillNulls(src, destForFill); }, ITER_SMALL, WARMUP));

        // ────────────────────────────────────────────
        // 场景 10: 深克隆 (同类型 SimplePOJO)
        // ────────────────────────────────────────────
        SimplePOJO simpleSrc = new SimplePOJO();
        simpleSrc.setId(100L);
        simpleSrc.setName("test");
        simpleSrc.setAge(20);
        simpleSrc.setActive(true);
        simpleSrc.setScore(99.9);
        results.add(measure("10. 深克隆 (同类型 SimplePOJO)", () -> { SimplePOJO s = BeanMapper.map(simpleSrc, SimplePOJO.class); }, ITER_SMALL, WARMUP));

        // ────────────────────────────────────────────
        // 场景 11: 数组转对象
        // ────────────────────────────────────────────
        Object[] arr = new Object[]{"id", 1L, "name", "王五", "age", 25, "active", true};
        results.add(measure("11. 数组→Object", () -> { Dest d = BeanMapper.map(arr, Dest.class); }, ITER_SMALL, WARMUP));

        // ────────────────────────────────────────────
        // 输出报告
        // ────────────────────────────────────────────
        printReport(results);

        // 环境信息
        System.out.println();
        System.out.printf("JVM: %s | Java: %s | 核心: %d | 最大堆: %.0f MB%n",
                System.getProperty("java.vm.name"),
                System.getProperty("java.version"),
                Runtime.getRuntime().availableProcessors(),
                Runtime.getRuntime().maxMemory() / 1024.0 / 1024.0);
    }

    private static void printReport(List<BenchmarkResult> results) {
        String sep = "═════════════════════════════════════════════════════════════════════════════════════════════════";
        System.out.println();
        System.out.println("╔" + sep + "╗");
        System.out.println("║  BeanMapper 性能测试报告" + padRight("", sep.length() - 23) + "║");
        System.out.println("╠" + sep + "╣");
        System.out.printf("║  %-55s │ %8s │ %15s │ %12s │ %12s ║%n", "场景", "耗时(ms)", "TPS(次/秒)", "平均延迟(ns)", "内存变化(KB)");
        System.out.println("╠" + sep + "╣");

        for (BenchmarkResult r : results) {
            System.out.printf("║  %-55s │ %8.1f │ %,15.0f │ %12.0f │ %12s ║%n",
                    r.name, r.elapsedMs, r.tps, r.avgLatencyNs,
                    r.memDelta == 0 ? "—" : formatKB(r.memDelta));
        }
        System.out.println("╚" + sep + "╝");

        // 对比总结
        BenchmarkResult manual = results.get(0);
        BenchmarkResult mapper = results.get(1);
        double ratio = mapper.avgLatencyNs / manual.avgLatencyNs;

        System.out.println();
        System.out.println("┌──────────────────────────────────────────────────┐");
        System.out.printf("│  BeanMapper / 手动 :  %.1fx  %-20s │%n", ratio,
                ratio < 3 ? "✅ 性能优秀" : ratio < 10 ? "⚠️ 有差距但可接受" : "🔻 差距较大");
        System.out.printf("│  手动 TPS : %,15.0f 次/秒           │%n", manual.tps);
        System.out.printf("│  映射 TPS : %,15.0f 次/秒           │%n", mapper.tps);
        System.out.println("└──────────────────────────────────────────────────┘");
    }

    private static String formatKB(long bytes) {
        if (bytes < 0) return "-" + formatKB(-bytes);
        if (bytes < 1024) return bytes + " B";
        return String.format("%.1f KB", bytes / 1024.0);
    }

    private static String padRight(String s, int len) {
        StringBuilder sb = new StringBuilder(s);
        while (sb.length() < len) sb.append(' ');
        return sb.toString();
    }
}
