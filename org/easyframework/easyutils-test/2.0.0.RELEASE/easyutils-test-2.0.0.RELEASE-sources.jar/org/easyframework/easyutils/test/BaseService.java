package org.easyframework.easyutils.test;

 interface BaseService<D, T> extends TestService<D, T> {
}
