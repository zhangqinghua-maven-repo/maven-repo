package org.easyframework.easyutils.test;

import javax.annotation.processing.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-12T18:13:57+0800",
    comments = "version: 1.6.3, compiler: javac, environment: Java 25 (Oracle Corporation)"
)
public class MapStructDirectMapperImpl implements MapStructDirectMapper {

    @Override
    public BeanMapperTypePerformanceBenchmark.DirectTarget map(BeanMapperTypePerformanceBenchmark.DirectSource source) {
        if ( source == null ) {
            return null;
        }

        BeanMapperTypePerformanceBenchmark.DirectTarget directTarget = new BeanMapperTypePerformanceBenchmark.DirectTarget();

        directTarget.setPrimitiveBoolean( source.isPrimitiveBoolean() );
        directTarget.setPrimitiveByte( source.getPrimitiveByte() );
        directTarget.setPrimitiveShort( source.getPrimitiveShort() );
        directTarget.setPrimitiveInt( source.getPrimitiveInt() );
        directTarget.setPrimitiveLong( source.getPrimitiveLong() );
        directTarget.setPrimitiveFloat( source.getPrimitiveFloat() );
        directTarget.setPrimitiveDouble( source.getPrimitiveDouble() );
        directTarget.setPrimitiveChar( source.getPrimitiveChar() );
        directTarget.setWrapperBoolean( source.getWrapperBoolean() );
        directTarget.setWrapperByte( source.getWrapperByte() );
        directTarget.setWrapperShort( source.getWrapperShort() );
        directTarget.setWrapperInt( source.getWrapperInt() );
        directTarget.setWrapperLong( source.getWrapperLong() );
        directTarget.setWrapperFloat( source.getWrapperFloat() );
        directTarget.setWrapperDouble( source.getWrapperDouble() );
        directTarget.setWrapperChar( source.getWrapperChar() );
        directTarget.setText( source.getText() );
        directTarget.setBigInteger( source.getBigInteger() );
        directTarget.setBigDecimal( source.getBigDecimal() );
        directTarget.setStatus( source.getStatus() );
        directTarget.setDate( source.getDate() );
        directTarget.setLocalDate( source.getLocalDate() );
        directTarget.setLocalTime( source.getLocalTime() );
        directTarget.setLocalDateTime( source.getLocalDateTime() );
        directTarget.setYear( source.getYear() );
        directTarget.setMonth( source.getMonth() );
        directTarget.setYearMonth( source.getYearMonth() );

        return directTarget;
    }
}
