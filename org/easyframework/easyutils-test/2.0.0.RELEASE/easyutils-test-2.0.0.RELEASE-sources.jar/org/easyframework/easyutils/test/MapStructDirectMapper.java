package org.easyframework.easyutils.test;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface MapStructDirectMapper {
    MapStructDirectMapper INSTANCE = Mappers.getMapper(MapStructDirectMapper.class);

    BeanMapperTypePerformanceBenchmark.DirectTarget map(BeanMapperTypePerformanceBenchmark.DirectSource source);
}
