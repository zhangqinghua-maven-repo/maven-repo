package org.easyframework.easyutils.test;

import org.easyframework.easyutils.BeanMapper;

/**
 * 手动 get/set vs BeanMapperOpt 性能对比
 */
public class ManualVsMapperTest {

    public static class Src {
        private Long id;
        private String name;
        private Integer age;
        private java.math.BigDecimal salary;
        private java.math.BigInteger bigValue;
        private java.util.Date createTime;
        private java.time.LocalDate birthday;
        private java.time.LocalTime workStartTime;
        private java.time.LocalDateTime updateTime;
        private java.time.YearMonth period;
        private Boolean active;
        private Double score;
        private SrcNested nested;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public Integer getAge() { return age; }
        public void setAge(Integer age) { this.age = age; }
        public java.math.BigDecimal getSalary() { return salary; }
        public void setSalary(java.math.BigDecimal salary) { this.salary = salary; }
        public java.math.BigInteger getBigValue() { return bigValue; }
        public void setBigValue(java.math.BigInteger bigValue) { this.bigValue = bigValue; }
        public java.util.Date getCreateTime() { return createTime; }
        public void setCreateTime(java.util.Date createTime) { this.createTime = createTime; }
        public java.time.LocalDate getBirthday() { return birthday; }
        public void setBirthday(java.time.LocalDate birthday) { this.birthday = birthday; }
        public java.time.LocalTime getWorkStartTime() { return workStartTime; }
        public void setWorkStartTime(java.time.LocalTime workStartTime) { this.workStartTime = workStartTime; }
        public java.time.LocalDateTime getUpdateTime() { return updateTime; }
        public void setUpdateTime(java.time.LocalDateTime updateTime) { this.updateTime = updateTime; }
        public java.time.YearMonth getPeriod() { return period; }
        public void setPeriod(java.time.YearMonth period) { this.period = period; }
        public Boolean getActive() { return active; }
        public void setActive(Boolean active) { this.active = active; }
        public Double getScore() { return score; }
        public void setScore(Double score) { this.score = score; }
        public SrcNested getNested() { return nested; }
        public void setNested(SrcNested nested) { this.nested = nested; }
    }

    public static class Dest {
        private Long id;
        private String name;
        private Integer age;
        private java.math.BigDecimal salary;
        private java.math.BigInteger bigValue;
        private java.util.Date createTime;
        private java.time.LocalDate birthday;
        private java.time.LocalTime workStartTime;
        private java.time.LocalDateTime updateTime;
        private java.time.YearMonth period;
        private Boolean active;
        private Double score;
        private SrcNested nested;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public Integer getAge() { return age; }
        public void setAge(Integer age) { this.age = age; }
        public java.math.BigDecimal getSalary() { return salary; }
        public void setSalary(java.math.BigDecimal salary) { this.salary = salary; }
        public java.math.BigInteger getBigValue() { return bigValue; }
        public void setBigValue(java.math.BigInteger bigValue) { this.bigValue = bigValue; }
        public java.util.Date getCreateTime() { return createTime; }
        public void setCreateTime(java.util.Date createTime) { this.createTime = createTime; }
        public java.time.LocalDate getBirthday() { return birthday; }
        public void setBirthday(java.time.LocalDate birthday) { this.birthday = birthday; }
        public java.time.LocalTime getWorkStartTime() { return workStartTime; }
        public void setWorkStartTime(java.time.LocalTime workStartTime) { this.workStartTime = workStartTime; }
        public java.time.LocalDateTime getUpdateTime() { return updateTime; }
        public void setUpdateTime(java.time.LocalDateTime updateTime) { this.updateTime = updateTime; }
        public java.time.YearMonth getPeriod() { return period; }
        public void setPeriod(java.time.YearMonth period) { this.period = period; }
        public Boolean getActive() { return active; }
        public void setActive(Boolean active) { this.active = active; }
        public Double getScore() { return score; }
        public void setScore(Double score) { this.score = score; }
        public SrcNested getNested() { return nested; }
        public void setNested(SrcNested nested) { this.nested = nested; }
    }

    public static class SrcNested {
        private Long nestedId;
        private String nestedName;
        private java.math.BigDecimal price;
        public Long getNestedId() { return nestedId; }
        public void setNestedId(Long nestedId) { this.nestedId = nestedId; }
        public String getNestedName() { return nestedName; }
        public void setNestedName(String nestedName) { this.nestedName = nestedName; }
        public java.math.BigDecimal getPrice() { return price; }
        public void setPrice(java.math.BigDecimal price) { this.price = price; }
    }

    private static Src buildSrc() {
        SrcNested nested = new SrcNested();
        nested.setNestedId(999L);
        nested.setNestedName("nested-item");
        nested.setPrice(new java.math.BigDecimal("99.99"));

        Src src = new Src();
        src.setId(1L);
        src.setName("张三");
        src.setAge(28);
        src.setSalary(new java.math.BigDecimal("15000.50"));
        src.setBigValue(java.math.BigInteger.valueOf(9999999999L));
        src.setCreateTime(new java.util.Date());
        src.setBirthday(java.time.LocalDate.of(1995, 6, 15));
        src.setWorkStartTime(java.time.LocalTime.of(9, 0, 0));
        src.setUpdateTime(java.time.LocalDateTime.now());
        src.setPeriod(java.time.YearMonth.of(2024, 1));
        src.setActive(true);
        src.setScore(95.5);
        src.setNested(nested);
        return src;
    }

    /** 手动 get/set：纯 Java 代码，无反射 */
    private static Dest manualMap(Src src) {
        Dest t = new Dest();
        t.setId(src.getId());
        t.setName(src.getName());
        t.setAge(src.getAge());
        t.setSalary(src.getSalary());
        t.setBigValue(src.getBigValue());
        t.setCreateTime(src.getCreateTime());
        t.setBirthday(src.getBirthday());
        t.setWorkStartTime(src.getWorkStartTime());
        t.setUpdateTime(src.getUpdateTime());
        t.setPeriod(src.getPeriod());
        t.setActive(src.getActive());
        t.setScore(src.getScore());
        t.setNested(src.getNested()); // 同类型，直接赋值
        return t;
    }

    /** 预热 */
    private static void warmup(Runnable task, int count) {
        for (int i = 0; i < count; i++) task.run();
    }

    public static void main(String[] args) {
        int ITER = 1_000_000;
        int WARMUP = 10_000;
        Src src = buildSrc();

        // === 手动 get/set ===
        warmup(() -> { Dest d = manualMap(src); }, WARMUP);
        System.gc();
        long startManual = System.nanoTime();
        for (int i = 0; i < ITER; i++) {
            Dest d = manualMap(src);
        }
        long manualNs = System.nanoTime() - startManual;
        double manualMs = manualNs / 1_000_000.0;
        double manualTps = ITER / (manualNs / 1_000_000_000.0);

        // === BeanMapperOpt ===
        warmup(() -> { Dest d = BeanMapper.map(src, Dest.class); }, WARMUP);
        System.gc();
        long startOpt = System.nanoTime();
        for (int i = 0; i < ITER; i++) {
            Dest d = BeanMapper.map(src, Dest.class);
        }
        long optNs = System.nanoTime() - startOpt;
        double optMs = optNs / 1_000_000.0;
        double optTps = ITER / (optNs / 1_000_000_000.0);

        // === 输出 ===
        System.out.println("╔══════════════════════════════════════════════════════════════════╗");
        System.out.println("║        手动 get/set vs BeanMapperOpt 性能对比 (100万次)         ║");
        System.out.println("╠══════════════════════════════════════════════════════════════════╣");
        System.out.printf("  手动 get/set:     %8.1f ms  |  TPS: %,12.0f%n", manualMs, manualTps);
        System.out.printf("  BeanMapperOpt:    %8.1f ms  |  TPS: %,12.0f%n", optMs, optTps);
        System.out.println("╠══════════════════════════════════════════════════════════════════╣");
        double ratio = optNs / (double) manualNs;
        System.out.printf("  BeanMapperOpt / 手动:  %.1fx  (%s)%n", ratio, ratio < 2 ? "✅ 接近手写性能" : ratio < 5 ? "⚠️ 有差距但可接受" : "🔻 差距较大");
        System.out.println("╚══════════════════════════════════════════════════════════════════╝");

        // 1000万推算
        double manual10M = manualMs / 100 * 10; // 100万→1000万
        double opt10M = optMs / 100 * 10;
        System.out.printf("%n📊 1000万对象推算：手动 %.1f秒 vs BeanMapperOpt %.1f秒%n", manual10M / 1000, opt10M / 1000);

        // 环境信息
        System.out.printf("%nJVM: %s | Java: %s | 核心: %d%n",
                System.getProperty("java.vm.name"),
                System.getProperty("java.version"),
                Runtime.getRuntime().availableProcessors());
    }
}
