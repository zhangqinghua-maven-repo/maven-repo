package org.easyframework.easyutils.test;

 class OrderServiceImpl implements OrderService<Member, Product, Order> {

}
