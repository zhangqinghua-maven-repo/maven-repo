package org.easyframework.easyutils.test;

 class Member {
}
