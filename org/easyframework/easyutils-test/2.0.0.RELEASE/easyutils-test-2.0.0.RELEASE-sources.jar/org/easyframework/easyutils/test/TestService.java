package org.easyframework.easyutils.test;

 interface TestService<S, L> {
}
