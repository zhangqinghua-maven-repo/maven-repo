package org.easyframework.easyutils.test;

import org.easyframework.easyutils.BeanMapper;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Year;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Per-category performance matrix. Results are diagnostic and must be compared
 * on the same JVM and machine; every result is consumed through a volatile sink.
 */
public final class BeanMapperTypePerformanceBenchmark {
    private static final int WARMUP = 50_000;
    private static final long DEFAULT_SCENARIO_SECONDS = 30;
    private static volatile Object sink;
    private static long scenarioNanos;

    private BeanMapperTypePerformanceBenchmark() { }

    public static void main(String[] args) {
        long seconds = parseScenarioSeconds(args);
        scenarioNanos = seconds * 1_000_000_000L;
        DirectSource direct = directSource();
        ConversionSource conversion = conversionSource();
        ComplexSource complex = complexSource();
        Map<String, Object> map = conversionMap();
        Object[] keyValues = {"id", "9", "enabled", "true", "amount", "99.50", "date", "2024-01-15"};

        System.out.printf("BeanMapper type performance matrix (%d seconds per scenario, lower ratio is better)%n", seconds);
        System.out.printf("%-42s %12s %12s %10s%n", "category", "manual ns/op", "mapper ns/op", "ratio");
        measure("scalar String -> boolean", () -> Boolean.valueOf("true"), () -> BeanMapper.map("true", Boolean.class));
        measure("scalar String -> byte", () -> Byte.valueOf("1"), () -> BeanMapper.map("1", Byte.class));
        measure("scalar String -> short", () -> Short.valueOf("2"), () -> BeanMapper.map("2", Short.class));
        measure("scalar String -> integer", () -> Integer.valueOf("3"), () -> BeanMapper.map("3", Integer.class));
        measure("scalar String -> long", () -> Long.valueOf("4"), () -> BeanMapper.map("4", Long.class));
        measure("scalar String -> float", () -> Float.valueOf("5.5"), () -> BeanMapper.map("5.5", Float.class));
        measure("scalar String -> double", () -> Double.valueOf("6.5"), () -> BeanMapper.map("6.5", Double.class));
        measure("scalar String -> character", () -> "x".charAt(0), () -> BeanMapper.map("x", Character.class));
        measure("scalar String -> BigInteger", () -> new BigInteger("12345678901234567890"), () -> BeanMapper.map("12345678901234567890", BigInteger.class));
        measure("scalar String -> BigDecimal", () -> new BigDecimal("12345.6789"), () -> BeanMapper.map("12345.6789", BigDecimal.class));
        measure("scalar String -> enum", () -> Status.valueOf("ACTIVE"), () -> BeanMapper.map("ACTIVE", Status.class));
        measure("scalar String -> LocalDate", () -> LocalDate.parse("2024-01-15"), () -> BeanMapper.map("2024-01-15", LocalDate.class));
        measure("scalar String -> LocalTime", () -> LocalTime.parse("09:30:15"), () -> BeanMapper.map("09:30:15", LocalTime.class));
        measure("scalar String -> LocalDateTime", () -> LocalDateTime.parse("2024-01-15 09:30:15", java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")), () -> BeanMapper.map("2024-01-15 09:30:15", LocalDateTime.class));
        measure("scalar String -> YearMonth", () -> YearMonth.parse("2024-01"), () -> BeanMapper.map("2024-01", YearMonth.class));
        measureDirectDto("direct matrix: scalar/date-time/enum", () -> manualDirect(direct),
                () -> MapStructDirectMapper.INSTANCE.map(direct), () -> BeanMapper.map(direct, DirectTarget.class));
        measure("conversion matrix: scalar/date-time/enum", () -> manualConversion(conversion), () -> BeanMapper.map(conversion, ConversionTarget.class));
        measure("nested bean + List element mapping", () -> manualComplex(complex), () -> BeanMapper.map(complex, ComplexTarget.class));
        measure("Map -> typed Bean", () -> manualMap(map), () -> BeanMapper.map(map, ConversionTarget.class));
        measure("key-value array -> typed Bean", () -> manualArray(keyValues), () -> BeanMapper.map(keyValues, ConversionTarget.class));
        measure("Bean -> Map", () -> manualBeanToMap(direct), () -> BeanMapper.map(direct, Map.class));
    }

    private static void measure(String category, Task manual, Task mapper) {
        warmup(manual);
        warmup(mapper);
        double manualNs = run(manual, scenarioNanos / 2);
        double mapperNs = run(mapper, scenarioNanos / 2);
        System.out.printf("%-42s %12.1f %12.1f %9.2fx%n", category, manualNs, mapperNs, mapperNs / manualNs);
    }

    private static void measureDirectDto(String category, Task manual, Task mapStruct, Task beanMapper) {
        warmup(manual);
        warmup(mapStruct);
        warmup(beanMapper);
        double manualNs = run(manual, scenarioNanos / 3);
        double mapStructNs = run(mapStruct, scenarioNanos / 3);
        double beanMapperNs = run(beanMapper, scenarioNanos / 3);
        System.out.printf("%-42s manual=%8.1f MapStruct=%8.1f BeanMapper=%8.1f ns/op  MS=%4.2fx BM=%4.2fx%n",
                category, manualNs, mapStructNs, beanMapperNs, mapStructNs / manualNs, beanMapperNs / manualNs);
    }

    private static void warmup(Task task) {
        for (int index = 0; index < WARMUP; index++) sink = task.run();
    }

    private static double run(Task task, long durationNanos) {
        long start = System.nanoTime();
        long deadline = start + durationNanos;
        long count = 0;
        while (System.nanoTime() < deadline) {
            sink = task.run();
            count++;
        }
        return (System.nanoTime() - start) / (double) count;
    }

    private static long parseScenarioSeconds(String[] args) {
        if (args.length == 0) return DEFAULT_SCENARIO_SECONDS;
        String prefix = "--seconds=";
        if (!args[0].startsWith(prefix)) {
            throw new IllegalArgumentException("Usage: --seconds=<positive integer>");
        }
        long seconds = Long.parseLong(args[0].substring(prefix.length()));
        if (seconds <= 0) throw new IllegalArgumentException("seconds must be positive");
        return seconds;
    }

    private static DirectSource directSource() {
        DirectSource value = new DirectSource();
        value.primitiveBoolean = true; value.primitiveByte = 1; value.primitiveShort = 2; value.primitiveInt = 3;
        value.primitiveLong = 4L; value.primitiveFloat = 5.5F; value.primitiveDouble = 6.5D; value.primitiveChar = 'x';
        value.wrapperBoolean = false; value.wrapperByte = 7; value.wrapperShort = 8; value.wrapperInt = 9;
        value.wrapperLong = 10L; value.wrapperFloat = 11.5F; value.wrapperDouble = 12.5D; value.wrapperChar = 'y';
        value.text = "easyutils"; value.bigInteger = new BigInteger("12345678901234567890");
        value.bigDecimal = new BigDecimal("12345.6789"); value.status = Status.ACTIVE; value.date = new Date(1_700_000_000_000L);
        value.localDate = LocalDate.of(2024, 1, 15); value.localTime = LocalTime.of(9, 30, 15);
        value.localDateTime = LocalDateTime.of(2024, 1, 15, 9, 30, 15); value.year = Year.of(2024);
        value.month = Month.JANUARY; value.yearMonth = YearMonth.of(2024, 1);
        return value;
    }

    private static ConversionSource conversionSource() {
        ConversionSource value = new ConversionSource();
        value.enabled = "true"; value.id = "4"; value.byteValue = "1"; value.shortValue = "2"; value.intValue = "3";
        value.floatValue = "5.5"; value.doubleValue = "6.5"; value.charValue = "x"; value.bigInteger = "12345678901234567890";
        value.bigDecimal = "12345.6789"; value.status = "ACTIVE"; value.date = "2024-01-15";
        value.time = "09:30:15"; value.dateTime = "2024-01-15 09:30:15"; value.yearMonth = "2024-01";
        return value;
    }

    private static ComplexSource complexSource() {
        ComplexSource value = new ComplexSource();
        value.nested = new ChildSource("root", 1);
        value.children = Arrays.asList(new ChildSource("a", 2), new ChildSource("b", 3));
        value.attributes = new LinkedHashMap<>(Map.of("role", "admin"));
        value.numbers = new int[]{1, 2, 3};
        return value;
    }

    private static Map<String, Object> conversionMap() {
        Map<String, Object> values = new LinkedHashMap<>();
        values.put("id", "9"); values.put("enabled", "true"); values.put("amount", "99.50"); values.put("date", "2024-01-15");
        return values;
    }

    private static DirectTarget manualDirect(DirectSource source) {
        DirectTarget target = new DirectTarget();
        target.setPrimitiveBoolean(source.isPrimitiveBoolean()); target.setPrimitiveByte(source.getPrimitiveByte()); target.setPrimitiveShort(source.getPrimitiveShort()); target.setPrimitiveInt(source.getPrimitiveInt());
        target.setPrimitiveLong(source.getPrimitiveLong()); target.setPrimitiveFloat(source.getPrimitiveFloat()); target.setPrimitiveDouble(source.getPrimitiveDouble()); target.setPrimitiveChar(source.getPrimitiveChar());
        target.setWrapperBoolean(source.getWrapperBoolean()); target.setWrapperByte(source.getWrapperByte()); target.setWrapperShort(source.getWrapperShort()); target.setWrapperInt(source.getWrapperInt());
        target.setWrapperLong(source.getWrapperLong()); target.setWrapperFloat(source.getWrapperFloat()); target.setWrapperDouble(source.getWrapperDouble()); target.setWrapperChar(source.getWrapperChar());
        target.setText(source.getText()); target.setBigInteger(source.getBigInteger()); target.setBigDecimal(source.getBigDecimal()); target.setStatus(source.getStatus());
        target.setDate(source.getDate()); target.setLocalDate(source.getLocalDate()); target.setLocalTime(source.getLocalTime()); target.setLocalDateTime(source.getLocalDateTime());
        target.setYear(source.getYear()); target.setMonth(source.getMonth()); target.setYearMonth(source.getYearMonth());
        return target;
    }

    private static ConversionTarget manualConversion(ConversionSource source) {
        ConversionTarget target = new ConversionTarget();
        target.id = Long.valueOf(source.id); target.enabled = Boolean.valueOf(source.enabled); target.byteValue = Byte.valueOf(source.byteValue);
        target.shortValue = Short.valueOf(source.shortValue); target.intValue = Integer.valueOf(source.intValue); target.floatValue = Float.valueOf(source.floatValue);
        target.doubleValue = Double.valueOf(source.doubleValue); target.charValue = source.charValue.charAt(0); target.bigInteger = new BigInteger(source.bigInteger);
        target.bigDecimal = new BigDecimal(source.bigDecimal); target.status = Status.valueOf(source.status); target.date = LocalDate.parse(source.date);
        target.time = LocalTime.parse(source.time); target.dateTime = LocalDateTime.parse(source.dateTime, java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        target.yearMonth = YearMonth.parse(source.yearMonth);
        return target;
    }

    private static ComplexTarget manualComplex(ComplexSource source) {
        ComplexTarget target = new ComplexTarget();
        target.nested = manualChild(source.nested);
        target.children = source.children.stream().map(BeanMapperTypePerformanceBenchmark::manualChild).toList();
        target.attributes = source.attributes;
        target.numbers = source.numbers;
        return target;
    }

    private static ChildTarget manualChild(ChildSource source) {
        ChildTarget target = new ChildTarget();
        target.name = source.name; target.rank = source.rank;
        return target;
    }

    private static ConversionTarget manualMap(Map<String, Object> source) {
        ConversionTarget target = new ConversionTarget();
        target.id = Long.valueOf((String) source.get("id")); target.enabled = Boolean.valueOf((String) source.get("enabled"));
        target.bigDecimal = new BigDecimal((String) source.get("amount")); target.date = LocalDate.parse((String) source.get("date"));
        return target;
    }

    private static ConversionTarget manualArray(Object[] values) {
        ConversionTarget target = new ConversionTarget();
        target.id = Long.valueOf((String) values[1]); target.enabled = Boolean.valueOf((String) values[3]);
        target.bigDecimal = new BigDecimal((String) values[5]); target.date = LocalDate.parse((String) values[7]);
        return target;
    }

    private static Map<String, Object> manualBeanToMap(DirectSource source) {
        Map<String, Object> target = new LinkedHashMap<>();
        target.put("primitiveBoolean", source.isPrimitiveBoolean()); target.put("primitiveByte", source.getPrimitiveByte()); target.put("primitiveShort", source.getPrimitiveShort()); target.put("primitiveInt", source.getPrimitiveInt()); target.put("primitiveLong", source.getPrimitiveLong()); target.put("primitiveFloat", source.getPrimitiveFloat()); target.put("primitiveDouble", source.getPrimitiveDouble()); target.put("primitiveChar", source.getPrimitiveChar());
        target.put("wrapperBoolean", source.getWrapperBoolean()); target.put("wrapperByte", source.getWrapperByte()); target.put("wrapperShort", source.getWrapperShort()); target.put("wrapperInt", source.getWrapperInt()); target.put("wrapperLong", source.getWrapperLong()); target.put("wrapperFloat", source.getWrapperFloat()); target.put("wrapperDouble", source.getWrapperDouble()); target.put("wrapperChar", source.getWrapperChar());
        target.put("text", source.getText()); target.put("bigInteger", source.getBigInteger()); target.put("bigDecimal", source.getBigDecimal()); target.put("status", source.getStatus()); target.put("date", source.getDate()); target.put("localDate", source.getLocalDate()); target.put("localTime", source.getLocalTime()); target.put("localDateTime", source.getLocalDateTime()); target.put("year", source.getYear()); target.put("month", source.getMonth()); target.put("yearMonth", source.getYearMonth());
        return target;
    }

    @FunctionalInterface private interface Task { Object run(); }
    enum Status { ACTIVE, INACTIVE }

    public static class DirectSource {
        private boolean primitiveBoolean; private byte primitiveByte; private short primitiveShort; private int primitiveInt; private long primitiveLong; private float primitiveFloat; private double primitiveDouble; private char primitiveChar;
        private Boolean wrapperBoolean; private Byte wrapperByte; private Short wrapperShort; private Integer wrapperInt; private Long wrapperLong; private Float wrapperFloat; private Double wrapperDouble; private Character wrapperChar;
        private String text; private BigInteger bigInteger; private BigDecimal bigDecimal; private Status status; private Date date; private LocalDate localDate; private LocalTime localTime; private LocalDateTime localDateTime; private Year year; private Month month; private YearMonth yearMonth;
        public boolean isPrimitiveBoolean() { return primitiveBoolean; } public void setPrimitiveBoolean(boolean value) { primitiveBoolean = value; } public byte getPrimitiveByte() { return primitiveByte; } public void setPrimitiveByte(byte value) { primitiveByte = value; } public short getPrimitiveShort() { return primitiveShort; } public void setPrimitiveShort(short value) { primitiveShort = value; } public int getPrimitiveInt() { return primitiveInt; } public void setPrimitiveInt(int value) { primitiveInt = value; } public long getPrimitiveLong() { return primitiveLong; } public void setPrimitiveLong(long value) { primitiveLong = value; } public float getPrimitiveFloat() { return primitiveFloat; } public void setPrimitiveFloat(float value) { primitiveFloat = value; } public double getPrimitiveDouble() { return primitiveDouble; } public void setPrimitiveDouble(double value) { primitiveDouble = value; } public char getPrimitiveChar() { return primitiveChar; } public void setPrimitiveChar(char value) { primitiveChar = value; }
        public Boolean getWrapperBoolean() { return wrapperBoolean; } public void setWrapperBoolean(Boolean value) { wrapperBoolean = value; } public Byte getWrapperByte() { return wrapperByte; } public void setWrapperByte(Byte value) { wrapperByte = value; } public Short getWrapperShort() { return wrapperShort; } public void setWrapperShort(Short value) { wrapperShort = value; } public Integer getWrapperInt() { return wrapperInt; } public void setWrapperInt(Integer value) { wrapperInt = value; } public Long getWrapperLong() { return wrapperLong; } public void setWrapperLong(Long value) { wrapperLong = value; } public Float getWrapperFloat() { return wrapperFloat; } public void setWrapperFloat(Float value) { wrapperFloat = value; } public Double getWrapperDouble() { return wrapperDouble; } public void setWrapperDouble(Double value) { wrapperDouble = value; } public Character getWrapperChar() { return wrapperChar; } public void setWrapperChar(Character value) { wrapperChar = value; }
        public String getText() { return text; } public void setText(String value) { text = value; } public BigInteger getBigInteger() { return bigInteger; } public void setBigInteger(BigInteger value) { bigInteger = value; } public BigDecimal getBigDecimal() { return bigDecimal; } public void setBigDecimal(BigDecimal value) { bigDecimal = value; } public Status getStatus() { return status; } public void setStatus(Status value) { status = value; } public Date getDate() { return date; } public void setDate(Date value) { date = value; } public LocalDate getLocalDate() { return localDate; } public void setLocalDate(LocalDate value) { localDate = value; } public LocalTime getLocalTime() { return localTime; } public void setLocalTime(LocalTime value) { localTime = value; } public LocalDateTime getLocalDateTime() { return localDateTime; } public void setLocalDateTime(LocalDateTime value) { localDateTime = value; } public Year getYear() { return year; } public void setYear(Year value) { year = value; } public Month getMonth() { return month; } public void setMonth(Month value) { month = value; } public YearMonth getYearMonth() { return yearMonth; } public void setYearMonth(YearMonth value) { yearMonth = value; }
    }

    public static class DirectTarget extends DirectSource { }
    public static class ConversionSource { public String id, enabled, byteValue, shortValue, intValue, floatValue, doubleValue, charValue, bigInteger, bigDecimal, status, date, time, dateTime, yearMonth; }
    public static class ConversionTarget { public Long id; public Boolean enabled; public Byte byteValue; public Short shortValue; public Integer intValue; public Float floatValue; public Double doubleValue; public Character charValue; public BigInteger bigInteger; public BigDecimal bigDecimal; public Status status; public LocalDate date; public LocalTime time; public LocalDateTime dateTime; public YearMonth yearMonth; }
    public static class ChildSource { public String name; public int rank; public ChildSource() { } ChildSource(String name, int rank) { this.name = name; this.rank = rank; } }
    public static class ChildTarget { public String name; public int rank; }
    public static class ComplexSource { public ChildSource nested; public List<ChildSource> children; public Map<String, String> attributes; public int[] numbers; }
    public static class ComplexTarget { public ChildTarget nested; public List<ChildTarget> children; public Map<String, String> attributes; public int[] numbers; }
}
