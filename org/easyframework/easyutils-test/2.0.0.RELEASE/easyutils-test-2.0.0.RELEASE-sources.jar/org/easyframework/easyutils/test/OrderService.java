package org.easyframework.easyutils.test;

 interface OrderService<A, D, T> extends BaseService<D, T> {

}
