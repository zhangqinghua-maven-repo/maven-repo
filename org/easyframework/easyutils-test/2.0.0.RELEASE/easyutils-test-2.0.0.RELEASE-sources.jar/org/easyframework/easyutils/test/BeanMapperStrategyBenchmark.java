package org.easyframework.easyutils.test;

import org.easyframework.easyutils.BeanMapper;

import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

/**
 * Isolates mapper execution strategies using the same 14-field DTO pair.
 * This is deliberately a diagnostic benchmark, not a replacement for JMH.
 */
public final class BeanMapperStrategyBenchmark {
    private static final int WARMUP = 100_000;
    private static final int ITERATIONS = 1_000_000;
    private static volatile Object sink;

    private BeanMapperStrategyBenchmark() { }

    public static void main(String[] args) throws Throwable {
        BeanMapperPerformanceTest.Src source = buildSource();
        Strategy originalReflection = new OriginalReflectionStrategy();
        Strategy directField = new DirectFieldStrategy();
        Strategy methodHandle = new MethodHandleStrategy();

        measure("manual get/set", source, BeanMapperStrategyBenchmark::manualMap);
        measure("original reflection: Field.get + setter.invoke", source, originalReflection::map);
        measure("direct reflection: Field.get + Field.set", source, directField::map);
        measure("MethodHandle.invokeWithArguments", source, methodHandle::map);
        try {
            Strategy lambda = new LambdaStrategy();
            measure("LambdaMetafactory field access", source, lambda::map);
        } catch (Throwable e) {
            System.out.printf("%-48s unavailable: %s%n", "LambdaMetafactory field access", e.getClass().getSimpleName());
        }
        measure("current BeanMapper.map", source, value -> BeanMapper.map(value, BeanMapperPerformanceTest.Dest.class));
    }

    private static void measure(String name, BeanMapperPerformanceTest.Src source, Mapper mapper) {
        for (int index = 0; index < WARMUP; index++) sink = mapper.map(source);
        long start = System.nanoTime();
        for (int index = 0; index < ITERATIONS; index++) sink = mapper.map(source);
        long elapsed = System.nanoTime() - start;
        double latency = elapsed / (double) ITERATIONS;
        double throughput = ITERATIONS * 1_000_000_000.0 / elapsed;
        System.out.printf("%-48s %9.1f ns/op  %12.0f ops/s%n", name, latency, throughput);
    }

    private static BeanMapperPerformanceTest.Dest manualMap(BeanMapperPerformanceTest.Src source) {
        BeanMapperPerformanceTest.Dest target = new BeanMapperPerformanceTest.Dest();
        target.setId(source.getId());
        target.setName(source.getName());
        target.setAge(source.getAge());
        target.setSalary(source.getSalary());
        target.setBigValue(source.getBigValue());
        target.setCreateTime(source.getCreateTime());
        target.setBirthday(source.getBirthday());
        target.setWorkStartTime(source.getWorkStartTime());
        target.setUpdateTime(source.getUpdateTime());
        target.setPeriod(source.getPeriod());
        target.setActive(source.getActive());
        target.setScore(source.getScore());
        target.setStatus(source.getStatus());
        target.setNested(source.getNested());
        return target;
    }

    private static BeanMapperPerformanceTest.Src buildSource() {
        BeanMapperPerformanceTest.Src source = new BeanMapperPerformanceTest.Src();
        source.setId(1L);
        source.setName("benchmark");
        source.setAge(28);
        source.setSalary(new java.math.BigDecimal("15000.50"));
        source.setBigValue(java.math.BigInteger.valueOf(9999999999L));
        source.setCreateTime(new java.util.Date());
        source.setBirthday(java.time.LocalDate.of(1995, 6, 15));
        source.setWorkStartTime(java.time.LocalTime.of(9, 0));
        source.setUpdateTime(java.time.LocalDateTime.of(2026, 7, 12, 12, 0));
        source.setPeriod(java.time.YearMonth.of(2024, 1));
        source.setActive(true);
        source.setScore(95.5);
        source.setStatus(BeanMapperPerformanceTest.Status.ACTIVE);
        source.setNested(new BeanMapperPerformanceTest.SrcNested());
        return source;
    }

    @FunctionalInterface
    private interface Mapper { Object map(BeanMapperPerformanceTest.Src source); }

    private abstract static class AbstractStrategy implements Strategy {
        final List<FieldPair> fields = fieldPairs();

        static List<FieldPair> fieldPairs() {
            List<FieldPair> pairs = new ArrayList<>();
            for (Field source : BeanMapperPerformanceTest.Src.class.getDeclaredFields()) {
                if (Modifier.isStatic(source.getModifiers())) continue;
                try {
                    Field target = BeanMapperPerformanceTest.Dest.class.getDeclaredField(source.getName());
                    source.trySetAccessible();
                    target.trySetAccessible();
                    pairs.add(new FieldPair(source, target));
                } catch (NoSuchFieldException ignored) {
                    // The strategy benchmark only compares matching fields.
                }
            }
            return pairs;
        }

        BeanMapperPerformanceTest.Dest newTarget() { return new BeanMapperPerformanceTest.Dest(); }
    }

    private interface Strategy {
        Object map(BeanMapperPerformanceTest.Src source);
    }

    private static final class OriginalReflectionStrategy extends AbstractStrategy {
        private final List<ReflectionPair> setters = new ArrayList<>();

        OriginalReflectionStrategy() {
            try {
                for (FieldPair pair : fields) {
                    Method setter = BeanMapperPerformanceTest.Dest.class.getMethod(
                            "set" + Character.toUpperCase(pair.target.getName().charAt(0)) + pair.target.getName().substring(1),
                            pair.target.getType());
                    setters.add(new ReflectionPair(pair.source, setter));
                }
            } catch (NoSuchMethodException e) {
                throw new IllegalStateException(e);
            }
        }

        @Override
        public Object map(BeanMapperPerformanceTest.Src source) {
            BeanMapperPerformanceTest.Dest target = newTarget();
            try {
                for (ReflectionPair pair : setters) pair.setter.invoke(target, pair.source.get(source));
                return target;
            } catch (ReflectiveOperationException e) {
                throw new IllegalStateException(e);
            }
        }
    }

    private static final class DirectFieldStrategy extends AbstractStrategy {
        @Override
        public Object map(BeanMapperPerformanceTest.Src source) {
            BeanMapperPerformanceTest.Dest target = newTarget();
            try {
                for (FieldPair pair : fields) pair.target.set(target, pair.source.get(source));
                return target;
            } catch (IllegalAccessException e) {
                throw new IllegalStateException(e);
            }
        }
    }

    private static final class MethodHandleStrategy extends AbstractStrategy {
        private final MethodHandle constructor;
        private final List<MethodHandlePair> handles = new ArrayList<>();

        MethodHandleStrategy() throws IllegalAccessException, NoSuchMethodException {
            MethodHandles.Lookup lookup = MethodHandles.lookup();
            Constructor<BeanMapperPerformanceTest.Dest> ctor = BeanMapperPerformanceTest.Dest.class.getDeclaredConstructor();
            constructor = lookup.unreflectConstructor(ctor);
            for (FieldPair pair : fields) handles.add(new MethodHandlePair(
                    lookup.unreflectGetter(pair.source), lookup.unreflectSetter(pair.target)));
        }

        @Override
        public Object map(BeanMapperPerformanceTest.Src source) {
            try {
                Object target = constructor.invokeWithArguments();
                for (MethodHandlePair pair : handles) pair.writer.invokeWithArguments(target, pair.reader.invokeWithArguments(source));
                return target;
            } catch (Throwable e) {
                throw new IllegalStateException(e);
            }
        }
    }

    private static final class LambdaStrategy extends AbstractStrategy {
        private final Factory factory;
        private final List<LambdaPair> accessors = new ArrayList<>();

        LambdaStrategy() throws Throwable {
            MethodHandles.Lookup lookup = MethodHandles.lookup();
            Constructor<BeanMapperPerformanceTest.Dest> ctor = BeanMapperPerformanceTest.Dest.class.getDeclaredConstructor();
            factory = factory(lookup.unreflectConstructor(ctor));
            for (FieldPair pair : fields) accessors.add(new LambdaPair(
                    reader(lookup.unreflectGetter(pair.source)), writer(lookup.unreflectSetter(pair.target))));
        }

        @Override
        public Object map(BeanMapperPerformanceTest.Src source) {
            Object target = factory.create();
            for (LambdaPair pair : accessors) pair.writer.write(target, pair.reader.read(source));
            return target;
        }
    }

    private record FieldPair(Field source, Field target) { }
    private record ReflectionPair(Field source, Method setter) { }
    private record MethodHandlePair(MethodHandle reader, MethodHandle writer) { }
    private record LambdaPair(Reader reader, Writer writer) { }

    @FunctionalInterface private interface Reader { Object read(Object source); }
    @FunctionalInterface private interface Writer { void write(Object target, Object value); }
    @FunctionalInterface private interface Factory { Object create(); }

    private static Reader reader(MethodHandle handle) throws Throwable {
        MethodType sam = MethodType.methodType(Object.class, Object.class);
        return (Reader) LambdaMetafactory.metafactory(MethodHandles.lookup(), "read",
                MethodType.methodType(Reader.class), sam, handle, handle.type()).getTarget().invokeExact();
    }

    private static Writer writer(MethodHandle handle) throws Throwable {
        MethodType sam = MethodType.methodType(void.class, Object.class, Object.class);
        return (Writer) LambdaMetafactory.metafactory(MethodHandles.lookup(), "write",
                MethodType.methodType(Writer.class), sam, handle, handle.type()).getTarget().invokeExact();
    }

    private static Factory factory(MethodHandle handle) throws Throwable {
        MethodType sam = MethodType.methodType(Object.class);
        return (Factory) LambdaMetafactory.metafactory(MethodHandles.lookup(), "create",
                MethodType.methodType(Factory.class), sam, handle, handle.type()).getTarget().invokeExact();
    }
}
