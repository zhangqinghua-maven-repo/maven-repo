package org.easyframework.easyutils.test;

 interface BaseService2 extends BaseService<Order, Member> {
}
