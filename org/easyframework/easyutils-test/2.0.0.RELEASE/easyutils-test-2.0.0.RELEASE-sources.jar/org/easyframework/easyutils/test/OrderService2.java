package org.easyframework.easyutils.test;

 class OrderService2 implements BaseService2 {
}
