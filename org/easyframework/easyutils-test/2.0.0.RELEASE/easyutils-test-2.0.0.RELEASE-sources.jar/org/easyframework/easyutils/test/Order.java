package org.easyframework.easyutils.test;

class Order {
}
