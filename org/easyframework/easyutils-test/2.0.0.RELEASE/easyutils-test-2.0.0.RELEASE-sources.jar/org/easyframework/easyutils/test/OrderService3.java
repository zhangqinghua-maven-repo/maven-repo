package org.easyframework.easyutils.test;

 interface OrderService3<Order> {
}
