package org.easyframework.easyutils.test;

import org.easyframework.easyutils.GenericUtils;

class TestCode {

    public static void main(String[] args) {
        System.out.println(GenericUtils.findInterfaceGenerics(OrderService.class));
    }
}
