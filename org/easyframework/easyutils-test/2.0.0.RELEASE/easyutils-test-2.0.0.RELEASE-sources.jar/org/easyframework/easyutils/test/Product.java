package org.easyframework.easyutils.test;

class Product {
}
