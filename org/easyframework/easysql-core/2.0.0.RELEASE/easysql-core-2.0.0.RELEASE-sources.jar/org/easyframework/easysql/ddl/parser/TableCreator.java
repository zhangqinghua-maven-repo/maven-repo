package org.easyframework.easysql.ddl.parser;

import org.easyframework.easysql.annotations.Column;
import org.easyframework.easysql.annotations.Table;
import org.easyframework.easysql.ddl.dialect.DatabaseDialect;
import org.easyframework.easysql.ddl.util.SQLUtils;
import org.easyframework.easyutils.ReflectUtils;

import java.lang.reflect.Field;
import java.util.List;

public class TableCreator {

    /**
     * 生成 CREATE TABLE SQL。
     *
     * @param clz     实体类
     * @param dialect 数据库方言
     * @return DDL SQL，若实体无 @Table 注解则返回 null
     */
    public static String parse(Class<?> clz, DatabaseDialect dialect) {
        Table entity = clz.getAnnotation(Table.class);
        if (entity == null) {
            return null;
        }
        String tableName = SQLUtils.toTableName(clz.getSimpleName());
        StringBuilder sb = new StringBuilder();
        sb.append("CREATE TABLE ").append(dialect.quote(tableName)).append(" (\n");

        List<Field> fields = ReflectUtils.fields(clz);
        for (Field field : fields) {
            Column column = field.getAnnotation(Column.class);
            if (column == null) continue;

            sb.append("  ");
            // 如果存在自定义字段定义，直接取
            if (!column.columnDefinition().isEmpty()) {
                sb.append(dialect.quote(SQLUtils.toColumnName(field.getName())))
                  .append("\t")
                  .append(column.columnDefinition())
                  .append(",");
            } else {
                sb.append(ColumnParser.parse(field, column, dialect)).append(",");
            }
            sb.append("\n");
        }

        // 主键和索引
        for (Field field : fields) {
            Column column = field.getAnnotation(Column.class);
            if (column == null) continue;
            String columnName = SQLUtils.toColumnName(field.getName());
            if (column.key()) {
                sb.append("  PRIMARY KEY (").append(dialect.quote(columnName)).append("),\n");
            }
            if (column.index() && dialect.supportsInlineIndex()) {
                String indexName = SQLUtils.indexName(tableName, columnName);
                sb.append("  ").append(dialect.indexFragment(
                        dialect.quote(tableName), indexName, dialect.quote(columnName))).append(",\n");
            }
        }

        // 去掉最后一个逗号
        if (sb.lastIndexOf(",") == sb.length() - 2) {
            sb.deleteCharAt(sb.length() - 2);
        }

        sb.append(") ");

        // 表选项（ENGINE/CHARSET for MySQL, empty for PG）
        String options = dialect.tableOptions(entity);
        if (!options.isEmpty()) {
            sb.append(options).append(" ");
        }
        // 表注释（Dialect 控制：MySQL 内联，PG 跳过）
        String tableComment = dialect.tableComment(entity.value());
        if (!tableComment.isEmpty()) {
            sb.append(tableComment);
        }

        // 不支持内联索引的数据库，在建表后追加独立 CREATE INDEX。
        if (!dialect.supportsInlineIndex()) {
            for (Field field : fields) {
                Column column = field.getAnnotation(Column.class);
                if (column == null || !column.index()) continue;
                String columnName = SQLUtils.toColumnName(field.getName());
                String indexName = SQLUtils.indexName(tableName, columnName);
                sb.append(";\n").append(dialect.createIndex(
                        dialect.quote(tableName), dialect.quote(indexName), dialect.quote(columnName)));
            }
        }

        // 列注释：PG 用独立的 COMMENT ON COLUMN 语句（MySQL 已在列定义中内联）
        for (Field field : fields) {
            Column column = field.getAnnotation(Column.class);
            if (column == null || column.comment().isEmpty()) continue;
            String commentStmt = dialect.commentOnColumn(
                    dialect.quote(tableName),
                    dialect.quote(SQLUtils.toColumnName(field.getName())),
                    column.comment());
            if (!commentStmt.isEmpty()) {
                sb.append(";\n").append(commentStmt);
            }
        }

        // 表注释：PG 用独立的 COMMENT ON TABLE 语句（MySQL 已在表定义中内联）
        String tableCommentForDialect = dialect.commentOnTable(
                dialect.quote(tableName),
                entity.value());
        if (!tableCommentForDialect.isEmpty()) {
            sb.append(";\n").append(tableCommentForDialect);
        }

        return sb.toString();
    }
}
