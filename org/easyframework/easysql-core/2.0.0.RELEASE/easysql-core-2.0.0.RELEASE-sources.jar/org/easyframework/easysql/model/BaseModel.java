package org.easyframework.easysql.model;

import org.easyframework.easysql.annotations.Column;

import java.io.Serializable;
import java.time.LocalDateTime;

public class BaseModel implements Serializable {

    private static final long serialVersionUID = 9841816204289916L;

    @Column(key = true)
    private Long id;

    /**
     * 查询时
     * Ge：开始时间
     * Le：结束时间
     *
     * 有可能报错，Incorrect datetime value: '0000-00-00 00:00:00' for column 'created_at' at row 1
     * https://www.cnblogs.com/nayek/p/12915570.html
     */
    @Column(comment = "创建时间（gmtCreatedGe-开始  gmtCreatedLe-结束）", nullable = false)
    private LocalDateTime gmtCreated;

    @Column(comment = "修改时间", nullable = false)
    private LocalDateTime gmtModified;

    @Column(comment = "创建者", nullable = false, def = "sys", length = 32)
    private String creator;

    @Column(comment = "修改者", nullable = false, def = "sys", length = 32)
    private String modifier;

    @Column(comment = "是否已删除 0-未删除 1-已删除", def = "false", length = 1)
    private Boolean isDeleted;

    /**
     * todo 待优化
     * 只能由DTO调用，获取P class
     * <p>
     * Goods
     *
     * @return BizGoods
     */
    public Class<?> pclass() {
        return this.getClass().getSuperclass();
    }

    public BaseModel() {
    }

    public BaseModel(Long id) {
        this.id = id;
    }

    public BaseModel(Long id, LocalDateTime gmtCreated, LocalDateTime gmtModified, String creator, String modifier, Boolean isDeleted) {
        this.id = id;
        this.gmtCreated = gmtCreated;
        this.gmtModified = gmtModified;
        this.creator = creator;
        this.modifier = modifier;
        this.isDeleted = isDeleted;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(LocalDateTime gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public LocalDateTime getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(LocalDateTime gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public String toString() {
        return "BaseModel{" +
               "id=" + id +
               ", gmtCreated=" + gmtCreated +
               ", gmtModified=" + gmtModified +
               ", creator='" + creator + '\'' +
               ", modifier='" + modifier + '\'' +
               ", isDeleted=" + isDeleted +
               '}';
    }
}
