package org.easyframework.easysql.mapper;

import org.easyframework.easysql.ddl.util.SQLUtils;
import org.easyframework.easysql.exception.EasysqlException;
import org.springframework.jdbc.core.RowMapper;

import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.util.List;

/** Converts JDBC rows to EasySQL entity instances. */
final class EntityRowMapper {

    private EntityRowMapper() {
    }

    static <T> RowMapper<T> create(Class<T> type) {
        List<Field> fields = EntityMetadata.fields(type);
        return (resultSet, rowNumber) -> map(resultSet, type, fields);
    }

    private static <T> T map(ResultSet resultSet, Class<T> type, List<Field> fields) {
        try {
            T instance = type.getDeclaredConstructor().newInstance();
            for (int index = 1; index <= resultSet.getMetaData().getColumnCount(); index++) {
                String fieldName = SQLUtils.toFieldName(resultSet.getMetaData().getColumnLabel(index));
                for (Field field : fields) {
                    if (!field.getName().equals(fieldName)) continue;
                    Object value = resultSet.getObject(index);
                    if (value != null) {
                        field.setAccessible(true);
                        field.set(instance, convert(BeetMapper.fromJdbcValue(field, value), field.getType()));
                    }
                    break;
                }
            }
            return instance;
        } catch (Exception exception) {
            throw new EasysqlException("Failed to map row to " + type.getSimpleName(), exception);
        }
    }

    private static Object convert(Object value, Class<?> targetType) {
        if (targetType == LocalDateTime.class && value instanceof java.sql.Timestamp timestamp) return timestamp.toLocalDateTime();
        if (targetType == Long.class && value instanceof Number number) return number.longValue();
        if (targetType == Integer.class && value instanceof Number number) return number.intValue();
        return value;
    }
}
