package org.easyframework.easysql.model;


import java.io.Serializable;
import java.util.Collection;
import java.util.List;
public final class FieldBean implements Serializable {

    private String name;


    private Class<?> type;

    private QueryParam.QueryType queryType;

    /**
     * 查询查询的值
     * NOT_EQ、EQ、NOT_LIKE、LIKE、GT、GE、LT、LE、IS_NULL、NOT_NULL、NOT_IN、IN、ASC、DESC
     */
    private Object value;

    /**
     * 复合查询的值
     * OR、AND
     */
    private List<FieldBean> values;

    // /**
    //  * 高级查询：IN
    //  */
    // private InFieldBean inFieldBean;
    //
    // /**
    //  * 高级查询：OR
    //  */
    // private InFieldBean orFieldBean;
    //
    // /**
    //  * 高级查询：AND
    //  */
    // private InFieldBean andFieldBean;

    /**
     * 高级查询：EXISTS
     */
    private ExistsFieldBean existsFieldBean;

    public static class InFieldBean {
        private Collection<FieldBean> fieldBeans;

        public void setFieldBeans(Collection<FieldBean> fieldBeans) {
            this.fieldBeans = fieldBeans;
        }

        public Collection<FieldBean> getFieldBeans() {
            return fieldBeans;
        }
    }

    /**
     * EXISTS 查询
     * 例如：exists(Goods::getFistCateId, FirstCate::getId, like(FistCate::getName, "888"))
     * 等于：and EXISTS (select 1 from biz_first_cate where is_deleted = 'n' and name like '%888%' and id = first_cate_id)
     */
    public static class ExistsFieldBean {

        /**
         * FistCate.class,
         */
        private Class<?> joinClz;

        /**
         * Goods.class
         */
        private Class<?> foreignClz;

        /**
         * FirstCate::getId
         */
        private String joinName;

        /**
         * Goods::getFistCateId
         */
        private String foreignName;


        /**
         * like(FistCate::getName, "888")
         */
        private List<FieldBean> fieldBeans;

        public Class<?> getJoinClz() {
            return joinClz;
        }

        public void setJoinClz(Class<?> joinClz) {
            this.joinClz = joinClz;
        }

        public Class<?> getForeignClz() {
            return foreignClz;
        }

        public void setForeignClz(Class<?> foreignClz) {
            this.foreignClz = foreignClz;
        }

        public String getJoinName() {
            return joinName;
        }

        public void setJoinName(String joinName) {
            this.joinName = joinName;
        }

        public String getForeignName() {
            return foreignName;
        }

        public void setForeignName(String foreignName) {
            this.foreignName = foreignName;
        }

        public List<FieldBean> getFieldBeans() {
            return fieldBeans;
        }

        public void setFieldBeans(List<FieldBean> fieldBeans) {
            this.fieldBeans = fieldBeans;
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Class<?> getType() {
        return type;
    }

    public void setType(Class<?> type) {
        this.type = type;
    }

    public QueryParam.QueryType getQueryType() {
        return queryType;
    }

    public void setQueryType(QueryParam.QueryType queryType) {
        this.queryType = queryType;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public List<FieldBean> getValues() {
        return values;
    }

    public void setValues(List<FieldBean> values) {
        this.values = values;
    }

    public ExistsFieldBean getExistsFieldBean() {
        return existsFieldBean;
    }

    public void setExistsFieldBean(ExistsFieldBean existsFieldBean) {
        this.existsFieldBean = existsFieldBean;
    }
}
