package org.easyframework.easysql.config;

import org.easyframework.easysql.annotations.EnableEasySQL;
import org.easyframework.easysql.model.BaseModel;
import org.easyframework.easysql.repository.impl.AbstractService;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.core.ResolvableType;

import java.util.Map;

/**
 * 在 Bean 定义阶段捕获 {@link EnableEasySQL} 注解属性。
 * <p>
 * 分两阶段工作：
 * <ol>
 *   <li><b>本阶段（registerBeanDefinitions）</b>：收集注解中的
 *       {@code basePackage} 和显式 {@code entities}，存入
 *       {@link EasySQLEntities}；注册 {@link EasySQLScanPostProcessor}</li>
 *   <li><b>延迟阶段（EasySQLScanPostProcessor）</b>：在
 *       {@link org.springframework.core.Ordered#LOWEST_PRECEDENCE}
 *       执行实际扫描，此时用户动态添加的 scan package 已全部就绪</li>
 * </ol>
 */
public class EasySQLRegistrar implements ImportBeanDefinitionRegistrar {

    @Override
    public void registerBeanDefinitions(AnnotationMetadata metadata, BeanDefinitionRegistry registry) {
        Map<String, Object> attrs = metadata.getAnnotationAttributes(EnableEasySQL.class.getName());
        if (attrs == null) return;

        // 1. 收集 basePackage（不立即扫描，交给 EasySQLScanPostProcessor 延迟执行）
        String bp = (String) attrs.getOrDefault("basePackage", "");

        // 未指定 basePackage 时，默认扫描注解所在类的包及其子包
        if (bp.isEmpty()) {
            String className = metadata.getClassName();
            int lastDot = className.lastIndexOf('.');
            bp = lastDot > 0 ? className.substring(0, lastDot) : "";
        }

        EasySQLEntities.addScanPackage(bp);

        // 注册延迟扫描器（LOWEST_PRECEDENCE，确保用户动态配置的包也被收集）
        if (!registry.containsBeanDefinition(EasySQLScanPostProcessor.class.getName())) {
            GenericBeanDefinition postProcessorDef = new GenericBeanDefinition();
            postProcessorDef.setBeanClass(EasySQLScanPostProcessor.class);
            registry.registerBeanDefinition(EasySQLScanPostProcessor.class.getName(), postProcessorDef);
        }

        // 2. 显式声明实体：直接注册 Service Bean
        Object entitiesObj = attrs.get("entities");
        if (entitiesObj instanceof Class<?>[] entityArray) {
            for (Class<?> c : entityArray) {
                if (BaseModel.class.isAssignableFrom(c)) {
                    @SuppressWarnings("unchecked")
                    Class<? extends BaseModel> entity = (Class<? extends BaseModel>) c;
                    EasySQLEntities.addEntity(entity);
                    registerServiceBean(registry, entity);
                }
            }
        } else if (entitiesObj instanceof String[] classNames) {
            for (String className : classNames) {
                try {
                    Class<?> c = Class.forName(className);
                    if (BaseModel.class.isAssignableFrom(c)) {
                        @SuppressWarnings("unchecked")
                        Class<? extends BaseModel> entity = (Class<? extends BaseModel>) c;
                        EasySQLEntities.addEntity(entity);
                        registerServiceBean(registry, entity);
                    }
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException("Entity class not found: " + className, e);
                }
            }
        }
    }

    /**
     * 为实体类自动注册 AbstractService Bean。
     * 使用工厂方法 {@code AbstractService.of(entityClass)} 创建。
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    private void registerServiceBean(BeanDefinitionRegistry registry, Class<? extends BaseModel> entityClass) {
        String beanName = Character.toLowerCase(entityClass.getSimpleName().charAt(0))
                          + entityClass.getSimpleName().substring(1) + "Service";
        if (registry.containsBeanDefinition(beanName)) return;

        RootBeanDefinition bd = new RootBeanDefinition();
        bd.setBeanClass(AbstractService.class);
        bd.setTargetType(ResolvableType.forClassWithGenerics(AbstractService.class, entityClass));
        bd.setFactoryMethodName("of");
        bd.getConstructorArgumentValues().addGenericArgumentValue(entityClass);
        registry.registerBeanDefinition(beanName, bd);
    }
}
