package org.easyframework.easysql.config;

import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.util.Locale;

/**
 * 数据库启动验证失败，携带面向使用者的修复建议。
 */
public class DatabaseStartupException extends IllegalStateException {

    private final String action;

    private DatabaseStartupException(String message, String action, Throwable cause) {
        super(message, cause);
        this.action = action;
    }

    public String getAction() {
        return action;
    }

    static DatabaseStartupException classify(String jdbcUrl, Throwable failure, long elapsedMs) {
        String target = sanitizeJdbcUrl(jdbcUrl);
        SQLException sqlException = findCause(failure, SQLException.class);
        String sqlState = sqlException == null ? null : sqlException.getSQLState();
        int errorCode = sqlException == null ? 0 : sqlException.getErrorCode();
        String messages = causeMessages(failure).toLowerCase(Locale.ROOT);

        if ((sqlState != null && sqlState.startsWith("28"))
                || errorCode == 1045
                || messages.contains("access denied")
                || messages.contains("password authentication failed")) {
            return failure(
                    "数据库认证失败：" + target + "，耗时 " + elapsedMs + " ms",
                    "检查 spring.datasource.username、spring.datasource.password，以及数据库用户允许登录的来源地址。",
                    failure
            );
        }
        if ("3D000".equals(sqlState) || errorCode == 1049 || messages.contains("unknown database")) {
            return failure(
                    "数据库不存在或名称错误：" + target,
                    "检查 spring.datasource.url 中的数据库名称，并确认该数据库已经创建。",
                    failure
            );
        }
        if (errorCode == 1040 || "53300".equals(sqlState) || messages.contains("too many connections")) {
            return failure(
                    "数据库连接数已耗尽：" + target,
                    "检查数据库最大连接数、当前连接占用和 Hikari 连接池大小。",
                    failure
            );
        }
        if (hasCause(failure, UnknownHostException.class)) {
            return failure(
                    "数据库地址无法解析：" + target,
                    "检查 spring.datasource.url 中的主机名和 DNS 配置。",
                    failure
            );
        }
        if (hasCause(failure, NoRouteToHostException.class)) {
            return failure(
                    "数据库地址不可达：" + target,
                    "检查数据库地址、网络路由、防火墙、安全组和 SSH 隧道。",
                    failure
            );
        }
        if (hasCause(failure, SocketTimeoutException.class)
                || (sqlState != null && sqlState.startsWith("HYT"))
                || messages.contains("connect timed out")
                || messages.contains("connection timed out")) {
            return failure(
                    "数据库连接超时：" + target + "，耗时 " + elapsedMs + " ms",
                    "检查网络质量、数据库负载和 JDBC connectTimeout/socketTimeout 配置。",
                    failure
            );
        }
        if (hasCause(failure, ConnectException.class)) {
            return failure(
                    "数据库连接被拒绝：" + target,
                    "检查数据库端口、数据库服务监听状态、防火墙和 SSH 隧道。",
                    failure
            );
        }
        return failure(
                "数据库连接验证失败：" + target + "，耗时 " + elapsedMs + " ms",
                "检查数据源地址、数据库服务状态、认证信息和网络连接。",
                failure
        );
    }

    private static DatabaseStartupException failure(String message, String action, Throwable cause) {
        return new DatabaseStartupException(message, action, cause);
    }

    private static String sanitizeJdbcUrl(String jdbcUrl) {
        if (jdbcUrl == null || jdbcUrl.isBlank()) {
            return "未配置的数据库地址";
        }
        int queryStart = jdbcUrl.indexOf('?');
        String sanitized = queryStart >= 0 ? jdbcUrl.substring(0, queryStart) : jdbcUrl;
        return sanitized.replaceAll("(//)[^/@:]+:[^/@]+@", "$1***:***@");
    }

    private static boolean hasCause(Throwable failure, Class<? extends Throwable> type) {
        return findCause(failure, type) != null;
    }

    private static <T extends Throwable> T findCause(Throwable failure, Class<T> type) {
        for (Throwable cause = failure; cause != null; cause = cause.getCause()) {
            if (type.isInstance(cause)) {
                return type.cast(cause);
            }
        }
        return null;
    }

    private static String causeMessages(Throwable failure) {
        StringBuilder messages = new StringBuilder();
        for (Throwable cause = failure; cause != null; cause = cause.getCause()) {
            if (cause.getMessage() != null) {
                messages.append(cause.getMessage()).append('\n');
            }
        }
        return messages.toString();
    }
}
