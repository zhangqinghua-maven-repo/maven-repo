package org.easyframework.easysql.annotations;

import org.easyframework.easysql.config.EasySQLDDLConfig;
import org.easyframework.easysql.config.EasySQLDataSourceConfig;
import org.easyframework.easysql.config.EasySQLRegistrar;
import org.easyframework.easysql.mapper.BeetMapper;
import org.easyframework.easysql.mapper.SQLExecutor;
import org.easyframework.easysql.model.BaseModel;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Documented
@Import(value = {
        BeetMapper.class,
        SQLExecutor.class,
        EasySQLDDLConfig.class,
        EasySQLDataSourceConfig.class,
        EasySQLRegistrar.class})
public @interface EnableEasySQL {

    /**
     * 实体类所在的包路径，JVM 模式下自动扫描 @Table 实体。
     * <p>
     * 支持以下形式：
     * <ul>
     *   <li><b>默认（空字符串）</b>：使用声明此注解的类所在的包路径，递归扫描其下所有子包</li>
     *   <li><b>普通包路径</b>：{@code "com.example.entity"}，扫描该包及其所有子包</li>
     *   <li><b>Ant 风格通配符</b>：{@code "com.example.**.model"}，扫描所有匹配该模式的包路径，
     *       其中 {@code **} 匹配任意层级目录</li>
     * </ul>
     */
    String basePackage() default "";

    /**
     * 显式声明的实体类列表（可选）。
     * <p>
     * 通常无需设置此项，框架会自动从 {@link #basePackage()} 扫描 @Table 实体。
     * 仅在需要精确控制注册范围时使用。
     */
    Class<? extends BaseModel>[] entities() default {};
}
