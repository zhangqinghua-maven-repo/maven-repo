package org.easyframework.easysql.mapper;

import org.easyframework.easysql.annotations.Column;
import org.easyframework.easysql.ddl.dialect.DatabaseDialect;
import org.easyframework.easysql.ddl.util.SQLUtils;
import org.easyframework.easysql.model.BaseModel;
import org.easyframework.easysql.model.FieldBean;
import org.easyframework.easysql.model.QueryParam.QueryType;
import org.easyframework.easyutils.ReflectUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

/** Immutable reflection metadata shared by mapper operations. */
final class EntityMetadata {

    private static final ConcurrentMap<Class<?>, List<Field>> FIELDS = new ConcurrentHashMap<>();
    private static final ConcurrentMap<Class<?>, List<String>> COLUMNS = new ConcurrentHashMap<>();
    private static final ConcurrentMap<Class<?>, Map<String, Field>> FIELDS_BY_NAME = new ConcurrentHashMap<>();

    private EntityMetadata() {
    }

    static Class<?> persistentClass(Class<?> type) {
        Class<?> parent = type.getSuperclass();
        return parent != null && parent != Object.class && parent != BaseModel.class
                && BaseModel.class.isAssignableFrom(parent) ? parent : type;
    }

    static List<Field> fields(Class<?> type) {
        return FIELDS.computeIfAbsent(type, key -> ReflectUtils.fields(key).stream()
                .filter(field -> field.getAnnotation(Column.class) != null)
                .collect(Collectors.toList()));
    }

    static List<String> columns(Class<?> type) {
        return COLUMNS.computeIfAbsent(type,
                key -> fields(key).stream().map(Field::getName).collect(Collectors.toList()));
    }

    @SuppressWarnings("unchecked")
    static List<String> selectColumns(Collection<FieldBean> fieldBeans, Class<?> type, DatabaseDialect dialect) {
        List<String> selected = new ArrayList<>();
        for (FieldBean fieldBean : fieldBeans) {
            if (fieldBean.getQueryType() == QueryType.FIELD && fieldBean.getValue() instanceof Collection<?>) {
                selected.addAll((Collection<String>) fieldBean.getValue());
            }
        }
        if (selected.isEmpty()) selected = new ArrayList<>(columns(type));
        List<Field> entityFields = fields(type);
        selected.removeIf(column -> entityFields.stream().noneMatch(field -> field.getName().equals(column)));
        return selected.stream().map(column -> dialect.quote(SQLUtils.toColumnName(column))).collect(Collectors.toList());
    }

    static Object fieldValue(Field field, Object entity) {
        try {
            field.setAccessible(true);
            return field.get(entity);
        } catch (IllegalAccessException exception) {
            return null;
        }
    }

    static Object fieldValue(Object entity, String fieldName) {
        Field field = FIELDS_BY_NAME.computeIfAbsent(entity.getClass(), EntityMetadata::allFieldsByName).get(fieldName);
        return field == null ? null : fieldValue(field, entity);
    }

    private static Map<String, Field> allFieldsByName(Class<?> type) {
        Map<String, Field> fieldsByName = new HashMap<>();
        for (Field field : ReflectUtils.fields(type)) fieldsByName.put(field.getName(), field);
        return fieldsByName;
    }
}
