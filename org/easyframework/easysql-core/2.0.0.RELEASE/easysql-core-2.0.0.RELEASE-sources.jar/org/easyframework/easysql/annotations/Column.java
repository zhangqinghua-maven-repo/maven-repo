package org.easyframework.easysql.annotations;


import org.easyframework.easysql.ddl.enums.Type;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Column {

    /**
     * 是否主键
     */
    boolean key() default false;

    /**
     * 是否索引
     */
    boolean index() default false;

    /**
     * 是否允许为空
     */
    boolean nullable() default true;

    /**
     * 长度 -1 表示未定义
     */
    int length() default -1;

    /**
     * 保留多少位小数点 -1 表示未定义
     */
    int scale() default -1;

    /**
     * 字段类型
     */
    Type type() default Type.NONE;

    /**
     * 默认值
     */
    String def() default "";

    /**
     * 注释
     */
    String comment() default "";

    /**
     * 定义语句，以此为标准，即这里定义了，其它地方失效
     */
    String columnDefinition() default "";

}
