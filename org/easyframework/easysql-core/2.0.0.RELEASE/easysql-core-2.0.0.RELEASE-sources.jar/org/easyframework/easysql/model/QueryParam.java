package org.easyframework.easysql.model;

import org.easyframework.easysql.exception.EasysqlException;
import org.easyframework.easyutils.BeanMapper;
import org.easyframework.easyutils.ReflectUtils;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class QueryParam {

    public static <T extends BaseModel> FieldBean eq(Property<T, ?> property, Object val) {
        return warp(property, val, QueryType.EQ);
    }

    public static <T extends BaseModel> FieldBean eq(String name, Object val) {
        return warp(name, val, QueryType.EQ);
    }

    public static <T extends BaseModel> FieldBean notEq(Property<T, ?> property, Object val) {
        return warp(property, val, QueryType.NOT_EQ);
    }

    public static <T extends BaseModel> FieldBean like(Property<T, ?> property, String val) {
        if (val == null || val.equals("")) return null;
        return warp(property, val, QueryType.LIKE);
    }

    public static <T extends BaseModel> FieldBean notLike(Property<T, ?> property, String val) {
        if (val == null || val.equals("")) return null;
        return warp(property, val, QueryType.NOT_LIKE);
    }

    public static <T extends BaseModel> FieldBean gt(Property<T, ?> property, Object val) {
        return warp(property, val, QueryType.GT);
    }

    public static <T extends BaseModel> FieldBean ge(Property<T, ?> property, Object val) {
        return warp(property, val, QueryType.GE);
    }

    public static <T extends BaseModel> FieldBean lt(Property<T, ?> property, Object val) {
        return warp(property, val, QueryType.LT);
    }

    public static <T extends BaseModel> FieldBean le(Property<T, ?> property, Object val) {
        return warp(property, val, QueryType.LE);
    }

    public static <T extends BaseModel> FieldBean isNull(Property<T, ?> property) {
        return warp(property, true, QueryType.IS_NULL);
    }

    public static <T extends BaseModel> FieldBean notNull(Property<T, ?> property) {
        return warp(property, true, QueryType.NOT_NULL);
    }

    public static <T extends BaseModel> FieldBean in(Property<T, ?> property, Collection<?> val) {
        return in(property, val, true);
    }

    public static <T extends BaseModel> FieldBean in(Property<T, ?> property, Object... params) {
        return in(property, Arrays.stream(params).collect(Collectors.toList()), false);
    }

    /**
     * in 查询
     *
     * in(Order::getUserId, [],     true ) -> where is_deleted = 'n' and user_id in (-1111);
     * in(Order::getUserId, [0, 1], true ) -> where is_deleted = 'n' and user_id in (0, 1);
     *
     * in(Order::getUserId, [],     false) -> where is_deleted = 'n'
     * in(Order::getUserId, [0, 1], false) -> where is_deleted = 'n' and user_id in (0, 1);
     *
     */
    public static <T extends BaseModel> FieldBean in(Property<T, ?> property, Collection<?> val, boolean notnull) {
        if (!notnull && CollectionUtils.isEmpty(val)) return null;
        return warp(property, val, QueryType.IN);
    }

    public static <T extends BaseModel> FieldBean notIn(Property<T, ?> property, Collection<?> val) {
        return notIn(property, val, true);
    }

    public static <T extends BaseModel> FieldBean notIn(Property<T, ?> property, Object... params) {
        return notIn(property, Arrays.stream(params).collect(Collectors.toList()), false);
    }

    /**
     * not in 查询
     *
     * in(Order::getUserId, [],     true ) -> where is_deleted = 'n' and user_id not in (-1111);
     * in(Order::getUserId, [0, 1], true ) -> where is_deleted = 'n' and user_id not in (0, 1);
     *
     * in(Order::getUserId, [],     false) -> where is_deleted = 'n'
     * in(Order::getUserId, [0, 1], false) -> where is_deleted = 'n' and user_id not in (0, 1);
     *
     */
    public static <T extends BaseModel> FieldBean notIn(Property<T, ?> property, Collection<?> val, boolean notnull) {
        if (!notnull && CollectionUtils.isEmpty(val)) return null;
        return warp(property, val, QueryType.NOT_IN);
    }

    public static <T extends BaseModel> FieldBean or(FieldBean... fieldBeans) {
        List<FieldBean> list = new ArrayList<>(Arrays.asList(fieldBeans));
        list.removeIf(Objects::isNull);
        if (list.size() == 0)
            return null;

        FieldBean fieldBean = new FieldBean();
        fieldBean.setName("or_type");
        fieldBean.setQueryType(QueryType.OR);
        fieldBean.setValues(list);
        return fieldBean;
    }

    public static <T extends BaseModel> FieldBean and(FieldBean... fieldBeans) {
        List<FieldBean> list = new ArrayList<>(Arrays.asList(fieldBeans));
        list.removeIf(Objects::isNull);
        if (list.size() == 0)
            return null;

        FieldBean fieldBean = new FieldBean();
        fieldBean.setName("and_type");
        fieldBean.setQueryType(QueryType.AND);
        fieldBean.setValues(list);
        return fieldBean;
    }


    /**
     * 连表查询
     * 判断第三方表是否存在
     *
     * exists(Goods::getCateCode, Cate::getCode, eq(Cate::getName, "8888"))
     *
     * and exists (select 1 from biz_cate where is_deleted = 'n' and code = cate_code and name like '%888%')
     *
     * and exists (select 1 from biz_goods where id = 2)
     * @param foreignProperty   Goods::getCateCode
     * @param joinProperty      Cate::getCode
     * @param fieldBeans        其它查询条件
     * @param <T>               Goods
     * @param <P>               cateCode
     */
    public static <T, D, P> FieldBean exists(Property<T, ?> foreignProperty, Property<D, ?> joinProperty, FieldBean... fieldBeans) {
        // 排除掉null查询
        if (fieldBeans == null || fieldBeans.length == 0) {
            fieldBeans = new FieldBean[1];
            fieldBeans[0] = eq(BaseModel::getIsDeleted, false);
        }
        List<FieldBean> list = new ArrayList<>(Arrays.asList(fieldBeans));
        list.removeIf(Objects::isNull);
        if (list.size() == 0)
            return null;

        // 组装Exists查询
        FieldBean.ExistsFieldBean existsFieldBean = new FieldBean.ExistsFieldBean();
        existsFieldBean.setJoinClz(joinProperty.getClz());
        existsFieldBean.setJoinName(joinProperty.getName());
        existsFieldBean.setForeignClz(foreignProperty.getClz());
        existsFieldBean.setForeignName(foreignProperty.getName());
        existsFieldBean.setFieldBeans(list);
        FieldBean fieldBean = new FieldBean();
        fieldBean.setQueryType(QueryType.EXISTS);
        fieldBean.setExistsFieldBean(existsFieldBean);
        return fieldBean;
    }

    public static <T, D, P> FieldBean notExists(Property<T, ?> foreignProperty, Property<D, ?> joinProperty, FieldBean... fieldBeans) {
        // 排除掉null查询
        if (fieldBeans == null)
            return null;
        List<FieldBean> list = new ArrayList<>(Arrays.asList(fieldBeans));
        list.removeIf(Objects::isNull);
        if (list.size() == 0)
            return null;

        // 组装Exists查询
        FieldBean.ExistsFieldBean existsFieldBean = new FieldBean.ExistsFieldBean();
        existsFieldBean.setJoinClz(joinProperty.getClz());
        existsFieldBean.setJoinName(joinProperty.getName());
        existsFieldBean.setForeignClz(foreignProperty.getClz());
        existsFieldBean.setForeignName(foreignProperty.getName());

        existsFieldBean.setFieldBeans(list);

        FieldBean fieldBean = new FieldBean();
        fieldBean.setQueryType(QueryType.NOT_EXISTS);
        fieldBean.setExistsFieldBean(existsFieldBean);
        return fieldBean;
    }

    @SafeVarargs
    public static <T extends BaseModel> FieldBean asc(Property<T, ?>... properties) {
        if (properties == null || properties.length == 0)
            throw new EasysqlException("Must set a sort field");

        FieldBean fieldBean = new FieldBean();
        fieldBean.setName("order_by_asc");
        fieldBean.setQueryType(QueryType.ASC);
        fieldBean.setValue(Stream.of(properties).map(Property::getName).collect(Collectors.toList()));
        return fieldBean;
    }

    @SafeVarargs
    public static <T extends BaseModel> FieldBean desc(Property<T, ?>... properties) {
        if (properties == null || properties.length == 0)
            throw new EasysqlException("Must set a sort field");

        FieldBean fieldBean = new FieldBean();
        fieldBean.setName("order_by_desc");
        fieldBean.setQueryType(QueryType.DESC);
        fieldBean.setValue(Stream.of(properties).map(Property::getName).collect(Collectors.toList()));
        return fieldBean;
    }

    /**
     * 查询指定字段
     */
    @SafeVarargs
    public static <T extends BaseModel> FieldBean attr(Property<T, ?>... properties) {
        return attr(new ArrayList<>(Arrays.asList(properties)));
    }

    public static FieldBean attr(List<Property<?, ?>> properties) {
        if (properties == null || properties.size() == 0)
            throw new EasysqlException("Must set a query field");

        FieldBean fieldBean = new FieldBean();
        fieldBean.setName("field");
        fieldBean.setType(ArrayList.class);
        fieldBean.setQueryType(QueryType.FIELD);
        fieldBean.setValue(properties.stream().map(Property::getName).collect(Collectors.toList()));
        // 默认添加Id
        //noinspection unchecked
        List<String> value = ((List<String>) fieldBean.getValue());
        if (!value.contains("id")) value.add(0, "id");
        return fieldBean;
    }

    /**
     * 修改指定字段
     */
    public static <T extends BaseModel> FieldBean attr(Property<T, ?> property, Object val) {
        return warp(property, val, QueryType.UPDATE);
    }

    public static FieldBean id(Long id) {
        if (id == null) {
            throw new EasysqlException("Id can't be null");
        }
        FieldBean fieldBean = new FieldBean();
        fieldBean.setName("id");
        fieldBean.setValue(id);
        fieldBean.setType(id.getClass());
        fieldBean.setQueryType(QueryType.EQ);
        return fieldBean;
    }

    public static <T extends BaseModel> FieldBean id(Collection<Long> val) {
        return id(val, true);
    }

    /**
     * 通过id查询记录
     * ids = []     nullable = true : where id in (-11111)
     * ids = [0, 1] nullable = true : where id in (-11111, 0, 1)
     *
     * ids = []     nullable = false: null
     * ids = [0, 1] nullable = false: where id in (0, 1)
     *
     * @param ids       主键
     * @param notnull   是否允许空值
     */
    public static <T extends BaseModel> FieldBean id(Collection<Long> ids, boolean notnull) {
        if (!notnull && CollectionUtils.isEmpty(ids)) return null;
        if (ids == null) ids = new ArrayList<>();
        ids = ids.stream().filter(Objects::nonNull).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(ids)) ids.add(-11111L);
        return in(BaseModel::getId, ids);
    }

    public static FieldBean pageSize(Integer val) {
        val = null == val ? 1 : val;
        FieldBean fieldBean = new FieldBean();
        fieldBean.setName("pageSize");
        fieldBean.setType(val.getClass());
        fieldBean.setValue(val);
        fieldBean.setQueryType(QueryType.PAGE_SIZE);
        return fieldBean;
    }

    public static FieldBean pageIndex(Integer val) {
        val = null == val ? 10 : val;
        FieldBean fieldBean = new FieldBean();
        fieldBean.setName("pageIndex");
        fieldBean.setType(val.getClass());
        fieldBean.setValue(val);
        fieldBean.setQueryType(QueryType.PAGE_INDEX);
        return fieldBean;
    }

    private static <T extends BaseModel> FieldBean warp(Property<T, ?> property, Object val, QueryType queryType) {
        return warp(property.getName(), val, queryType);
    }

    private static <T extends BaseModel> FieldBean warp(String name, Object val, QueryType queryType) {
        if (val == null) return null;

        FieldBean fieldBean = new FieldBean();
        fieldBean.setName(name);
        fieldBean.setType(val.getClass());
        fieldBean.setValue(val);
        fieldBean.setQueryType(queryType);
        return fieldBean;
    }

    /**
     * 数组转FieldBeans
     * Object[] arr = {"a", 1, "b", 2}
     *      ->
     * fieldBean1:
     *      name = a
     *      value = 1
     * fieldBean2:
     *      name = b
     *      value = 2
     */
    public static List<FieldBean> array2FieldBeans(Object... params) {
        @SuppressWarnings("unchecked")
        Map<String, Object> map = BeanMapper.map(params, Map.class);
        return map2FieldBeans(map);
    }

    /**
     * 对象转FieldBeans
     * user{a = 1, b = 2}
     *      ->
     * fieldBean1:
     *      name = a
     *      value = 1
     * fieldBean2:
     *      name = b
     *      value = 2
     */
    public static List<FieldBean> object2FieldBeans(Object param) {
        @SuppressWarnings("unchecked")
        Map<String, Object> map = BeanMapper.map(param, Map.class);
        return map2FieldBeans(map);
    }

    /**
     * Map转FieldBeans
     * user{a = 1, b = 2}
     *      ->
     * fieldBean1:
     *      name = a
     *      value = 1
     * fieldBean2:
     *      name = b
     *      value = 2
     */
    private static List<FieldBean> map2FieldBeans(Map<String, Object> map) {
        List<FieldBean> fieldBeans = new ArrayList<>();
        for (String key : map.keySet()) {
            if (map.get(key) == null) continue;

            // 如果是FieldBean类型则直接添加
            if (map.get(key).getClass() == FieldBean.class) {
                fieldBeans.add((FieldBean) map.get(key));
                continue;
            }

            // 如果是List<FieldBean>类型则直接添加
            if (ReflectUtils.isCollectionType(map.get(key).getClass())) {
                @SuppressWarnings("rawtypes")
                List values = (List) map.get(key);
                if (values.size() > 0 && values.get(0).getClass() == FieldBean.class) {
                    //noinspection unchecked
                    fieldBeans.addAll(values);
                }
            }

            /*
             * 特殊类型：ATTR，查询指定字段
             */
            if ("attr".equals(key)) {
                @SuppressWarnings("unchecked")
                FieldBean bean = attr((List<Property<?, ?>>) map.get(key));
                fieldBeans.add(bean);
                continue;
            }
            /*
             * 特殊类型：PAGE_SIZE，查询分页大小
             */
            if ("pageSize".equals(key)) {
                FieldBean bean = new FieldBean();
                bean.setType(Integer.class);
                bean.setName("pageSize");
                bean.setValue(map.get(key));
                bean.setQueryType(QueryType.PAGE_SIZE);
                fieldBeans.add(bean);
                continue;
            }
            /*
             * 特殊类型：PAGE_INDEX，查询分页码数
             */
            if ("pageIndex".equals(key)) {
                FieldBean bean = new FieldBean();
                bean.setType(Integer.class);
                bean.setName("pageIndex");
                bean.setValue(map.get(key));
                bean.setQueryType(QueryType.PAGE_INDEX);
                fieldBeans.add(bean);
                continue;
            }

            /*
             * 类不存在此字段的，忽略
             */




            /*
             * 普通类型
             */
            FieldBean bean = new FieldBean();
            bean.setName(key);
            bean.setType(map.get(key).getClass());
            bean.setValue(map.get(key));
            bean.setQueryType(QueryType.EQ);
            fieldBeans.add(bean);

            for (QueryType type : QueryType.values()) {
                if (key.endsWith(type.key)) {
                    bean.setName(bean.getName().substring(0, bean.getName().lastIndexOf(type.key)));
                    bean.setQueryType(type);
                    break;
                }
            }
        }

        return fieldBeans;
    }

    /**
     * fieldBeans转成描述性文字，以便排除错误
     */
    public static String fieldBeansToString(Collection<FieldBean> fieldBeans) {
        if (fieldBeans == null) return null;
        StringBuilder sb = new StringBuilder();
        for (FieldBean fieldBean : fieldBeans) {
            // 分页查询pageSize，pageIndex没有queryType
            if (fieldBean.getQueryType() == null) continue;
            if ("isDeleted".equals(fieldBean.getName())) continue;
            if (fieldBean.getQueryType() == QueryType.FIELD) continue;
            if (fieldBean.getQueryType() == QueryType.ASC) continue;
            if (fieldBean.getQueryType() == QueryType.DESC) continue;
            if (fieldBean.getQueryType() == QueryType.EXISTS) {
                // exists(firstCateId, like(name, 888))
                sb.append(String.format("%s(%s, %s), ",
                                        fieldBean.getQueryType().name,
                                        fieldBean.getExistsFieldBean().getForeignName(),
                                        fieldBeansToString(fieldBean.getExistsFieldBean().getFieldBeans())));
            } else {
                // eq(id, 1237606952704409600)
                sb.append(String.format("%s(%s, %s), ",
                                        fieldBean.getQueryType().name,
                                        fieldBean.getName(),
                                        fieldBean.getValue()));
            }
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
            sb.deleteCharAt(sb.length() - 1);
        }
        return sb.toString();
    }

    public enum QueryType {
        /**
         * 属性名后面拼接NotEq
         */
        NOT_EQ("NotEq", "notEq"),

        /**
         * 属性名后面拼接Eq
         */
        EQ("Eq", "eq"),
        /**
         * 属性名后面拼接NotLike
         */
        NOT_LIKE("NotLike", "notLike"),
        /**
         * 属性名后面拼接Like
         */
        LIKE("Like", "like"),

        /**
         * 属性名后面拼接GT 大于
         */
        GT("Gt", "gt"),
        /**
         * >= 查询, a >= b
         * 属性名后面拼接GE 大于等于
         */
        GE("Ge", "ge"),
        /**
         * 属性名后面拼接LT 小于
         */
        LT("Lt", "lt"),
        /**
         * 属性名后面拼接LE 小于等于
         */
        LE("Le", "le"),
        /**
         * 属性名后面拼接Null 属性值为Boolean
         */
        IS_NULL("IsNull", "isNull"),

        /**
         * 属性名后面拼接NotNull 属性值为Boolean
         */
        NOT_NULL("NotNull", "notNull"),
        /**
         * 属性名后面拼接NotIn 属性值为数组或者以逗号(,)分隔的字符串
         */
        NOT_IN("NotIn", "notIn"),
        /**
         * 属性名后面拼接In 属性值为数组或者以逗号(,)分隔的字符串
         */
        IN("In", "in"),
        /**
         * 属性名后面拼接OR
         */
        OR("Or", "or"),
        /**
         * 包括查询
         * 相当于在外包买一个括号
         * or(a = 1 and (a = 2 and b = c))
         */
        AND("And", "and"),

        NOT_EXISTS("NotExists", "notExists"),
        /**
         * 连表查询
         * 判断第三方表是否存在
         * and exists (select 1 from biz_goods where id = 2)
         */

        EXISTS("Exists", "exists"),

        /**
         * 判断2个集合是否有交集
         * SELECT JSON_OVERLAPS('[1, 2, 3]', '[3, 4, 5]') > 0
         */
        OVERLAPS("Overlaps", "overlaps"),

        /**
         * 判断2个集合是否没有交集
         * SELECT JSON_OVERLAPS('[1, 2, 3]', '[3, 4, 5]') = 0
         */
        NOT_OVERLAPS("NotOverlaps", "notOverlaps"),


        /**
         * 判断一个元素是否存在于集合中
         * select *
         * from biz_tenant
         * where JSON_CONTAINS(domains, JSON_QUOTE('aa'), '$')
         * 1. domains = ["a", "b", "c"]
         */
        CONTAINS("Contains", "contains"),

        /**
         * 判断一个元素是否存在于集合中
         * select *
         * from biz_tenant
         * where JSON_CONTAINS(domains, JSON_QUOTE('aa'), '$')
         * 1. domains = ["a", "b", "c"]
         */
        NOT_CONTAINS("Contains", "Contains"),

        /**
         * 属性名后面拼接ASC 属性值为Boolean
         */
        ASC("Asc", "asc"),

        /**
         * 属性名后面拼接DESC 属性值为Boolean
         */
        DESC("Desc", "desc"),

        /**
         * 修改操作
         */
        UPDATE("Attr", "attr"),

        /**
         * 查询操作（限定查询字段）
         */
        FIELD("Attr", "attr"),

        /**
         * 分页大小
         */
        PAGE_SIZE("pageSize", "pageSize"),

        /**
         * 分页索引
         */
        PAGE_INDEX("pageIndex", "pageIndex");

        public String key;

        public String name;

        QueryType(String key, String name) {
            this.key = key;
            this.name = name;
        }
    }
}
