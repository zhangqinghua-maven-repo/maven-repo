//package org.easyframework.easysql.model;
//
//public class PageParam {
//
//    /**
//     * 每页大小，默认10
//     */
//    private Integer pageSize = 10;
//
//    /**
//     * 第几页，默认第一页
//     */
//    private Integer pageIndex = 1;
//
//    public PageParam() {
//    }
//
//
//    public PageParam(Integer pageSize) {
//        this.pageSize = pageSize;
//    }
//
//    public PageParam(Integer pageSize, Integer pageIndex) {
//        this.pageSize = pageSize;
//        this.pageIndex = pageIndex;
//    }
//
//    public Integer getPageSize() {
//        return pageSize;
//    }
//
//    public void setPageSize(Integer pageSize) {
//        this.pageSize = pageSize;
//    }
//
//    public Integer getPageIndex() {
//        return pageIndex;
//    }
//
//    public void setPageIndex(Integer pageIndex) {
//        this.pageIndex = pageIndex;
//    }
//}
