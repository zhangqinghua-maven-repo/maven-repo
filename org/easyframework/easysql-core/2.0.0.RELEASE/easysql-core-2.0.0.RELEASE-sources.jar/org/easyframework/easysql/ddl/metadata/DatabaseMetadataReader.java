package org.easyframework.easysql.ddl.metadata;

import org.easyframework.easysql.ddl.dialect.DatabaseDialect;
import org.easyframework.easysql.ddl.model.ColumnMeta;
import org.easyframework.easysql.ddl.model.TableMeta;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 读取数据库现有结构，并将不同数据库的 metadata 结果标准化为 TableMeta。
 */
public class DatabaseMetadataReader {

    private final JdbcTemplate jdbcTemplate;
    private final DatabaseDialect dialect;

    public DatabaseMetadataReader(JdbcTemplate jdbcTemplate, DatabaseDialect dialect) {
        this.jdbcTemplate = jdbcTemplate;
        this.dialect = dialect;
    }

    public Map<String, TableMeta> readTables() {
        String schema = jdbcTemplate.execute((ConnectionCallback<String>) conn -> {
            String currentSchema = conn.getSchema();
            return StringUtils.hasText(currentSchema) ? currentSchema : conn.getCatalog();
        });
        if (!StringUtils.hasText(schema)) {
            throw new IllegalStateException("Cannot determine current database schema/catalog for DDL metadata query");
        }

        String sql = dialect.metadataQuery().replace("${table_schema}", schema);
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
        Map<String, List<Map<String, Object>>> groupedRows = rows.stream()
                .collect(Collectors.groupingBy(row -> row.get("table_name") + ""));

        Map<String, TableMeta> tables = new HashMap<>();
        for (Map.Entry<String, List<Map<String, Object>>> entry : groupedRows.entrySet()) {
            List<ColumnMeta> columns = new ArrayList<>();
            for (Map<String, Object> row : entry.getValue()) {
                columns.add(toColumnMeta(row));
            }
            tables.put(entry.getKey(), new TableMeta(entry.getKey(), columns));
        }
        return tables;
    }

    private ColumnMeta toColumnMeta(Map<String, Object> row) {
        String name = row.get("column_name") + "";
        String notnull = "YES".equals(row.get("is_nullable")) ? "" : "NOT NULL";
        if ("id".equals(name)) {
            notnull = "";
        }

        String rawComment = row.get("column_comment") == null ? "" : row.get("column_comment") + "";
        String comment = StringUtils.hasText(rawComment) ? "COMMENT '" + rawComment + "'" : "";

        return new ColumnMeta(
                name,
                dialect.normalizeColumnType(row.get("column_type") + ""),
                notnull,
                dialect.normalizeColumnDefault(row.get("column_default") == null ? null : row.get("column_default") + ""),
                comment,
                dialect.isIndexed(row.get("column_key")));
    }
}
