package org.easyframework.easysql.ddl.parser;

import org.easyframework.easysql.annotations.Column;
import org.easyframework.easysql.ddl.dialect.DatabaseDialect;
import org.easyframework.easysql.ddl.model.ColumnMeta;
import org.easyframework.easysql.ddl.model.TableMeta;
import org.easyframework.easysql.ddl.util.SQLUtils;
import org.easyframework.easyutils.ReflectUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class TableModitor {

    /**
     * 比较实体类和数据表之间的差异，生成相应的 ALTER 语句。
     */
    public static String parse(Class<?> clz, TableMeta table, DatabaseDialect dialect) {
        StringBuilder alter = new StringBuilder();
        String tableName = SQLUtils.toTableName(clz.getSimpleName());
        List<ColumnMeta> tableColumns = table.columns();
        List<Field> fields = ReflectUtils.fields(clz).stream()
                .filter(f -> f.getAnnotation(Column.class) != null)
                .collect(Collectors.toList());

        // 1. 新增的字段
        for (Field field : fields.stream()
                .filter(f -> !table.hasColumn(SQLUtils.toColumnName(f.getName())))
                .collect(Collectors.toList())) {
            Column column = field.getAnnotation(Column.class);
            if (column == null) continue;
            alter.append("ALTER TABLE ").append(dialect.quote(tableName))
                 .append(" ADD ").append(ColumnParser.parse(field, column, dialect)).append(";\n");
            // PG 需独立 COMMENT ON COLUMN 语句
            if (!column.comment().isEmpty()) {
                String commentStmt = dialect.commentOnColumn(
                        dialect.quote(tableName),
                        dialect.quote(SQLUtils.toColumnName(field.getName())),
                        column.comment());
                if (!commentStmt.isEmpty()) {
                    alter.append(commentStmt).append(";\n");
                }
            }
        }

        // 2. 移除的字段
        for (ColumnMeta column : tableColumns.stream()
                .filter(t -> fields.stream().noneMatch(
                        f -> t.name().equals(SQLUtils.toColumnName(f.getName()))))
                .collect(Collectors.toList())) {
            if (column.deprecated()) {
                continue;
            }
            // 字段已从实体移除：1）允许为空  2）注释加"已废弃"
            appendStatement(alter, dialect.alterColumn(
                    dialect.quote(tableName),
                    dialect.quote(column.name()),
                    column.type(),   // 保持原类型不变
                    "",              // 去掉 NOT NULL
                    column.def(),     // 保持原默认值不变
                    column.deprecatedComment()));
        }

        // 3. 修改的字段
        for (Field f : fields) {
            for (ColumnMeta t : tableColumns) {
                if (!t.name().equals(SQLUtils.toColumnName(f.getName()))) continue;
                Column c = f.getAnnotation(Column.class);
                if (c == null) continue;

                String type = ColumnParser.type(f, c, dialect);
                String notnull = ColumnParser.notnull(c);
                String def = ColumnParser.def(f, c, dialect);
                String comment = ColumnParser.comment(c);

                if (type.equals(t.type()) && notnull.equals(t.notnull())
                        && def.equals(t.def()) && comment.equals(t.comment())) {
                    continue;
                }
                appendStatement(alter, dialect.alterColumn(
                        dialect.quote(tableName),
                        dialect.quote(SQLUtils.toColumnName(f.getName())),
                        type, notnull, def, comment));
                break;
            }
        }

        // 4. 新增或删除索引
        for (Field f : fields) {
            Column column = f.getAnnotation(Column.class);
            if (column == null) continue;
            String columnName = SQLUtils.toColumnName(f.getName());
            String indexName = SQLUtils.indexName(tableName, columnName);
            boolean oldHasIndex = tableColumns.stream()
                    .filter(tc -> tc.name().equals(columnName))
                    .map(ColumnMeta::indexed)
                    .findAny().orElse(false);

            if (column.index() && !oldHasIndex) {
                alter.append(dialect.createIndex(
                        dialect.quote(tableName),
                        dialect.quote(indexName),
                        dialect.quote(columnName))).append(";\n");
            }
            if (!column.index() && oldHasIndex) {
                alter.append(dialect.dropIndex(
                        dialect.quote(tableName),
                        dialect.quote(indexName))).append(";\n");
            }
        }

        return alter.toString();
    }

    private static void appendStatement(StringBuilder target, String ddl) {
        String statement = ddl.stripTrailing();
        target.append(statement);
        if (!statement.endsWith(";")) target.append(';');
        target.append('\n');
    }

    public static String parse(Class<?> clz, List<Map<String, String>> tableColumns, DatabaseDialect dialect) {
        String tableName = SQLUtils.toTableName(clz.getSimpleName());
        List<ColumnMeta> columns = tableColumns.stream()
                .map(TableModitor::toColumnMeta)
                .collect(Collectors.toList());
        return parse(clz, new TableMeta(tableName, columns), dialect);
    }

    private static ColumnMeta toColumnMeta(Map<String, String> column) {
        return new ColumnMeta(
                column.getOrDefault("name", ""),
                column.getOrDefault("type", ""),
                column.getOrDefault("notnull", ""),
                column.getOrDefault("def", ""),
                column.getOrDefault("comment", ""),
                Boolean.parseBoolean(column.getOrDefault("key", "false")));
    }

    public static List<Map<String, String>> tableColumns(String ddl) {
        List<Map<String, String>> columns = new ArrayList<>();
        // 每一个字段的定义
        String[] columnLines = ddl.substring(ddl.indexOf("(\n") + 2, ddl.indexOf("\n  PRIMARY KEY ")).split("\n");
        for (String columnLine : columnLines) {
            Map<String, String> column = new HashMap<>();
            column.put("ddl", columnLine);
            column.put("name", ColumnParser.name(columnLine));
            column.put("type", ColumnParser.type(columnLine));
            column.put("notnull", ColumnParser.notnull(columnLine));
            column.put("def", ColumnParser.def(columnLine));
            column.put("comment", ColumnParser.comment(columnLine));
            columns.add(column);
        }
        return columns;
    }
}
