package org.easyframework.easysql.ddl.parser;

import org.easyframework.easysql.annotations.Column;
import org.easyframework.easysql.ddl.dialect.DatabaseDialect;
import org.easyframework.easysql.ddl.util.SQLUtils;

import java.lang.reflect.Field;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 表字段工具
 */
public class ColumnParser {

    /**
     * f -> DDL 片段
     * <p>
     * order_no varchar(20) NOT NULL DEFAULT 'xxx' COMMENT '12345'
     */
    public static String parse(Field field, Column column, DatabaseDialect dialect) {
        StringBuilder sb = new StringBuilder();
        sb.append(name(field, dialect)).append(blank(sb.length()))
          .append(type(field, column, dialect));

        String notnull = notnull(column);
        if (!notnull.isEmpty())
            sb.append(" ").append(notnull);

        String def = def(field, column, dialect);
        if (!def.isEmpty())
            sb.append(" ").append(def);

        String comment = dialect.columnComment(column.comment());
        if (!comment.isEmpty())
            sb.append(" ").append(comment);

        return sb.toString();
    }

    /**
     * 列名，带数据库方言引用符
     */
    public static String name(Field f, DatabaseDialect dialect) {
        return dialect.quote(SQLUtils.toColumnName(f.getName()));
    }

    /**
     * 从 DDL 行文本中提取列名（仅用于 MySQL DDL 解析）
     */
    public static String name(String columnLine) {
        Matcher m = columnNamePattern.matcher(columnLine);
        if (m.find()) return m.group(1);
        return "";
    }

    /**
     * 字段类型，委托给 Dialect
     */
    public static String type(Field f, Column c, DatabaseDialect dialect) {
        return dialect.ddlType(f, c);
    }

    // ==================== DDL 解析（从 DDL 文本提取字段信息） ====================

    /**
     * 从 DDL 行文本中提取列名
     */
    private static final Pattern columnNamePattern = Pattern.compile("^\\s\\s`(.*)` ");
    private static final Pattern typePattern = Pattern.compile("`[^`]*`\\s+(\\S+)");
    private static final Pattern notnullPattern = Pattern.compile(" (NOT NULL) ");
    private static final Pattern defPattern = Pattern.compile(" (DEFAULT '.*') ");
    private static final Pattern commentPattern = Pattern.compile(" (COMMENT '.*')");

    public static String type(String columnLine) {
        Matcher m = typePattern.matcher(columnLine);
        if (m.find()) {
            // mediumtext, -> mediumtext
            return m.group(1).replace(",", "");
        }
        return "";
    }

    private static String key(Column c) {
        if (c.key())
            return " PRIMARY KEY";
        return "";
    }

    public static String notnull(Column c) {
        // 是否允许为NULL
        if (!c.nullable())
            return "NOT NULL";
        return "";
    }

    public static String notnull(String columnLine) {
        Matcher m = notnullPattern.matcher(columnLine);
        if (m.find()) {
            return m.group(1);
        }
        return "";
    }

    public static String def(Field f, Column c) {
        String def = "";
        if (!c.def().isEmpty()) {
            def = String.format("DEFAULT '%s'", c.def());

            // 针对浮点型数字类型加小数点：0.00
            // if (c.type() == Type.DOUBLE || (c.type() == Type.NONE && (f.getType() == Double.class || f.getType() == BigDecimal.class))) {
            //     // 0 -> 0.00 MySQL 8.0 不需要这个东西了
            //      if (!def.contains(".")) {
            //          def = String.format("DEFAULT '%s'", c.def() + ".00");
            //      }
            // }
        }

        return def;
    }

    public static String def(Field f, Column c, DatabaseDialect dialect) {
        return dialect.columnDefault(f, c);
    }

    public static String def(String columnLine) {
        Matcher m = defPattern.matcher(columnLine);
        if (m.find()) {
            return m.group(1);
        }
        return "";
    }

    public static String comment(Column c) {
        if (!c.comment().equals(""))
            return String.format("COMMENT '%s'", c.comment());
        return "";
    }


    public static String comment(String columnLine) {
        Matcher m = commentPattern.matcher(columnLine);
        if (m.find()) {
            return m.group(1);
        }
        return "";
    }

    public static String blank(Integer lenght) {
        StringBuilder sb = new StringBuilder();
        for (int i = lenght; i < 20; i++) {
            sb.append(" ");
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        System.out.println(type("  `chat_item_id` bigint NOT NULL COMMENT '对话记录Id',"));
        System.out.println(type("  `messages_json` mediumtext,"));
        System.out.println(type("  `modifier` varchar(32) NOT NULL DEFAULT 'sys' COMMENT '修改者',"));
    }
}
