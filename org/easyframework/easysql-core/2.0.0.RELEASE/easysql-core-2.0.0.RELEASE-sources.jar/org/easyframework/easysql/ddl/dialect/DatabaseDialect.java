package org.easyframework.easysql.ddl.dialect;

import org.easyframework.easysql.annotations.Column;
import org.easyframework.easysql.annotations.Table;

import java.lang.reflect.Field;

/**
 * 数据库方言接口，封装不同数据库（MySQL/PostgreSQL）的 SQL 差异。
 * <p>
 * 运行时通过 {@link java.sql.DatabaseMetaData#getDatabaseProductName()} 自动检测，
 * 选择对应的 {@link MySQLDialect} 或 {@link PostgreSQLDialect} 实现。
 */
public interface DatabaseDialect {

    /**
     * 标识符引用。
     * MySQL:  `name` → PostgreSQL: "name"
     */
    String quote(String identifier);

    /**
     * 将 Java 字段 + {@link Column} 注解映射为数据库 DDL 类型字符串。
     * 例如 MySQL 返回 "VARCHAR(255)"，PostgreSQL 返回 "VARCHAR(255)"。
     */
    String ddlType(Field field, Column column);

    /**
     * 将实体注解中的默认值转换为当前数据库的列 DEFAULT 片段。
     * 默认按字符串字面量处理；布尔值等方言差异由具体数据库覆盖。
     */
    default String columnDefault(Field field, Column column) {
        if (column.def().isEmpty()) return "";
        return "DEFAULT '" + column.def() + "'";
    }

    /**
     * 建表时的表级选项。
     * MySQL: "ENGINE=InnoDB CHARSET=utf8mb4" → PostgreSQL: ""（不需要）
     */
    String tableOptions(Table tableAnno);

    /**
     * 建表时的表注释。
     * MySQL: 内联 COMMENT = 'xxx' → PostgreSQL: 返回空（PG 用单独的 COMMENT ON 语句）
     */
    String tableComment(String comment);

    /**
     * 列定义中的内联注释片段。
     * MySQL: "COMMENT 'xxx'" → PostgreSQL: ""（PG 不支持内联列注释）
     */
    String columnComment(String comment);

    /**
     * 独立的列注释 DDL 语句（用于 CREATE TABLE 之后或 ALTER TABLE 之后）。
     * MySQL: ""（已在列定义中内联） → PostgreSQL: "COMMENT ON COLUMN \"table\".\"col\" IS 'xxx'"
     *
     * @param quotedTable 已 quote 的表名
     * @param quotedColumn 已 quote 的列名
     * @param comment 注释文本
     */
    String commentOnColumn(String quotedTable, String quotedColumn, String comment);

    /**
     * 独立的表注释 DDL 语句（用于 CREATE TABLE 之后）。
     * MySQL: ""（已在表定义中内联 COMMENT = 'xxx'） → PostgreSQL: "COMMENT ON TABLE \"table\" IS 'xxx'"
     *
     * @param quotedTable 已 quote 的表名
     * @param comment 注释文本
     */
    String commentOnTable(String quotedTable, String comment);

    /**
     * 是否支持在 CREATE TABLE 中定义普通索引。
     * MySQL 支持内联 KEY，PostgreSQL 需要在建表后单独执行 CREATE INDEX。
     */
    default boolean supportsInlineIndex() {
        return true;
    }

    /**
     * 建表时的内联索引片段。
     * MySQL: "KEY idx_name (col)" → PostgreSQL: 返回空（PG 需单独 CREATE INDEX）
     *
     * @param quotedTable 已 quote 的表名
     * @param indexName   索引名
     * @param quotedCol   已 quote 的列名
     */
    String indexFragment(String quotedTable, String indexName, String quotedCol);

    /**
     * SQL 函数：空值替换。
     * MySQL: IFNULL(expr, def) → PostgreSQL: COALESCE(expr, def)
     */
    String ifNull(String expr, String defaultValue);

    /**
     * JSON 包含判断。
     * MySQL: JSON_CONTAINS(col, JSON_QUOTE('val'), '$')
     * PostgreSQL: col @> to_jsonb('val'::text)
     */
    String jsonContains(String column, String value);

    /**
     * JSON 交集判断。
     * MySQL: JSON_OVERLAPS(col, '[...]')
     * PostgreSQL: col ?| array['a','b']
     */
    String jsonOverlaps(String column, String value);

    /**
     * 分页子句。
     * MySQL: LIMIT offset, size → PostgreSQL: LIMIT size OFFSET offset
     */
    String limitClause(long offset, long size);

    /**
     * 获取 information_schema 查询 SQL，用于读取数据库现有表结构。
     * 参数 ${table_schema} 会被替换为实际数据库名。
     */
    String metadataQuery();

    /**
     * 判断 information_schema.columns 中的 column_key 值是否表示"有索引"。
     * MySQL: "MUL" 表示有索引 → PostgreSQL: 需关联查 pg_indexes
     */
    boolean isIndexed(Object columnKeyValue);

    /**
     * 生成修改列的 ALTER 语句。
     * MySQL: ALTER TABLE t MODIFY COLUMN col type NOT NULL DEFAULT 'x' COMMENT 'x'
     * PostgreSQL: 多个语句用 ;\n 拼接（ALTER COLUMN TYPE / SET NOT NULL / SET DEFAULT + COMMENT ON COLUMN）
     *
     * @param quotedTable 已 quote 的表名
     * @param quotedCol   已 quote 的列名
     * @param type        列类型
     * @param notnull     NOT NULL 或空
     * @param def         DEFAULT 'xxx' 或空
     * @param comment     COMMENT 'xxx' 或空
     */
    String alterColumn(String quotedTable, String quotedCol, String type, String notnull, String def, String comment);

    /**
     * 生成仅修改列注释的语句（用于标记废弃字段）。
     * MySQL: ALTER TABLE t MODIFY COLUMN col ... COMMENT 'xxx'
     * PostgreSQL: COMMENT ON COLUMN t.col IS 'xxx'
     */
    String alterColumnComment(String quotedTable, String quotedCol, String type, String def, String comment);

    /**
     * 创建索引。
     * MySQL: ALTER TABLE t ADD INDEX idx (col)
     * PostgreSQL: CREATE INDEX idx ON t (col)
     */
    String createIndex(String quotedTable, String indexName, String quotedCol);

    /**
     * 删除索引。
     * MySQL: DROP INDEX idx ON t
     * PostgreSQL: DROP INDEX IF EXISTS idx
     */
    String dropIndex(String quotedTable, String indexName);

    /**
     * 将数据库原生列类型标准化为框架统一格式，用于与实体定义做等值比较。
     * PG: "TIMESTAMP WITHOUT TIME ZONE" → "TIMESTAMP"
     * MySQL: 原样返回
     */
    default String normalizeColumnType(String dbType) {
        return dbType;
    }

    /**
     * 将数据库原生默认值标准化为框架统一格式（DEFAULT 'xxx'），用于与实体定义做等值比较。
     * PG: "'sys'::character varying" → "DEFAULT 'sys'"
     * MySQL: "'sys'" → "DEFAULT 'sys'"
     */
    default String normalizeColumnDefault(String dbDefault) {
        if (dbDefault == null || dbDefault.isEmpty()) return "";
        return "DEFAULT " + dbDefault;
    }
}
