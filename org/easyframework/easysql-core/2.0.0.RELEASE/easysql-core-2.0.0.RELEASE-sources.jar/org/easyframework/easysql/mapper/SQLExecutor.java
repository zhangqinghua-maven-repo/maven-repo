package org.easyframework.easysql.mapper;

import org.easyframework.easysql.model.BaseModel;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 简化下游项目执行自定义 SQL 的入口。
 *
 * <p>普通实体或 DTO 查询可以直接传入结果类型；复杂投影则可以传入自己的
 * {@link RowMapper}。参数始终通过 JDBC 占位符或命名参数绑定，不要直接拼接用户输入。</p>
 */
@Service
public class SQLExecutor {

    private final JdbcTemplate jdbcTemplate;
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public SQLExecutor(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = Objects.requireNonNull(jdbcTemplate, "jdbcTemplate must not be null");
        this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(this.jdbcTemplate);
    }

    /**
     * 查询一条实体/DTO。没有结果时返回 {@code null}，多条结果时取第一条。
     */
    public <T> T selectOne(String sql, Object params, Class<T> resultType) {
        List<T> results = selectList(sql, params, resultType);
        return results.isEmpty() ? null : results.get(0);
    }

    /**
     * 查询实体/DTO列表。
     */
    public <T> List<T> selectList(String sql, Object params, Class<T> resultType) {
        return selectList(sql, params, rowMapper(resultType));
    }

    /**
     * 使用 Map 或 JavaBean 参数和 {@code @if} 条件查询，并使用自定义 RowMapper 映射结果。
     * 支持 {@code isNull}、{@code notNull}、{@code isEmpty}、{@code notEmpty} 四种判断。
     */
    public <T> List<T> selectList(String sql, Object params, RowMapper<T> rowMapper) {
        Map<String, ?> actualParams = actualParams(params);
        String renderedSql = renderSql(sql, actualParams);
        Objects.requireNonNull(rowMapper, "rowMapper must not be null");
        return executeNamed(renderedSql, actualParams,
                false, () -> namedParameterJdbcTemplate.query(renderedSql, actualParams, rowMapper));
    }

    /** 使用 Map 或 JavaBean 参数查询一条记录。没有结果时返回 {@code null}。 */
    public <T> T selectOne(String sql, Object params, RowMapper<T> rowMapper) {
        List<T> results = selectList(sql, params, rowMapper);
        return results.isEmpty() ? null : results.get(0);
    }

    /**
     * 查询一条 Map 记录。没有结果时返回 {@code null}。
     */
    public Map<String, Object> selectOneMap(String sql, Object params) {
        List<Map<String, Object>> results = selectListMap(sql, params);
        return results.isEmpty() ? null : results.get(0);
    }

    /**
     * 查询 Map 列表，适合临时表结构或不值得专门创建 DTO 的查询。
     */
    public List<Map<String, Object>> selectListMap(String sql, Object params) {
        Map<String, ?> actualParams = actualParams(params);
        String renderedSql = renderSql(sql, actualParams);
        return executeNamed(renderedSql, actualParams,
                false, () -> namedParameterJdbcTemplate.queryForList(renderedSql, actualParams));
    }

    /**
     * 查询单个标量值，例如 COUNT、SUM 或数据库函数结果。
     */
    public <T> T selectValue(String sql, Object params, Class<T> resultType) {
        Map<String, ?> actualParams = actualParams(params);
        String renderedSql = renderSql(sql, actualParams);
        return executeNamed(renderedSql, actualParams,
                false, () -> namedParameterJdbcTemplate.queryForObject(renderedSql, actualParams, resultType));
    }

    /**
     * 执行 INSERT、UPDATE、DELETE，返回受影响的行数。
     */
    public int update(String sql, Object params) {
        Map<String, ?> actualParams = actualParams(params);
        String renderedSql = renderSql(sql, actualParams);
        return executeNamed(renderedSql, actualParams,
                true, () -> namedParameterJdbcTemplate.update(renderedSql, actualParams));
    }

    /**
     * 执行无返回值的 DDL 或其他数据库语句。
     */
    public void execute(String sql) {
        requireSql(sql);
        execute(sql, new Object[0], true, () -> {
            jdbcTemplate.execute(sql);
            return null;
        });
    }

    /** 使用 Map 或 JavaBean 参数执行 DDL 或其他无返回值语句。 */
    public void execute(String sql, Object params) {
        Map<String, ?> actualParams = actualParams(params);
        String renderedSql = renderSql(sql, actualParams);
        executeNamed(renderedSql, actualParams, true, () -> {
            namedParameterJdbcTemplate.getJdbcOperations().execute(renderedSql);
            return null;
        });
    }

    private <T> RowMapper<T> rowMapper(Class<T> resultType) {
        Objects.requireNonNull(resultType, "resultType must not be null");

        // BaseModel/带 @Column 的实体复用 EasySQL 的字段转换和 JSON 处理；
        // 普通下游 DTO 使用 Spring 的 camelCase/下划线映射。
        if (BaseModel.class.isAssignableFrom(resultType)
                || !EntityMetadata.fields(resultType).isEmpty()) {
            return EntityRowMapper.create(resultType);
        }
        return BeanPropertyRowMapper.newInstance(resultType);
    }

    private <T> T execute(String sql, Object[] params, boolean update, Supplier<T> action) {
        return execute(() -> new SqlLogSession("custom", sql, params), update, action);
    }

    private <T> T executeNamed(String sql, Map<String, ?> params, boolean update, Supplier<T> action) {
        return execute(() -> new SqlLogSession("custom", sql, params), update, action);
    }

    private <T> T execute(Supplier<SqlLogSession> sessionFactory, boolean update, Supplier<T> action) {
        SqlLogSession session = SqlLogSession.isDebugEnabled() ? sessionFactory.get() : null;
        try {
            T result = action.get();
            if (session != null) {
                session.logResult(result, update);
            }
            return result;
        } catch (RuntimeException exception) {
            if (session != null) {
                session.logException(exception);
            }
            throw exception;
        }
    }

    private static void requireSql(String sql) {
        if (sql == null || sql.isBlank()) {
            throw new IllegalArgumentException("sql must not be blank");
        }
    }

    private static Map<String, ?> actualParams(Object params) {
        if (params == null) return Collections.emptyMap();
        if (params instanceof Map<?, ?> source) {
            Map<String, Object> result = new java.util.LinkedHashMap<>();
            source.forEach((key, value) -> {
                if (!(key instanceof String name)) {
                    throw new IllegalArgumentException("SQL parameter map keys must be strings");
                }
                result.put(name, value);
            });
            return result;
        }

        BeanWrapper bean = new BeanWrapperImpl(params);
        Map<String, Object> result = new java.util.LinkedHashMap<>();
        for (var descriptor : bean.getPropertyDescriptors()) {
            String name = descriptor.getName();
            if (!"class".equals(name) && bean.isReadableProperty(name)) {
                result.put(name, bean.getPropertyValue(name));
            }
        }
        return result;
    }

    private static String renderSql(String sql, Map<String, ?> params) {
        requireSql(sql);
        return SqlTemplate.render(sql, actualParams(params));
    }

    /** Lightweight conditional renderer for trusted SQL templates. */
    private static final class SqlTemplate {

        private static final Pattern FUNCTION = Pattern.compile(
                "(?i)^(isNull|notNull|isEmpty|notEmpty)\\s*\\(\\s*([A-Za-z_][A-Za-z0-9_.]*)\\s*\\)$");

        private SqlTemplate() {
        }

        private static String render(String template, Map<String, ?> params) {
            StringBuilder result = new StringBuilder(template.length());
            int cursor = 0;
            while (true) {
                int ifStart = template.indexOf("@if", cursor);
                if (ifStart < 0) {
                    result.append(template, cursor, template.length());
                    return result.toString();
                }

                int openParenthesis = skipWhitespace(template, ifStart + 3);
                if (openParenthesis >= template.length() || template.charAt(openParenthesis) != '(') {
                    throw new IllegalArgumentException("Invalid SQL template: expected '(' after @if");
                }

                int closeParenthesis = findClosingParenthesis(template, openParenthesis);
                if (closeParenthesis < 0) {
                    throw new IllegalArgumentException("Invalid SQL template: missing ')' for @if");
                }

                int openBrace = skipWhitespace(template, closeParenthesis + 1);
                if (openBrace >= template.length() || template.charAt(openBrace) != '{') {
                    throw new IllegalArgumentException("Invalid SQL template: expected '{' after @if condition");
                }

                int closeBlock = findCloseBlock(template, openBrace + 1);
                String condition = template.substring(openParenthesis + 1, closeParenthesis).trim();
                String body = template.substring(openBrace + 1, closeBlock);
                boolean standalone = isStandaloneBlock(template, ifStart, closeBlock + 2);
                if (!standalone) {
                    result.append(template, cursor, ifStart);
                    if (evaluate(condition, params)) {
                        result.append(render(body, params));
                    }
                    cursor = closeBlock + 2;
                    continue;
                }

                // @if/@} 独占一行时，条件不成立要连同控制行一起删除；
                // 条件成立时只保留 body 的实际内容，避免产生空行。
                int lineStart = template.lastIndexOf('\n', ifStart - 1) + 1;
                if (lineStart >= cursor) {
                    result.append(template, cursor, lineStart);
                }
                removeTrailingHorizontalWhitespace(result);
                boolean conditionMatched = evaluate(condition, params);
                if (conditionMatched) {
                    result.append(removeLeadingLineBreak(
                            removeTrailingHorizontalWhitespace(render(body, params))));
                } else {
                    removeBlankLineBefore(result);
                }
                cursor = conditionMatched
                        ? consumeLineBreakAfterBlock(template, closeBlock + 2)
                        : consumeBlankLinesAfterBlock(template, closeBlock + 2);
            }
        }

        private static boolean isStandaloneBlock(String template, int ifStart, int afterBlock) {
            int lineStart = template.lastIndexOf('\n', ifStart - 1) + 1;
            for (int index = lineStart; index < ifStart; index++) {
                if (!Character.isWhitespace(template.charAt(index))) return false;
            }

            int cursor = afterBlock;
            while (cursor < template.length()
                    && (template.charAt(cursor) == ' ' || template.charAt(cursor) == '\t')) {
                cursor++;
            }
            return cursor == template.length()
                    || template.charAt(cursor) == '\n'
                    || template.charAt(cursor) == '\r';
        }

        private static int consumeLineBreakAfterBlock(String template, int start) {
            int cursor = start;
            while (cursor < template.length()
                    && (template.charAt(cursor) == ' ' || template.charAt(cursor) == '\t')) {
                cursor++;
            }
            if (cursor < template.length() && template.charAt(cursor) == '\r') cursor++;
            if (cursor < template.length() && template.charAt(cursor) == '\n') cursor++;
            return cursor;
        }

        private static int consumeBlankLinesAfterBlock(String template, int start) {
            int cursor = start;
            while (cursor < template.length()) {
                int lineStart = cursor;
                while (cursor < template.length()
                        && (template.charAt(cursor) == ' ' || template.charAt(cursor) == '\t')) {
                    cursor++;
                }
                if (cursor < template.length() && template.charAt(cursor) == '\r') cursor++;
                if (cursor < template.length() && template.charAt(cursor) == '\n') {
                    cursor++;
                    continue;
                }
                return lineStart;
            }
            return cursor;
        }

        private static void removeTrailingHorizontalWhitespace(StringBuilder value) {
            while (value.length() > 0) {
                char last = value.charAt(value.length() - 1);
                if (last != ' ' && last != '\t') return;
                value.deleteCharAt(value.length() - 1);
            }
        }

        private static void removeBlankLineBefore(StringBuilder value) {
            int end = value.length();
            while (end > 0 && (value.charAt(end - 1) == ' ' || value.charAt(end - 1) == '\t')) end--;
            if (end > 0 && value.charAt(end - 1) == '\n') {
                value.delete(end - 1, value.length());
            }
        }

        private static String removeTrailingHorizontalWhitespace(String value) {
            int end = value.length();
            while (end > 0 && (value.charAt(end - 1) == ' ' || value.charAt(end - 1) == '\t')) end--;
            return value.substring(0, end);
        }

        private static String removeLeadingLineBreak(String value) {
            if (value.startsWith("\r\n")) return value.substring(2);
            if (value.startsWith("\n") || value.startsWith("\r")) return value.substring(1);
            return value;
        }

        private static int findClosingParenthesis(String template, int openParenthesis) {
            int depth = 0;
            for (int index = openParenthesis; index < template.length(); index++) {
                char current = template.charAt(index);
                if (current == '(') {
                    depth++;
                } else if (current == ')') {
                    depth--;
                    if (depth == 0) return index;
                }
            }
            return -1;
        }

        private static int findCloseBlock(String template, int bodyStart) {
            int depth = 1;
            int cursor = bodyStart;
            while (cursor < template.length()) {
                int nestedIf = template.indexOf("@if", cursor);
                int closeBlock = template.indexOf("@}", cursor);
                if (closeBlock < 0) {
                    throw new IllegalArgumentException("Invalid SQL template: missing '@}'");
                }
                if (nestedIf >= 0 && nestedIf < closeBlock) {
                    depth++;
                    cursor = nestedIf + 3;
                } else {
                    depth--;
                    if (depth == 0) return closeBlock;
                    cursor = closeBlock + 2;
                }
            }
            throw new IllegalArgumentException("Invalid SQL template: missing '@}'");
        }

        private static int skipWhitespace(String value, int start) {
            int cursor = start;
            while (cursor < value.length() && Character.isWhitespace(value.charAt(cursor))) cursor++;
            return cursor;
        }

        private static boolean evaluate(String expression, Map<String, ?> params) {
            Matcher matcher = FUNCTION.matcher(expression);
            if (!matcher.matches()) {
                throw new IllegalArgumentException(
                        "Unsupported SQL condition: " + expression
                                + ". Supported conditions: isNull, notNull, isEmpty, notEmpty");
            }

            Object value = params.get(matcher.group(2));
            boolean empty = isEmpty(value);
            return switch (matcher.group(1).toLowerCase()) {
                case "isempty" -> empty;
                case "notempty" -> !empty;
                case "isnull" -> value == null;
                case "notnull" -> value != null;
                default -> throw new IllegalArgumentException("Unsupported SQL condition: " + expression);
            };
        }

        private static boolean isEmpty(Object value) {
            if (value == null) return true;
            if (value instanceof CharSequence text) return text.toString().trim().isEmpty();
            if (value instanceof Collection<?> collection) return collection.isEmpty();
            if (value instanceof Map<?, ?> map) return map.isEmpty();
            return value.getClass().isArray() && Array.getLength(value) == 0;
        }
    }
}
