package org.easyframework.easysql.model;

import org.easyframework.easyutils.BeanMapper;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;

public class PageData<T> implements Serializable {
    private static final long serialVersionUID = 984181620748996L;
    /**
     * 每页大小
     */
    private int pageSize;

    /**
     * 当前是第几页
     */
    private int pageIndex;

    /**
     * 查询记录总数
     */
    private int totalCount;

    /**
     * 查询记录页数
     */
    private int pageCount;

    /**
     * 记录
     */
    private Collection<T> data;

    /**
     * 扩展信息，比如可以存储像合计、统计这一类的数据
     */
    private Map<String, Object> ext;

    public PageData() {
    }

    public PageData(int totalCount) {
        this.totalCount = totalCount;
    }

    public PageData(int pageCount, int totalCount) {
        this.pageCount = pageCount;
        this.totalCount = totalCount;
    }

    public PageData(int pageCount, int totalCount, Collection<T> data) {
        this.data = data;
        this.pageCount = pageCount;
        this.totalCount = totalCount;
    }

    public PageData(int pageSize, int pageIndex, int pageCount, int totalCount, Collection<T> data) {
        this.data = data;
        this.pageSize = pageSize;
        this.pageIndex = pageIndex;
        this.pageCount = pageCount;
        this.totalCount = totalCount;
    }

    public PageData(PageData<?> pageData, Class<T> clz) {
        this.data = BeanMapper.map(pageData.getData(), clz);
        this.pageSize = pageData.pageSize;
        this.pageIndex = pageData.pageIndex;
        this.pageCount = pageData.pageCount;
        this.totalCount = pageData.totalCount;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public Collection<T> getData() {
        return data;
    }

    public void setData(Collection<T> data) {
        this.data = data;
    }

    public Map<String, Object> getExt() {
        return ext;
    }

    public void setExt(Map<String, Object> ext) {
        this.ext = ext;
    }
}
