package org.easyframework.easysql.config;

import org.easyframework.easysql.annotations.Table;
import org.easyframework.easysql.ddl.dialect.DatabaseDialect;
import org.easyframework.easysql.ddl.dialect.MySQLDialect;
import org.easyframework.easysql.ddl.dialect.PostgreSQLDialect;
import org.easyframework.easysql.ddl.metadata.DatabaseMetadataReader;
import org.easyframework.easysql.ddl.model.TableMeta;
import org.easyframework.easysql.ddl.parser.TableCreator;
import org.easyframework.easysql.ddl.parser.TableModitor;
import org.easyframework.easysql.ddl.util.SQLUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

/**
 * 自动建表配置。
 * <p>
 * 使用 {@link ApplicationRunner} 在 Spring 容器刷新完成后执行数据库初始化，
 * 将 Spring 容器启动与 EasySQL 的数据库连接、方言识别和 DDL 耗时分开。
 * <p>
 * 用户可在 {@code @Configuration} 类的 {@code @PostConstruct} 中动态覆盖配置：
 * <pre>{@code
 * @Configuration
 * @EnableEasySQL
 * public class EasySQLConfig {
 *     &#64;Value("${easysql.scan:*}")
 *     private String scan;
 *     &#64;Value("${easysql.ddl:update}")
 *     private String ddlType;
 *
 *     &#64;PostConstruct
 *     public void init() {
 *         EasySQLDDLConfig.setDdlScan(scan);
 *         EasySQLDDLConfig.setDdlType(ddlType);
 *     }
 * }
 * }</pre>
 */
@Configuration
public class EasySQLDDLConfig {

    private static final Logger log = LoggerFactory.getLogger(EasySQLDDLConfig.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private Environment environment;

    /** 运行时检测到的数据库方言 */
    private DatabaseDialect dialect;

    /**
     * 是否启用自动建表功能（来自 {@code easysql.ddl} 配置，作为默认值）
     */
    @Value("${easysql.ddl:none}")
    private String defaultDdlType;

    /**
     * 扫描哪些表的注解（来自 {@code easysql.scan} 配置，作为默认值）
     */
    @Value("${easysql.scan:*}")
    private String defaultDdlScan;

    /** 用户通过 {@link #setDdlType(String)} 自定义的 DDL 模式，为 null 时使用 @Value 默认值 */
    private static volatile String customDdlType = null;
    /** 用户通过 {@link #setDdlScan(String)} 自定义的扫描路径，为 null 时使用 @Value 默认值 */
    private static volatile String customDdlScan = null;

    // ==================== 静态配置入口（供外部 @Configuration 调用） ====================

    /**
     * 动态设置 DDL 自动建表模式（none / create / update）。
     * 在 {@code @PostConstruct} 中调用即可覆盖 {@code easysql.ddl} 默认值。
     */
    public static void setDdlType(String type) {
        customDdlType = type;
    }

    /**
     * 动态设置 DDL 实体扫描路径。
     * 在 {@code @PostConstruct} 中调用即可覆盖 {@code easysql.scan} 默认值。
     */
    public static void setDdlScan(String scan) {
        customDdlScan = scan;
    }

    /** 获取最终的 DDL 模式：自定义值优先，否则使用 @Value 默认值 */
    private String getDdlType() {
        return customDdlType != null ? customDdlType : defaultDdlType;
    }

    /** 获取最终的扫描路径：自定义值优先，否则使用 @Value 默认值 */
    private String getDdlScan() {
        return customDdlScan != null ? customDdlScan : defaultDdlScan;
    }

    // ==================== Dialect Bean ====================

    /**
     * 暴露 DatabaseDialect 为 Spring Bean，供 BeetMapper 等组件注入。
     * <p>
     * 延迟创建该 Bean，避免 Spring 容器刷新阶段提前访问数据库。
     * 正常情况下，方言会由 {@link #easySQLInitializer()} 在业务初始化阶段率先解析。
     */
    @Bean
    @Lazy
    public DatabaseDialect databaseDialect() {
        if (this.dialect == null) {
            this.dialect = resolveDialect();
        }
        return this.dialect;
    }

    private DatabaseDialect resolveDialect() {
        DataSource dataSource = jdbcTemplate.getDataSource();
        if (dataSource == null) {
            throw new IllegalStateException("JdbcTemplate 未配置 DataSource");
        }

        long connectionStartedAt = System.nanoTime();
        try (Connection conn = dataSource.getConnection()) {
            log.info("[EasySQL] 数据库连接获取及验证完成（包含连接池首次启动），耗时 {} ms", elapsedMillis(connectionStartedAt));

            long dialectStartedAt = System.nanoTime();
            String product = conn.getMetaData().getDatabaseProductName();
            DatabaseDialect resolved;
            if ("PostgreSQL".equals(product)) {
                resolved = new PostgreSQLDialect();
            } else {
                resolved = new MySQLDialect();
            }
            log.info("[EasySQL] 数据库方言识别完成：{}，耗时 {} ms", product, elapsedMillis(dialectStartedAt));
            return resolved;
        } catch (SQLException e) {
            throw new CannotGetJdbcConnectionException("EasySQL 无法获取数据库连接", e);
        }
    }

    // ==================== 业务初始化阶段 ====================

    /**
     * 在 ApplicationStartedEvent 之后、ApplicationReadyEvent 之前执行数据库初始化。
     * <p>
     * 使用最高优先级，确保依赖 EasySQL 的下游 ApplicationRunner 在数据库初始化完成后运行。
     */
    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE)
    public ApplicationRunner easySQLInitializer() {
        return args -> initializeDatabase();
    }

    private void initializeDatabase() {
        long totalStartedAt = System.nanoTime();

        try {
            if (this.dialect == null) {
                this.dialect = resolveDialect();
            }

            String ddlType = getDdlType();
            if ("none".equals(ddlType)) {
                log.info("[EasySQL] DDL 已关闭（easysql.ddl=none）");
            } else {
                long ddlStartedAt = System.nanoTime();
                doInit();
                log.info("[EasySQL] DDL 初始化完成，模式：{}，耗时 {} ms", ddlType, elapsedMillis(ddlStartedAt));
            }
        } catch (CannotGetJdbcConnectionException e) {
            throw DatabaseStartupException.classify(jdbcUrl(), e, elapsedMillis(totalStartedAt));
        }
        log.info("[EasySQL] 数据库业务初始化完成，总耗时 {} ms", elapsedMillis(totalStartedAt));
    }

    private String jdbcUrl() {
        String url = environment.getProperty("spring.datasource.url");
        if (url == null || url.isBlank()) {
            url = environment.getProperty("spring.datasource.hikari.jdbc-url");
        }
        return url;
    }

    private static long elapsedMillis(long startedAt) {
        return (System.nanoTime() - startedAt) / 1_000_000;
    }

    // ==================== DDL 核心逻辑 ====================

    private void doInit() {
        String ddlType = getDdlType();
        String ddlScan = getDdlScan();

        // 1. 获取实体列表：优先使用显式声明的实体，否则类路径扫描
        Set<Class<?>> entityClasses = new LinkedHashSet<>();
        if (EasySQLEntities.hasExplicitEntities()) {
            entityClasses.addAll(EasySQLEntities.getEntities());
        } else {
            ClassPathScanningCandidateComponentProvider provider = new ClassPathScanningCandidateComponentProvider(false);
            provider.addIncludeFilter(new AnnotationTypeFilter(Table.class));
            Set<BeanDefinition> beanDefinitionSet = provider.findCandidateComponents(ddlScan);

            // 清空老的表
            if ("create".equals(ddlType)) {
                beanDefinitionSet.forEach(d -> {
                    if (d.getBeanClassName() == null) return;
                    String tableName = d.getBeanClassName().substring(d.getBeanClassName().lastIndexOf(".") + 1);
                    jdbcTemplate.execute("DROP TABLE IF EXISTS " + dialect.quote(SQLUtils.toTableName(tableName)));
                });
            }

            for (BeanDefinition d : beanDefinitionSet) {
                if (d.getBeanClassName() == null) continue;
                try {
                    entityClasses.add(Class.forName(d.getBeanClassName()));
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }

        // 2. 获取数据库所有表
        Map<String, TableMeta> tables = new DatabaseMetadataReader(jdbcTemplate, dialect).readTables();

        // 本批次已处理的表名，防止同名类重复创建
        Set<String> processedInBatch = new HashSet<>();
        entityClasses.forEach(entity -> {
            String tableName = SQLUtils.toTableName(entity.getSimpleName());
            if (!processedInBatch.add(tableName)) {
                return;
            }
            // 新增操作
            if (!tables.containsKey(tableName)) {
                String createDDL = TableCreator.parse(entity, dialect);
                if (createDDL != null && !createDDL.isEmpty()) {
                    System.err.println("新增操作：\n" + createDDL);
                    executeDdl(createDDL);
                }
            }
            // 修改操作
            else {
                String updateDDL = TableModitor.parse(entity, tables.get(tableName), dialect);
                if (!updateDDL.isEmpty()) {
                    System.err.println("修改操作：\n" + updateDDL);
                    executeDdl(updateDDL);
                }
            }
        });
    }

    /**
     * 执行 DDL（支持多条 SQL，用 {@code ;} 分隔）。
     * PG 的 COMMENT ON COLUMN 语句与 CREATE TABLE 通过 {@code ;\n} 拼接在同一字符串中。
     */
    private void executeDdl(String ddl) {
        for (String stmt : ddl.split(";")) {
            String trimmed = stmt.trim();
            if (!trimmed.isEmpty()) {
                jdbcTemplate.execute(trimmed);
            }
        }
    }
}
