package org.easyframework.easysql.ddl.util;

/**
 * 数据库工具
 */
public class SQLUtils {

    /**
     * 转成Java字段名（驼峰命名）
     * userName, user_name, UserName > userName
     */
    public static String toFieldName(String para) {
        String[] a = para.split("_");
        StringBuilder result = new StringBuilder();
        for (String s : a) {
            if (!para.contains("_")) {
                result.append(s.substring(0, 1).toLowerCase());
                result.append(s.substring(1));
                continue;
            }
            if (result.length() == 0) {
                result.append(s.toLowerCase());
            } else {
                result.append(s.substring(0, 1).toUpperCase());
                result.append(s.substring(1).toLowerCase());
            }
        }
        return result.toString();
    }

    /**
     * 转成类名（首字母大写）
     * PoUser, poUser, po_user > PoUser
     */
    public static String toClassName(String para) {
        return toFieldName(para);
    }

    /**
     * 转成数据库表（下划线）
     * UserName, userName, user_name > user_name
     */
    public static String toTableName(String para) {
        return toColumnName(para);
    }

    /**
     * 转成数据库字段命名（下划线）
     * UserName, userName, user_name > user_name
     */
    public static String toColumnName(String para) {
        if (para == null || para.equals(""))
            return "";

        int temp = 0; //定位
        StringBuilder sb = new StringBuilder(para);
        for (int i = 1; i < para.length(); i++) {
            if (!Character.isUpperCase(para.charAt(i))) continue;
            sb.insert(i + temp, "_");
            temp++;
        }
        return sb.toString().toLowerCase();
    }

    /**
     * 生成表级唯一的普通索引名，避免 PostgreSQL 同一 schema 下不同表的索引重名。
     */
    public static String indexName(String tableName, String columnName) {
        return "idx_" + tableName + "_" + columnName;
    }

    /**
     * special char handle
     * '：用于包裹搜索条件，需转为\'
     * %：用于代替任意数目的任意字符，需转换为\%
     * _：用于代替一个任意字符，需转换为\_
     * \：转义符号，需转换为\\在java中\也是特殊字符因此需要两次转义，而replace正则需要再次转义
     *
     * \要最先处理，防止把转义\再次转一遍
     * eg:abc _'%*sdf\\
     * result:abc\_\'\%\*sdf\\\\
     *
     * author :bamboo
     * url:https://editor.csdn.net/md?not_checkout=1&articleId=111865685
     */
    public static String escapeSqlSpecialChar(String str) {
        if (str == null) return null;
        // return str.trim().replaceAll("\\s", "").replace("\\", "\\\\\\\\")
        //           .replace("_", "\\_").replace("\'", "\\'")
        //           .replace("%", "\\%").replace("*", "\\*");
        // return str.trim().replace("\\", "\\\\\\\\")
        //           .replaceAll("_", "\\_")
        //           .replaceAll("\'", "\\'")
        //           .replaceAll("\'", "\\\\'")
        //           .replaceAll("%", "\\%")
        //           .replace("*", "\\*");

        return str.replace("\\", "\\\\\\\\")
                  .replaceAll("_", "\\_")
                  .replaceAll("\'", "\\'")
                  .replaceAll("\'", "\\\\'")
                  .replaceAll("%", "\\%")
                  .replace("*", "\\*");
    }

    /**
     * 这个专门用来转JSON的，看看什么时候和上面这个合并。
     */
    public static String escapeSqlSpecialChar2(String str) {
        // 1. 转义   \n -> \\n   这个是换行符
        // 2. 转义  \\n -> \\\\n 这个是字符串 \n
        // 3. 转义 \\\n -> \\\\\n   这个是换行符
        // 2. 转义 \t -> \\t   制表符
        // 2. 转义 \" -> \\"   这个是字符串 "
        // 3. 转义 '  -> \'    这个是字符串 '
        // 这里正则的作用是已经替换过的字符串不再被替换。
//        return str.replaceAll("(?<!\\\\)\\\\\\\\n", "\\\\\\\\\\\\\\\\n")
//                  .replaceAll("(?<!\\\\)\\\\\\n", "\\\\\\\\n")
//                  .replaceAll("(?<!\\\\)\\\\n", "\\\\\\\\n")
//                  .replaceAll("(?<!\\\\)\\\\t", "\\\\\\\\t")
//                  .replaceAll("(?<!\\\\)\\\\\"", "\\\\\\\\\"")
//                  .replaceAll("'", "\\\\'");
          return escapeJsonSpecialChars(str);
//        return JSONObject.toJSONString(str);
    }


    public static void main(String[] args) {
        String aa = "'";
        System.out.println(escapeJsonSpecialChars(aa));
    }


    // 处理JSON字符串中的特殊字符
    public static String escapeJsonSpecialChars(String jsonString) {
        if (jsonString == null) {
            return null;
        }

        StringBuilder sb = new StringBuilder();
        for (char c : jsonString.toCharArray()) {
            switch (c) {
                // 因为外层SQL用了 '
                case '\'':
                    sb.append("\\'");
                    break;
                case '"':
                    sb.append("\\\"");
                    break;
                case '\\':
                    sb.append("\\\\");
                    break;
                case '\b':
                    sb.append("\\b");
                    break;
                case '\f':
                    sb.append("\\f");
                    break;
                case '\r':
                    sb.append("\\r");
                    break;
                case '\t':
                    sb.append("\\t");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                default:
                    if (c < ' ') {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.toString();
    }

}
