package org.easyframework.easysql.config;

import org.easyframework.easysql.annotations.Table;
import org.easyframework.easysql.exception.EasysqlException;
import org.easyframework.easysql.model.BaseModel;
import org.easyframework.easysql.repository.impl.AbstractService;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.Ordered;
import org.springframework.core.ResolvableType;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.type.filter.AnnotationTypeFilter;

import java.util.Set;

/**
 * 延迟实体扫描器，在 {@link Ordered#LOWEST_PRECEDENCE} 执行。
 * <p>
 * 设计意图：让 {@link EasySQLEntities} 先收集所有扫描包（来自
 * {@code @EnableEasySQL} 注解 + 用户动态调用 {@link EasySQLEntities#addScanPackage(String)}），
 * 最后一次性扫描注册。
 * <p>
 * 用户可在任意 {@code @Configuration} 类的 static 块或早期生命周期回调中
 * 动态添加扫描路径，无需在注解中写死：
 * <pre>{@code
 * @Configuration
 * public class EasySQLConfig {
 *     static {
 *         EasySQLEntities.addScanPackage("com.example.**.model");
 *     }
 * }
 * }</pre>
 */
public class EasySQLScanPostProcessor
        implements BeanDefinitionRegistryPostProcessor, Ordered {

    /** 最低优先级，确保在所有 Configuration 类处理完毕后再扫描 */
    @Override
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE;
    }

    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) {
        for (String pkg : EasySQLEntities.getScanPackages()) {
            if (pkg == null || pkg.isEmpty()) continue;
            scanPackage(registry, pkg);
        }
    }

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
        // no-op
    }

    /**
     * 使用 Spring 的 classpath 扫描机制查找 @Table 实体。
     */
    private void scanPackage(BeanDefinitionRegistry registry, String basePackage) {
        try {
            ClassLoader cl = Thread.currentThread().getContextClassLoader();
            if (cl == null) cl = ClassLoader.getSystemClassLoader();
            ClassPathScanningCandidateComponentProvider scanner =
                    new ClassPathScanningCandidateComponentProvider(false);
            scanner.setResourceLoader(new PathMatchingResourcePatternResolver(cl));
            scanner.addIncludeFilter(new AnnotationTypeFilter(Table.class));

            Set<BeanDefinition> beans = scanner.findCandidateComponents(basePackage);
            for (BeanDefinition def : beans) {
                String beanClassName = def.getBeanClassName();
                try {
                    if (beanClassName == null) continue;
                    Class<?> cz = cl.loadClass(beanClassName);
                    if (BaseModel.class.isAssignableFrom(cz)) {
                        @SuppressWarnings("unchecked")
                        Class<? extends BaseModel> entityClass = (Class<? extends BaseModel>) cz;
                        EasySQLEntities.addEntity(entityClass);
                        registerServiceBean(registry, entityClass);
                    }
                } catch (Exception ignored) {
                    throw new EasysqlException("Failed to register EasySQL entity: " + beanClassName, ignored);
                }
            }
        } catch (EasysqlException e) {
            throw e;
        } catch (Exception e) {
            throw new EasysqlException("Failed to scan EasySQL entities from package: " + basePackage, e);
        }
    }

    /**
     * 为实体类自动注册 AbstractService Bean。
     * 使用工厂方法 {@code AbstractService.of(entityClass)} 创建。
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    private void registerServiceBean(BeanDefinitionRegistry registry, Class<? extends BaseModel> entityClass) {
        String beanName = Character.toLowerCase(entityClass.getSimpleName().charAt(0))
                          + entityClass.getSimpleName().substring(1) + "Service";
        if (registry.containsBeanDefinition(beanName)) return;

        RootBeanDefinition bd = new RootBeanDefinition();
        bd.setBeanClass(AbstractService.class);
        bd.setTargetType(ResolvableType.forClassWithGenerics(AbstractService.class, entityClass));
        bd.setFactoryMethodName("of");
        bd.getConstructorArgumentValues().addGenericArgumentValue(entityClass);
        registry.registerBeanDefinition(beanName, bd);
    }
}
