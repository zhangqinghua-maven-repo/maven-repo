package org.easyframework.easysql.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;

@Configuration
public class EasySQLDataSourceConfig {

    // @Primary
    @Bean(name = "hikariDataSource")
    @Order(1)
    public DataSource datasource(Environment env) {
        HikariDataSource hides = new HikariDataSource();
        hides.setJdbcUrl(env.getProperty("spring.datasource.url"));
        hides.setUsername(env.getProperty("spring.datasource.username"));
        hides.setPassword(env.getProperty("spring.datasource.password"));
        if (!StringUtils.isEmpty(env.getProperty("spring.datasource.hikari.minimum-idle"))) {
            hides.setMinimumIdle(Integer.parseInt(env.getProperty("spring.datasource.hikari.minimum-idle")));
        }
        if (!StringUtils.isEmpty(env.getProperty("spring.datasource.hikari.maximum-pool-size"))) {
            hides.setMaximumPoolSize(Integer.parseInt(env.getProperty("spring.datasource.hikari.maximum-pool-size")));
        }
        if (!StringUtils.isEmpty(env.getProperty("spring.datasource.hikari.idle-timeout"))) {
            hides.setIdleTimeout(Integer.parseInt(env.getProperty("spring.datasource.hikari.idle-timeout")));
        }
        if (!StringUtils.isEmpty(env.getProperty("spring.datasource.hikari.max-lifetime"))) {
            hides.setMaxLifetime(Integer.parseInt(env.getProperty("spring.datasource.hikari.max-lifetime")));
        }
        if (!StringUtils.isEmpty(env.getProperty("spring.datasource.hikari.connection-timeout"))) {
            hides.setConnectionTimeout(Integer.parseInt(env.getProperty("spring.datasource.hikari.connection-timeout")));
        }
        if (!StringUtils.isEmpty(env.getProperty("spring.datasource.hikari.connection-test-query"))) {
            hides.setConnectionTestQuery(env.getProperty("spring.datasource.hikari.connection-test-query"));
        }
        return hides;
    }

    //开启事务
    @Bean(name = "transactionManager")
    public DataSourceTransactionManager getDataSourceTransactionManager(DataSource datasource) {
        DataSourceTransactionManager dsm = new DataSourceTransactionManager();
        dsm.setDataSource(datasource);
        return dsm;
    }
}
