package org.easyframework.easysql.ddl.dialect;

import org.easyframework.easysql.annotations.Column;
import org.easyframework.easysql.annotations.Table;
import org.easyframework.easysql.ddl.enums.Type;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.Date;

/**
 * MySQL 方言实现。
 */
public class MySQLDialect implements DatabaseDialect {

    @Override
    public String quote(String identifier) {
        return "`" + identifier + "`";
    }

    @Override
    public String ddlType(Field field, Column column) {
        Type t = column.type();
        Class<?> ft = field.getType();

        // --- 字符串 / 枚举类 ---
        if (t == Type.CHAR || (t == Type.NONE && (ft == Character.class || ft.isEnum()))) {
            int len = column.length() == -1 ? 32 : column.length();
            return "char(" + len + ")";
        }
        if (t == Type.VARCHAR || t == Type.STRING || (t == Type.NONE && ft == String.class)) {
            int len = column.length() == -1 ? 255 : column.length();
            return "varchar(" + len + ")";
        }
        if (t == Type.TEXT || t == Type.MEDIUMTEXT || t == Type.LONGTEXT) {
            return t.name().toLowerCase();
        }

        // --- 整数 ---
        if (t == Type.Byte || (t == Type.NONE && ft == Byte.class))  return "int";
        if (t == Type.Short || (t == Type.NONE && ft == Short.class)) return "int";
        if (t == Type.INT || (t == Type.NONE && ft == Integer.class)) return "int";
        if (t == Type.LONG || t == Type.BIGINT || (t == Type.NONE && ft == Long.class)) return "bigint";

        // --- 浮点数 ---
        if (t == Type.FLOAT || (t == Type.NONE && ft == Float.class)) {
            int len = column.length() == -1 ? 10 : column.length();
            int scale = column.scale() == -1 ? 2 : column.scale();
            return "float(" + len + "," + scale + ")";
        }
        if (t == Type.DECIMAL || t == Type.DOUBLE
                || (t == Type.NONE && (ft == Double.class || ft == BigDecimal.class))) {
            int len = column.length() == -1 ? 10 : column.length();
            int scale = column.scale() == -1 ? 2 : column.scale();
            return "double(" + len + "," + scale + ")";
        }

        // --- 时间日期 ---
        if (t == Type.YEAR)  return "year(4)";
        if (t == Type.DATE || (t == Type.NONE && ft == LocalDate.class))   return "date";
        if (t == Type.TIME || (t == Type.NONE && ft == LocalTime.class))   return "time";
        if (t == Type.YEARMONTH || (t == Type.NONE && ft == YearMonth.class)) return "char(7)";
        if (t == Type.DATETIME || (t == Type.NONE && (ft == LocalDateTime.class || ft == Date.class)))
            return "datetime";

        // --- 布尔 → TINYINT(1) ---
        if (t == Type.BOOL || (t == Type.NONE && (ft == Boolean.class || ft == boolean.class))) return "tinyint(1)";

        // --- UUID → CHAR(36) ---
        if (t == Type.UUID) return "char(36)";

        // --- JSON ---
        if (t == Type.JSON) return "json";

        // --- 兜底：JSON ---
        return "json";
    }

    @Override
    public String columnDefault(Field field, Column column) {
        if (column.def().isEmpty()) return "";
        if (isBoolean(field, column)) {
            if ("false".equalsIgnoreCase(column.def()) || "0".equals(column.def())) return "DEFAULT '0'";
            if ("true".equalsIgnoreCase(column.def()) || "1".equals(column.def())) return "DEFAULT '1'";
        }
        return DatabaseDialect.super.columnDefault(field, column);
    }

    private boolean isBoolean(Field field, Column column) {
        return column.type() == Type.BOOL
                || (column.type() == Type.NONE
                && (field.getType() == Boolean.class || field.getType() == boolean.class));
    }

    @Override
    public String tableOptions(Table tableAnno) {
        String engine = tableAnno.engine();
        if (engine.isEmpty()) engine = "InnoDB";
        return "ENGINE=" + engine + " CHARSET=utf8mb4";
    }

    @Override
    public String tableComment(String comment) {
        if (comment == null || comment.isEmpty()) {
            return "";
        }
        return "COMMENT = '" + comment + "'";
    }

    @Override
    public String columnComment(String comment) {
        if (comment == null || comment.isEmpty()) {
            return "";
        }
        return "COMMENT '" + comment + "'";
    }

    @Override
    public String commentOnColumn(String quotedTable, String quotedColumn, String comment) {
        // MySQL 已在列定义中内联 COMMENT，无需独立语句
        return "";
    }

    @Override
    public String commentOnTable(String quotedTable, String comment) {
        // MySQL 已在表定义中内联 COMMENT = 'xxx'，无需独立语句
        return "";
    }

    @Override
    public String indexFragment(String quotedTable, String indexName, String quotedCol) {
        return "KEY " + quote(indexName) + " (" + quotedCol + ")";
    }

    @Override
    public String ifNull(String expr, String defaultValue) {
        return "IFNULL(" + expr + ", " + defaultValue + ")";
    }

    @Override
    public String jsonContains(String column, String value) {
        return "JSON_CONTAINS(" + column + ", JSON_QUOTE('" + value + "'), '$')";
    }

    @Override
    public String jsonOverlaps(String column, String value) {
        return "JSON_OVERLAPS(" + column + ", '" + value + "') > 0";
    }

    @Override
    public String limitClause(long offset, long size) {
        return "LIMIT " + offset + ", " + size;
    }

    @Override
    public String metadataQuery() {
        return "SELECT table_name, column_name, column_key, column_type, "
                + "is_nullable, column_default, column_comment "
                + "FROM information_schema.columns "
                + "WHERE table_schema = '${table_schema}' ORDER BY table_name, ordinal_position";
    }

    @Override
    public boolean isIndexed(Object columnKeyValue) {
        return "MUL".equals(columnKeyValue);
    }

    @Override
    public String alterColumn(String quotedTable, String quotedCol, String type, String notnull, String def, String comment) {
        StringBuilder sb = new StringBuilder();
        sb.append("ALTER TABLE ").append(quotedTable)
          .append(" MODIFY COLUMN ").append(quotedCol)
          .append(" ").append(type);
        if (!notnull.isEmpty()) sb.append(" ").append(notnull);
        if (!def.isEmpty()) sb.append(" ").append(def);
        if (!comment.isEmpty()) sb.append(" ").append(comment);
        return sb.toString();
    }

    @Override
    public String alterColumnComment(String quotedTable, String quotedCol, String type, String def, String comment) {
        StringBuilder sb = new StringBuilder();
        sb.append("ALTER TABLE ").append(quotedTable)
          .append(" MODIFY COLUMN ").append(quotedCol)
          .append(" ").append(type);
        if (!def.isEmpty()) sb.append(" ").append(def);
        if (!comment.isEmpty()) sb.append(" ").append(comment);
        return sb.toString();
    }

    @Override
    public String createIndex(String quotedTable, String indexName, String quotedCol) {
        return "ALTER TABLE " + quotedTable + " ADD INDEX " + indexName + " (" + quotedCol + ")";
    }

    @Override
    public String dropIndex(String quotedTable, String indexName) {
        return "DROP INDEX " + indexName + " ON " + quotedTable;
    }

    @Override
    public String normalizeColumnDefault(String dbDefault) {
        if (dbDefault == null || dbDefault.isEmpty()) return "";
        String cleaned = dbDefault.trim();
        if (cleaned.startsWith("'") && cleaned.endsWith("'")) {
            return "DEFAULT " + cleaned;
        }
        // information_schema 在 MySQL 中返回不带引号的默认值。
        return "DEFAULT '" + cleaned + "'";
    }
}
