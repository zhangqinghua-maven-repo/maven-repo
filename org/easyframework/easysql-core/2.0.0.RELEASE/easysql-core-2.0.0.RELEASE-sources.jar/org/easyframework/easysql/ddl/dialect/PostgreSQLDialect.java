package org.easyframework.easysql.ddl.dialect;

import org.easyframework.easysql.annotations.Column;
import org.easyframework.easysql.annotations.Table;
import org.easyframework.easysql.ddl.enums.Type;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.Date;

/**
 * PostgreSQL 方言实现。
 */
public class PostgreSQLDialect implements DatabaseDialect {

    @Override
    public String quote(String identifier) {
        return "\"" + identifier + "\"";
    }

    @Override
    public String ddlType(Field field, Column column) {
        Type t = column.type();
        Class<?> ft = field.getType();

        // --- 字符串 / 枚举类 ---
        if (t == Type.CHAR || (t == Type.NONE && (ft == Character.class || ft.isEnum()))) {
            int len = column.length() == -1 ? 32 : column.length();
            return "CHAR(" + len + ")";
        }
        if (t == Type.VARCHAR || t == Type.STRING || (t == Type.NONE && ft == String.class)) {
            int len = column.length() == -1 ? 255 : column.length();
            return "VARCHAR(" + len + ")";
        }
        // PG 只有一种 TEXT，MEDIUMTEXT/LONGTEXT 都映射为 TEXT
        if (t == Type.TEXT || t == Type.MEDIUMTEXT || t == Type.LONGTEXT) {
            return "TEXT";
        }

        // --- 整数 ---
        if (t == Type.Byte || (t == Type.NONE && ft == Byte.class))   return "SMALLINT";
        if (t == Type.Short || (t == Type.NONE && ft == Short.class)) return "SMALLINT";
        if (t == Type.INT || (t == Type.NONE && ft == Integer.class)) return "INTEGER";
        if (t == Type.LONG || t == Type.BIGINT || (t == Type.NONE && ft == Long.class)) return "BIGINT";

        // --- 浮点数 ---
        if (t == Type.FLOAT || (t == Type.NONE && ft == Float.class)) {
            int len = column.length() == -1 ? 10 : column.length();
            int scale = column.scale() == -1 ? 2 : column.scale();
            return "FLOAT(" + len + "," + scale + ")";
        }
        if (t == Type.DECIMAL || t == Type.DOUBLE
                || (t == Type.NONE && (ft == Double.class || ft == BigDecimal.class))) {
            int len = column.length() == -1 ? 10 : column.length();
            int scale = column.scale() == -1 ? 2 : column.scale();
            return "NUMERIC(" + len + "," + scale + ")";
        }

        // --- 时间日期 ---
        if (t == Type.YEAR) return "SMALLINT";
        if (t == Type.DATE || (t == Type.NONE && ft == LocalDate.class))   return "DATE";
        if (t == Type.TIME || (t == Type.NONE && ft == LocalTime.class))   return "TIME";
        if (t == Type.YEARMONTH || (t == Type.NONE && ft == YearMonth.class)) return "CHAR(7)";
        if (t == Type.DATETIME || (t == Type.NONE && (ft == LocalDateTime.class || ft == Date.class)))
            return "TIMESTAMP";

        // --- 布尔 → BOOLEAN ---
        if (t == Type.BOOL || (t == Type.NONE && (ft == Boolean.class || ft == boolean.class))) return "BOOLEAN";

        // --- UUID → UUID ---
        if (t == Type.UUID) return "UUID";

        // --- JSON → JSONB ---
        if (t == Type.JSON) return "JSONB";

        // --- 兜底：JSONB ---
        return "JSONB";
    }

    @Override
    public String columnDefault(Field field, Column column) {
        if (column.def().isEmpty()) return "";
        if (isBoolean(field, column)) {
            if ("false".equalsIgnoreCase(column.def()) || "0".equals(column.def())) return "DEFAULT 'false'";
            if ("true".equalsIgnoreCase(column.def()) || "1".equals(column.def())) return "DEFAULT 'true'";
        }
        return DatabaseDialect.super.columnDefault(field, column);
    }

    private boolean isBoolean(Field field, Column column) {
        return column.type() == Type.BOOL
                || (column.type() == Type.NONE
                && (field.getType() == Boolean.class || field.getType() == boolean.class));
    }

    @Override
    public String tableOptions(Table tableAnno) {
        // PostgreSQL 不需要 ENGINE/CHARSET 等表级选项
        return "";
    }

    @Override
    public String tableComment(String comment) {
        // PG 不支持内联 COMMENT，表注释需单独执行 COMMENT ON TABLE 语句
        return "";
    }

    @Override
    public String columnComment(String comment) {
        // PG 不支持列定义中内联 COMMENT，需用独立的 COMMENT ON COLUMN 语句
        return "";
    }

    @Override
    public String commentOnColumn(String quotedTable, String quotedColumn, String comment) {
        return "COMMENT ON COLUMN " + quotedTable + "." + quotedColumn + " IS '" + comment + "'";
    }

    @Override
    public String commentOnTable(String quotedTable, String comment) {
        return "COMMENT ON TABLE " + quotedTable + " IS '" + comment + "'";
    }

    @Override
    public boolean supportsInlineIndex() {
        return false;
    }

    @Override
    public String indexFragment(String quotedTable, String indexName, String quotedCol) {
        // PG 不支持 CREATE TABLE 内联索引，需单独 CREATE INDEX
        return "";
    }

    @Override
    public String ifNull(String expr, String defaultValue) {
        return "COALESCE(" + expr + ", " + defaultValue + ")";
    }

    @Override
    public String jsonContains(String column, String value) {
        return column + " @> to_jsonb('" + value + "'::text)";
    }

    @Override
    public String jsonOverlaps(String column, String value) {
        // PG: col ?| array['a','b'] — 用于 JSONB 数组交集
        return column + " ?| " + value;
    }

    @Override
    public String limitClause(long offset, long size) {
        return "LIMIT " + size + " OFFSET " + offset;
    }

    @Override
    public String metadataQuery() {
        // PostgreSQL 用 pg_catalog 获取列注释和索引信息
        return "SELECT c.table_name, c.column_name, "
                // 索引检测：用 EXISTS 标量子查询替代 LEFT JOIN，更稳健
                + "CASE WHEN EXISTS ("
                + "  SELECT 1 FROM pg_catalog.pg_index x"
                + "  JOIN pg_catalog.pg_class t ON t.oid = x.indrelid"
                + "  JOIN pg_catalog.pg_attribute a ON a.attrelid = t.oid AND a.attnum = ANY(x.indkey)"
                + "  WHERE NOT x.indisprimary AND t.relname = c.table_name AND a.attname = c.column_name"
                + ") THEN 'MUL' ELSE '' END AS column_key, "
                + "CASE WHEN c.character_maximum_length IS NOT NULL "
                + "  THEN UPPER(c.data_type) || '(' || c.character_maximum_length || ')' "
                + "  WHEN c.numeric_precision IS NOT NULL AND c.numeric_scale IS NOT NULL AND c.numeric_scale > 0 "
                + "  THEN UPPER(c.data_type) || '(' || c.numeric_precision || ',' || c.numeric_scale || ')' "
                + "  ELSE UPPER(c.data_type) "
                + "END AS column_type, "
                + "c.is_nullable, c.column_default, "
                + "COALESCE(pgd.description, '') AS column_comment "
                + "FROM information_schema.columns c "
                + "LEFT JOIN pg_catalog.pg_description pgd "
                + "  ON pgd.objoid = (SELECT pc.oid FROM pg_catalog.pg_class pc "
                + "                   JOIN pg_catalog.pg_namespace pn ON pn.oid = pc.relnamespace "
                + "                   WHERE pc.relname = c.table_name AND pn.nspname = c.table_schema) "
                + "  AND pgd.objsubid = c.ordinal_position "
                + "WHERE c.table_schema = '${table_schema}' "
                + "ORDER BY c.table_name, c.ordinal_position";
    }

    @Override
    public boolean isIndexed(Object columnKeyValue) {
        return "MUL".equals(columnKeyValue);
    }

    @Override
    public String alterColumn(String quotedTable, String quotedCol, String type, String notnull, String def, String comment) {
        StringBuilder sb = new StringBuilder();

        // 1. 修改类型
        sb.append("ALTER TABLE ").append(quotedTable)
          .append(" ALTER COLUMN ").append(quotedCol)
          .append(" TYPE ").append(type).append(";\n");

        // 2. 修改 NOT NULL
        if (!notnull.isEmpty()) {
            sb.append("ALTER TABLE ").append(quotedTable)
              .append(" ALTER COLUMN ").append(quotedCol)
              .append(" SET NOT NULL;\n");
        } else {
            sb.append("ALTER TABLE ").append(quotedTable)
              .append(" ALTER COLUMN ").append(quotedCol)
              .append(" DROP NOT NULL;\n");
        }

        // 3. 修改默认值
        if (!def.isEmpty()) {
            // def format: "DEFAULT 'xxx'"
            String defaultValue = def.replace("DEFAULT ", "").trim();
            sb.append("ALTER TABLE ").append(quotedTable)
              .append(" ALTER COLUMN ").append(quotedCol)
              .append(" SET DEFAULT ").append(defaultValue).append(";\n");
        } else {
            sb.append("ALTER TABLE ").append(quotedTable)
              .append(" ALTER COLUMN ").append(quotedCol)
              .append(" DROP DEFAULT;\n");
        }

        // 4. 修改注释
        if (!comment.isEmpty()) {
            // comment format: "COMMENT 'xxx'"
            String commentText = comment.replace("COMMENT ", "").trim();
            commentText = commentText.substring(1, commentText.length() - 1); // remove quotes
            sb.append("COMMENT ON COLUMN ").append(quotedTable).append(".").append(quotedCol)
              .append(" IS '").append(commentText).append("';\n");
        }

        return sb.toString();
    }

    @Override
    public String alterColumnComment(String quotedTable, String quotedCol, String type, String def, String comment) {
        // PG 仅修改注释，不修改类型/默认值
        if (!comment.isEmpty()) {
            String commentText = comment.replace("COMMENT ", "").trim();
            commentText = commentText.substring(1, commentText.length() - 1);
            return "COMMENT ON COLUMN " + quotedTable + "." + quotedCol + " IS '" + commentText + "'";
        }
        return "";
    }

    @Override
    public String createIndex(String quotedTable, String indexName, String quotedCol) {
        return "CREATE INDEX IF NOT EXISTS " + indexName + " ON " + quotedTable + " (" + quotedCol + ")";
    }

    @Override
    public String dropIndex(String quotedTable, String indexName) {
        return "DROP INDEX IF EXISTS " + indexName;
    }

    @Override
    public String normalizeColumnType(String dbType) {
        if (dbType == null) return null;
        return dbType
                .toUpperCase()
                .replace(" WITHOUT TIME ZONE", "")
                .replace(" WITH TIME ZONE", "")
                .replace("CHARACTER VARYING", "VARCHAR")
                .replace("CHARACTER", "CHAR");
    }

    @Override
    public String normalizeColumnDefault(String dbDefault) {
        if (dbDefault == null || dbDefault.isEmpty()) return "";
        // 去除 PG 类型转换后缀: 'sys'::character varying → 'sys'; 0 → 0
        String cleaned = dbDefault.replaceAll("::[a-zA-Z ]+$", "").trim();
        // PG 布尔值使用原生 true/false，并与实体侧统一为带引号的比较格式。
        if ("false".equalsIgnoreCase(cleaned)) cleaned = "'false'";
        else if ("true".equalsIgnoreCase(cleaned)) cleaned = "'true'";
        // PG 数值默认值不带引号，实体侧默认值统一加引号，需对齐。
        if (!cleaned.startsWith("'") && cleaned.matches("-?\\d+(\\.\\d+)?")) {
            cleaned = "'" + cleaned + "'";
        }
        return "DEFAULT " + cleaned;
    }
}
