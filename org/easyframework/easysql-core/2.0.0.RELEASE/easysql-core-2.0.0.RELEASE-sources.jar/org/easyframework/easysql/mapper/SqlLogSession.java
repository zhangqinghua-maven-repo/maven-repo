package org.easyframework.easysql.mapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.concurrent.atomic.AtomicLong;

/** Logs one SQL statement from submission through completion. */
final class SqlLogSession {

    private static final Logger LOG = LoggerFactory.getLogger(BeetMapper.class);
    private static final AtomicLong SQL_LOG_ID = new AtomicLong(10000L);
    private static final int MAX_SQL_LOG_LENGTH = 1000;
    private final long id;
    private final long startTime;

    SqlLogSession(String label, String sql, Object[] params) {
        this.id = SQL_LOG_ID.incrementAndGet();
        this.startTime = System.currentTimeMillis();
        logStart(sql, params);
    }

    static boolean isDebugEnabled() {
        return LOG.isDebugEnabled();
    }

    void logResult(Object result, boolean isUpdate) {
        if (!LOG.isDebugEnabled()) return;

        String resultText;
        if (isUpdate) {
            resultText = result + " results";
        } else if (result instanceof Collection<?> collection) {
            resultText = collection.size() + " results";
        } else if (result != null) {
            // String value = result.toString();
            // resultText = (value.length() > 80 ? value.substring(0, 80) + "..." : value) + " results";
            resultText = "1 results";
        } else {
            resultText = "0 results";
        }
        LOG.debug("EasySQL [{}] completed: {} in {}ms", id, resultText, elapsed());
    }

    void logException(Exception exception) {
        if (!LOG.isDebugEnabled()) return;
        LOG.debug("EasySQL [{}] failed: {} in {}ms", id,
                exception == null ? "" : exception.getMessage(), elapsed());
    }

    private void logStart(String sql, Object[] params) {
        if (!LOG.isDebugEnabled()) return;
        LOG.debug("EasySQL [{}] executing: {}", id, abbreviateSql(formatSql(sql, params)));
    }

    private long elapsed() {
        return System.currentTimeMillis() - startTime;
    }

    private static String formatSql(String sql, Object[] params) {
        if (params == null || params.length == 0) return sql.replaceAll("\\s+", " ").trim();
        StringBuilder result = new StringBuilder();
        int parameterIndex = 0;
        for (int index = 0; index < sql.length(); index++) {
            char character = sql.charAt(index);
            if (character == '?' && parameterIndex < params.length) {
                result.append(formatParam(params[parameterIndex++]));
            } else {
                result.append(character);
            }
        }
        return result.toString();
    }

    private static String formatParam(Object param) {
        if (param == null) return "NULL";
        if (param instanceof Number || param instanceof Boolean) return param.toString();
        return "'" + param.toString().replace("'", "''") + "'";
    }

    private static String abbreviateSql(String sql) {
        if (sql.length() <= MAX_SQL_LOG_LENGTH) return sql;
        return sql.substring(0, MAX_SQL_LOG_LENGTH) + "... (" + sql.length() + " chars)";
    }
}
