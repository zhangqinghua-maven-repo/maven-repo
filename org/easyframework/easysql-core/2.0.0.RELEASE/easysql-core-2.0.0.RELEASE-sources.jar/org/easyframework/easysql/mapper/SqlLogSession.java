package org.easyframework.easysql.mapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/** Logs one SQL statement from submission through completion. */
final class SqlLogSession {

    private static final Logger LOG = LoggerFactory.getLogger(BeetMapper.class);
    private static final AtomicLong SQL_LOG_ID = new AtomicLong(10000L);
    private static final int MAX_SQL_LOG_LENGTH = 1000;
    private final long id;
    private final long startTime;

    SqlLogSession(String label, String sql, Object[] params) {
        this.id = SQL_LOG_ID.incrementAndGet();
        this.startTime = System.currentTimeMillis();
        logStart(sql, params);
    }

    SqlLogSession(String label, String sql, Map<String, ?> params) {
        this.id = SQL_LOG_ID.incrementAndGet();
        this.startTime = System.currentTimeMillis();
        logStart(sql, params);
    }

    static boolean isDebugEnabled() {
        return LOG.isDebugEnabled();
    }

    void logResult(Object result, boolean isUpdate) {
        if (!LOG.isDebugEnabled()) return;

        String resultText;
        if (isUpdate) {
            resultText = result + " results";
        } else if (result instanceof Collection<?> collection) {
            resultText = collection.size() + " results";
        } else if (result != null) {
            // String value = result.toString();
            // resultText = (value.length() > 80 ? value.substring(0, 80) + "..." : value) + " results";
            resultText = "1 results";
        } else {
            resultText = "0 results";
        }
        LOG.debug("EasySQL [{}] completed: {} in {}ms", id, resultText, elapsed());
    }

    void logException(Exception exception) {
        if (!LOG.isDebugEnabled()) return;
        LOG.debug("EasySQL [{}] failed: {} in {}ms", id,
                exception == null ? "" : exception.getMessage(), elapsed());
    }

    private void logStart(String sql, Object[] params) {
        if (!LOG.isDebugEnabled()) return;
        LOG.debug("EasySQL [{}] executing: {}", id, abbreviateSql(formatSql(sql, params)));
    }

    private void logStart(String sql, Map<String, ?> params) {
        if (!LOG.isDebugEnabled()) return;
        LOG.debug("EasySQL [{}] executing: \n{}", id, abbreviateSql(formatNamedSql(sql, params)));
    }

    private long elapsed() {
        return System.currentTimeMillis() - startTime;
    }

    private static String formatSql(String sql, Object[] params) {
        if (params == null || params.length == 0) return sql == null ? "" : sql.strip();
        StringBuilder result = new StringBuilder();
        int parameterIndex = 0;
        for (int index = 0; index < sql.length(); index++) {
            char character = sql.charAt(index);
            if (character == '?' && parameterIndex < params.length) {
                result.append(formatParamValue(params[parameterIndex++]));
            } else {
                result.append(character);
            }
        }
        return result.toString().strip();
    }

    /** 替换命名参数，但保留 SQL 原有的换行、缩进和空行。 */
    private static String formatNamedSql(String sql, Map<String, ?> params) {
        if (sql == null) return "";
        if (params == null || params.isEmpty()) return sql.strip();

        StringBuilder result = new StringBuilder(sql.length());
        boolean singleQuote = false;
        boolean doubleQuote = false;
        boolean backtick = false;
        for (int index = 0; index < sql.length(); index++) {
            char current = sql.charAt(index);

            if (current == '\'' && !doubleQuote && !backtick) {
                singleQuote = !singleQuote;
                result.append(current);
                continue;
            }
            if (current == '"' && !singleQuote && !backtick) {
                doubleQuote = !doubleQuote;
                result.append(current);
                continue;
            }
            if (current == '`' && !singleQuote && !doubleQuote) {
                backtick = !backtick;
                result.append(current);
                continue;
            }

            if (current == ':' && !singleQuote && !doubleQuote && !backtick) {
                if (index + 1 < sql.length() && sql.charAt(index + 1) == ':') {
                    result.append("::");
                    index++;
                    continue;
                }

                int nameStart = index + 1;
                int nameEnd = nameStart;
                while (nameEnd < sql.length()
                        && (Character.isLetterOrDigit(sql.charAt(nameEnd))
                        || sql.charAt(nameEnd) == '_')) {
                    nameEnd++;
                }
                if (nameEnd > nameStart) {
                    String name = sql.substring(nameStart, nameEnd);
                    if (params.containsKey(name)) {
                        result.append(formatParamValue(params.get(name)));
                        index = nameEnd - 1;
                        continue;
                    }
                }
            }
            result.append(current);
        }
        return result.toString().strip();
    }

    private static String formatParam(Object param) {
        if (param == null) return "NULL";
        if (param instanceof Number || param instanceof Boolean) return param.toString();
        return "'" + param.toString().replace("'", "''") + "'";
    }

    private static String formatParamValue(Object param) {
        if (param instanceof Iterable<?> iterable) {
            StringBuilder result = new StringBuilder();
            for (Object value : iterable) {
                if (result.length() > 0) result.append(", ");
                result.append(formatParam(value));
            }
            return result.length() == 0 ? "NULL" : result.toString();
        }
        if (param != null && param.getClass().isArray()) {
            StringBuilder result = new StringBuilder();
            for (int index = 0; index < Array.getLength(param); index++) {
                if (index > 0) result.append(", ");
                result.append(formatParam(Array.get(param, index)));
            }
            return result.length() == 0 ? "NULL" : result.toString();
        }
        return formatParam(param);
    }

    private static String abbreviateSql(String sql) {
        if (sql.length() <= MAX_SQL_LOG_LENGTH) return sql;
        return sql.substring(0, MAX_SQL_LOG_LENGTH) + "... (" + sql.length() + " chars)";
    }
}
