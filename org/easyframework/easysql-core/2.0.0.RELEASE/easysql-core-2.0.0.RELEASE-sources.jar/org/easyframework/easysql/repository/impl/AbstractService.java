package org.easyframework.easysql.repository.impl;

import jakarta.annotation.PostConstruct;
import org.easyframework.easysql.annotations.Table;
import org.easyframework.easysql.config.EasySQLDDLConfig;
import org.easyframework.easysql.config.EasySQLEntities;
import org.easyframework.easysql.config.SqlExecutionListener;
import org.easyframework.easysql.config.UserInfoProvider;
import org.easyframework.easysql.exception.EasysqlException;
import org.easyframework.easysql.mapper.BeetMapper;
import org.easyframework.easysql.model.BaseModel;
import org.easyframework.easysql.model.FieldBean;
import org.easyframework.easysql.model.PageData;
import org.easyframework.easysql.model.QueryParam;
import org.easyframework.easysql.repository.BaseService;
import org.easyframework.easyutils.BeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import java.lang.reflect.ParameterizedType;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class AbstractService<D extends BaseModel> extends QueryParam implements BaseService<D> {

    @Autowired
    private BeetMapper beetMapper;

    @Autowired(required = false)
    private UserInfoProvider userInfoProvider;

    /** 用户通过 {@link #setUserInfoProvider(UserInfoProvider)} 自定义的用户信息提供者 */
    private static volatile UserInfoProvider staticUserInfoProvider = null;

    /**
     * 设置全局用户信息提供者（类似 {@link EasySQLDDLConfig#setDdlType(String)} 模式）。
     * <p>
     * 在 {@code @PostConstruct} 中调用即可统一为所有 Service 提供当前用户信息：
     * <pre>{@code
     * @PostConstruct
     * public void init() {
     *     AbstractService.setUserInfoProvider(() -> {
     *         LocalUser localUser = UserThreadLocal.getUserInfoOrNull();
     *         if (localUser != null) {
     *             return localUser.getUserEnum() + ":" + localUser.getUserId();
     *         }
     *         return "sys";
     *     });
     * }
     * }</pre>
     *
     * @param provider 用户信息提供者，设为 {@code null} 则清除自定义实现
     */
    public static void setUserInfoProvider(UserInfoProvider provider) {
        staticUserInfoProvider = provider;
    }

    /** 用户通过 {@link #setSqlExecutionListener(SqlExecutionListener)} 自定义的 SQL 执行监听器 */
    static volatile SqlExecutionListener staticSqlExecutionListener = null;

    /**
     * 设置全局 SQL 执行监听器（类似 {@link EasySQLDDLConfig#setDdlType(String)} 模式）。
     * <p>
     * 在 {@code @PostConstruct} 中调用即可在所有 SQL 执行前后插入自定义逻辑：
     * <pre>{@code
     * @PostConstruct
     * public void init() {
     *     AbstractService.setSqlExecutionListener(new SqlExecutionListener() {
     *         @Override
     *         public void before() {
     *             UserThreadLocal.plusSQLCount();
     *         }
     *         @Override
     *         public void after(long elapsedMs) {
     *             UserThreadLocal.plusSQLTime();
     *         }
     *     });
     * }
     * }</pre>
     *
     * @param listener SQL 执行监听器，设为 {@code null} 则清除
     */
    public static void setSqlExecutionListener(SqlExecutionListener listener) {
        staticSqlExecutionListener = listener;
    }

    /** @return 当前注册的 SQL 执行监听器，可能为 {@code null} */
    public static SqlExecutionListener getSqlExecutionListener() {
        return staticSqlExecutionListener;
    }

    /**
     * 指实体类，跟数据库对应
     */
    private Class<?> pclass;

    /**
     * 指业务Class
     */
    private Class<D> dclass;

    private String beanname;

    /**
     * 通过实体类直接创建 Service（无需子类化）
     */
    public static <T extends BaseModel> AbstractService<T> of(Class<T> entityClass) {
        AbstractService<T> service = new AbstractService<>();
        service.setEntityClass(entityClass);
        return service;
    }

    /**
     * 设置实体类（在 @PostConstruct 之前调用则跳过反射推断）
     */
    public void setEntityClass(Class<D> entityClass) {
        this.dclass = entityClass;
        this.pclass = entityClass.isAnnotationPresent(Table.class) ? entityClass : entityClass.getSuperclass();
        this.beanname = entityClass.getSimpleName();
        this.beanname = Character.isLowerCase(beanname.charAt(0)) ? beanname : Character.toLowerCase(beanname.charAt(0)) + beanname.substring(1);
    }

    @PostConstruct
    public void init() {
        // 如果已通过 of() / setEntityClass() 初始化，跳过反射推断
        if (this.dclass != null) {
            // 运行时注册到 EasySQLEntities，供 Property 的方法引用解析降级使用
            EasySQLEntities.addEntity(this.dclass);
            return;
        }
        //noinspection unchecked
        this.dclass = (Class<D>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
        this.pclass = this.dclass.isAnnotationPresent(Table.class) ? this.dclass : this.dclass.getSuperclass();
        this.beanname = dclass.getSimpleName();
        this.beanname = Character.isLowerCase(beanname.charAt(0)) ? beanname : Character.toLowerCase(beanname.charAt(0)) + beanname.substring(1);
        // 运行时注册到 EasySQLEntities，供 Property 的方法引用解析降级使用
        EasySQLEntities.addEntity(this.dclass);
    }

    /**
     * 获取用户的信息。
     * <p>
     * 优先级：{@link #setUserInfoProvider(UserInfoProvider)} 静态设置 &gt;
     * Spring Bean 注入 &gt; 默认值 {@code "sys"}。
     */
    protected String getUserInfo() {
        if (staticUserInfoProvider != null) {
            return staticUserInfoProvider.getUserInfo();
        }
        if (userInfoProvider != null) {
            return userInfoProvider.getUserInfo();
        }
        return "sys";
    }

    // ==================== SQL 执行监听辅助 ====================

    private long beforeSql(String method) {
        SqlExecutionListener l = staticSqlExecutionListener;
        if (l != null) l.before(method);
        return System.currentTimeMillis();
    }

    private void afterSql(String method, long start) {
        SqlExecutionListener l = staticSqlExecutionListener;
        if (l != null) l.after(method, System.currentTimeMillis() - start);
    }

    // ==================== Query API ====================

    @Override
    public Boolean exists(Collection<FieldBean> fieldBeans) {
        long _start = beforeSql("exists");
        try {
            return beetMapper.exists(fieldBeans, pclass);
        } finally {
            afterSql("exists", _start);
        }
    }

    @Override
    public <R> R sum(String property, Class<R> propertyClz, Collection<FieldBean> fieldBeans) {
        long _start = beforeSql("sum");
        try {
            return beetMapper.findSum(property, fieldBeans, propertyClz, pclass);
        } finally {
            afterSql("sum", _start);
        }
    }

    @Override
    public List<D> sum(String groupProperty, String sumProperty, String valueProperty, Collection<FieldBean> fieldBeans) {
        long _start = beforeSql("sum");
        try {
            return beetMapper.findSum(groupProperty, sumProperty, valueProperty, fieldBeans, dclass, pclass);
        } finally {
            afterSql("sum", _start);
        }
    }

    @Override
    public Integer count(Collection<FieldBean> fieldBeans) {
        long _start = beforeSql("count");
        try {
            return beetMapper.findCount(fieldBeans, pclass);
        } finally {
            afterSql("count", _start);
        }
    }

    @Override
    public List<D> count(String groupProperty, String countProperty, Collection<FieldBean> fieldBeans) {
        long _start = beforeSql("count");
        try {
            return beetMapper.findCount(groupProperty, countProperty, fieldBeans, dclass, pclass);
        } finally {
            afterSql("count", _start);
        }
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public D one(List<Enum<?>> bizTypes, Collection<FieldBean> fieldBeans) {
        long _start = beforeSql("one");
        try {
            fieldBeans.removeIf(Objects::isNull);
            if (fieldBeans.stream().noneMatch(f -> f.getQueryType() == QueryType.FIELD)) {
                warpAttr(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), (List) fieldBeans);
                warpAttr(bizTypes, (List) fieldBeans);
            }
            BaseModel p = (BaseModel) beetMapper.findOne(fieldBeans, pclass);
            if (p == null) {
                throw new EasysqlException(String.format("Find %s[%s] failed, data doesn't exist",
                                                         beanname,
                                                         fieldBeansToString(fieldBeans)));
            }
            return this.mapDTO(bizTypes, new ArrayList<>(Collections.singleton(p))).get(0);
        } finally {
            afterSql("one", _start);
        }
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public D oneornull(List<Enum<?>> bizTypes, Collection<FieldBean> fieldBeans) {
        long _start = beforeSql("oneornull");
        try {
            fieldBeans.removeIf(Objects::isNull);
            if (fieldBeans.stream().noneMatch(f -> f.getQueryType() == QueryType.FIELD)) {
                warpAttr(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), (List) fieldBeans);
                warpAttr(bizTypes, (List) fieldBeans);
            }
            BaseModel p = (BaseModel) beetMapper.findOne(fieldBeans, pclass);
            if (p == null) {
                return null;
            }
            return this.mapDTO(bizTypes, new ArrayList<>(Collections.singleton(p))).get(0);
        } finally {
            afterSql("oneornull", _start);
        }
    }

    @Override
    public D detail(List<Enum<?>> bizTypes, Collection<FieldBean> fieldBeans) {
        D d = this.one(bizTypes, fieldBeans);

        this.warpDetail(d.getId(), d);

        this.warpDetail(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), d.getId(), d);
        this.warpDetail(bizTypes, d.getId(), d);

        return d;
    }

    @Override
    public D detailornull(List<Enum<?>> bizTypes, Collection<FieldBean> fieldBeans) {
        D d = this.oneornull(bizTypes, fieldBeans);

        if (d == null) return null;

        this.warpDetail(d.getId(), d);

        this.warpDetail(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), d.getId(), d);
        this.warpDetail(bizTypes, d.getId(), d);

        return d;
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public List<D> list(List<Enum<?>> bizTypes, Collection<FieldBean> fieldBeans) {
        long _start = beforeSql("list");
        try {
            fieldBeans.removeIf(Objects::isNull);
            if (fieldBeans.stream().noneMatch(f -> f.getQueryType() == QueryType.FIELD)) {

                warpAttr(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), (List) fieldBeans);
                warpAttr(bizTypes, (List) fieldBeans);
            }
            List<BaseModel> ps = (List<BaseModel>) beetMapper.findList(fieldBeans, pclass);
            return this.mapList(bizTypes, ps);
        } finally {
            afterSql("list", _start);
        }
    }

    @Override
    @SuppressWarnings({"unchecked", "rawtypes"})
    public PageData<D> page(List<Enum<?>> bizTypes, Collection<FieldBean> fieldBeans) {
        long _start = beforeSql("page");
        try {
            fieldBeans.removeIf(Objects::isNull);
            if (fieldBeans.stream().noneMatch(f -> f.getQueryType() == QueryType.FIELD)) {
                warpAttr(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), (List) fieldBeans);
                warpAttr(bizTypes, (List) fieldBeans);
            }
            @SuppressWarnings("unchecked")
            Class<BaseModel> pClass = (Class<BaseModel>) pclass;
            PageData<BaseModel> page = beetMapper.findPage(fieldBeans, pClass);
            return this.mapPage(bizTypes, fieldBeans, page);
        } finally {
            afterSql("page", _start);
        }
    }

    private void insert(D d) {
        long _start = beforeSql("insert");
        try {
            // 1. 设置创建人和修改人、创建时间和修改时间
            d.setId(null);
            d.setIsDeleted(false);
            d.setCreator(getUserInfo());
            d.setModifier(getUserInfo());
            d.setGmtCreated(LocalDateTime.now());
            d.setGmtModified(LocalDateTime.now());

            // 2.1 新增之前的操作
            preInsert(d);
            d.setId(null);
            // 2.2 新增数据
            beetMapper.insert(d, pclass);

            // 2.3 新增之后的操作
            postInsert(d.getId(), d);
        } finally {
            afterSql("insert", _start);
        }
    }

    @Override
    @Transactional
    public Long insert(Object param) {
        D d = BeanMapper.map(param, dclass);
        d.setId(null);
        List<D> ds = new ArrayList<>(Collections.singletonList(d));
        // 兼容批量新增前操作
        preInsert(ds);
        ds.forEach(dd -> dd.setId(null));
        // 新增操作
        this.insert(d);
        // 兼容批量新增后操作
        postInsert(ds.stream().map(BaseModel::getId).collect(Collectors.toList()), ds);
        return d.getId();
    }

    @Override
    @Transactional
    public Long insert(Object... params) {
        D d = BeanMapper.map(params, dclass);
        d.setId(null);
        List<D> ds = new ArrayList<>(Collections.singletonList(d));
        // 兼容批量新增前操作
        preInsert(ds);
        ds.forEach(dd -> dd.setId(null));
        // 新增操作
        this.insert(d);
        // 兼容批量新增后操作
        postInsert(ds.stream().map(BaseModel::getId).collect(Collectors.toList()), ds);
        return d.getId();
    }

    @Override
    @Transactional
    public Long insert(Collection<FieldBean> fieldBeans) {
        fieldBeans.removeIf(Objects::isNull);
        // fieldBeans转Map
        Map<String, Object> params = fieldBeans
                .stream()
                .filter(s -> s.getValue() != null)
                .collect(Collectors.toMap(FieldBean::getName, FieldBean::getValue));
        D d = BeanMapper.map(params, dclass);
        d.setId(null);

        List<D> ds = new ArrayList<>(Collections.singletonList(d));
        // 兼容批量新增前操作
        preInsert(ds);
        ds.forEach(dd -> dd.setId(null));
        // 新增操作
        this.insert(d);
        // 兼容批量新增后操作
        postInsert(ds.stream().map(BaseModel::getId).collect(Collectors.toList()), ds);
        return d.getId();
    }

    @Override
    @Transactional
    public void inserts(Collection<D> ds) {
        if (CollectionUtils.isEmpty(ds)) return;
        long _start = beforeSql("inserts");
        try {
            ds.removeIf(Objects::isNull);
            preInsert(new ArrayList<>(ds));
            ds.forEach(d -> {
                d.setIsDeleted(false);
                d.setCreator(getUserInfo());
                d.setModifier(getUserInfo());
                d.setGmtCreated(LocalDateTime.now());
                d.setGmtModified(LocalDateTime.now());
            });
            beetMapper.inserts(ds, dclass);
            // 兼容批量新增后操作
            postInsert(ds.stream().map(BaseModel::getId).collect(Collectors.toList()), new ArrayList<>(ds));
        } finally {
            afterSql("inserts", _start);
        }
    }

    @Override
    @Transactional
    public void updates(Collection<D> ds) {
        if (CollectionUtils.isEmpty(ds)) return;
        long _start = beforeSql("updates");
        try {
            ds.forEach(d -> {
                d.setModifier(getUserInfo());
                d.setGmtModified(LocalDateTime.now());
            });
            beetMapper.updates(ds, dclass);
        } finally {
            afterSql("updates", _start);
        }
    }

    @Override
    @Transactional
    public Boolean update(Object param) {
        long _start = beforeSql("update");
        try {
            D d = BeanMapper.map(param, dclass);
            Assert.notNull(d, String.format("Update %s failed, data is null! ", beanname));
            Assert.notNull(d.getId(), String.format("update %s failed, id is null! ", beanname));

            // 1. 设置创修改人、改时间
            d.setModifier(getUserInfo());
            d.setGmtModified(LocalDateTime.now());

            List<Long> ids = Collections.singletonList(d.getId());
            List<D> ds = Collections.singletonList(d);

            preUpdate(d.getId(), d);
            preUpdate(ids, ds);

            // 2. 修改
            Collection<FieldBean> fieldBeans = new ArrayList<>(Collections.singleton(eq(BaseModel::getId, d.getId())));
            if (!beetMapper.update(fieldBeans, d, pclass)) {
                throw new EasysqlException(String.format("Update %s failed, data「%s」 dost't exists! ", beanname, fieldBeansToString(fieldBeans)));
            }

            postUpdate(d.getId(), d);
            postUpdate(ids, ds);
            return true;
        } finally {
            afterSql("update", _start);
        }
    }

    @Override
    @Transactional
    public Boolean update(Collection<FieldBean> fieldBeans) {
        long _start = beforeSql("update");
        try {
            Map<String, Object> map = new HashMap<>();
            fieldBeans.stream().filter(f -> f != null && f.getQueryType() == QueryType.UPDATE).forEach(f -> map.put(f.getName(), f.getValue()));
            if (map.isEmpty()) {
                throw new EasysqlException(String.format("Update %s failed, query fields is empty!", beanname));
            }
            D d = BeanMapper.map(map, dclass);
            d.setModifier(getUserInfo());
            d.setGmtModified(LocalDateTime.now());

            return beetMapper.update(fieldBeans, d, pclass);
        } finally {
            afterSql("update", _start);
        }
    }

    @Override
    @Transactional
    public Boolean delete(Collection<FieldBean> fieldBeans) {
        long _start = beforeSql("delete");
        try {
            if (fieldBeans == null || fieldBeans.isEmpty()) {
                throw new EasysqlException(String.format("Delete %s failed, fieldBeans is empty!", beanname));
            }
            fieldBeans.removeIf(Objects::isNull);
            fieldBeans.add(attr(BaseModel::getId));
            List<D> deletes = BeanMapper.map(beetMapper.findList(fieldBeans, pclass), dclass);

            // todo 删除失败，事务没有回滚。有时间看一下
            if (deletes.isEmpty()) return true;

            List<Long> ids = deletes.stream().map(BaseModel::getId).collect(Collectors.toList());

            ids.forEach(this::preDelete);
            preDelete(ids);

            // 删除数据
            BaseModel delete = new BaseModel();
            delete.setIsDeleted(true);
            delete.setModifier(getUserInfo());
            delete.setGmtModified(LocalDateTime.now());
            if (!beetMapper.update(fieldBeans, BeanMapper.map(delete, dclass), pclass)) {
                throw new EasysqlException(String.format("Delete %s「%s」failed! ", beanname, fieldBeansToString(fieldBeans)));
            }

            ids.forEach(this::postDelete);
            postDelete(ids);

            return true;
        } finally {
            afterSql("delete", _start);
        }
    }

    /**
     * 相对上面的方法可以省掉一次查询
     *
     * @param ids   要删除数据的主键
     */
    @Override
    @Transactional
    public Boolean delete(List<Long> ids) {
        long _start = beforeSql("delete");
        try {
            ids.forEach(this::preDelete);
            preDelete(ids);

            // 删除数据
            BaseModel delete = new BaseModel();
            delete.setIsDeleted(true);
            delete.setModifier(getUserInfo());
            delete.setGmtModified(LocalDateTime.now());

            List<FieldBean> fieldBeans = new ArrayList<>();
            fieldBeans.add(id(ids));
            if (!beetMapper.update(fieldBeans, BeanMapper.map(delete, dclass), pclass)) {
                throw new EasysqlException(String.format("Delete %s「%s」failed! ", beanname, fieldBeansToString(fieldBeans)));
            }

            ids.forEach(this::postDelete);
            postDelete(ids);

            return true;
        } finally {
            afterSql("delete", _start);
        }
    }

    private List<D> mapDTO(List<Enum<?>> bizTypes, List<BaseModel> os) {
        List<D> ds = BeanMapper.map(os, dclass);
        List<Long> ids = ds.stream().map(BaseModel::getId).collect(Collectors.toList());
        // 自定义业务处理
        if (!ds.isEmpty()) {
            ds.forEach(d -> {
                warpDTO(d.getId(), d);

                warpDTO(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), d.getId(), d);
                warpDTO(bizTypes, d.getId(), d);
            });
            warpDTO(ids, ds);

            warpDTO(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), ids, ds);
            warpDTO(bizTypes, ids, ds);
        }
        return ds;
    }

    private List<D> mapList(List<Enum<?>> bizTypes, List<BaseModel> os) {
        if (os == null) return null;

        List<D> ds = BeanMapper.map(os, dclass);
        List<Long> ids = ds.stream().map(BaseModel::getId).collect(Collectors.toList());

        if (!ds.isEmpty()) {
            // 自定义业务处理
            ds.forEach(d -> {
                this.warpDTO(d.getId(), d);

                this.warpDTO(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), d.getId(), d);
                this.warpDTO(bizTypes, d.getId(), d);
            });

            this.warpDTO(ids, ds);

            this.warpDTO(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), ids, ds);
            this.warpDTO(bizTypes, ids, ds);

            // this.warpList(ids, ds);
            // this.warpList(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), ids, ds);
            // this.warpList(bizTypes, ids, ds);
        }

        return ds;
    }

    private PageData<D> mapPage(List<Enum<?>> bizTypes, Collection<FieldBean> fieldBean, PageData<BaseModel> page) {
        PageData<D> pageData = new PageData<>(page.getPageSize(),
                                              page.getPageIndex(),
                                              page.getPageCount(),
                                              page.getTotalCount(),
                                              BeanMapper.map(page.getData(), dclass));
        if (pageData.getTotalCount() == 0) pageData.setPageCount(0);

        List<D> ds = (List<D>) pageData.getData();
        List<Long> ids = ds.stream().map(BaseModel::getId).collect(Collectors.toList());

        if (!pageData.getData().isEmpty()) {
            // 自定义业务处理
            ds.forEach(d -> {
                this.warpDTO(d.getId(), d);

                this.warpDTO(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), d.getId(), d);
                this.warpDTO(bizTypes, d.getId(), d);
            });

            this.warpDTO(ids, ds);

            this.warpDTO(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), ids, ds);
            this.warpDTO(bizTypes, ids, ds);

            this.warpPage(ids, ds);

            this.warpPage(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), ids, ds);
            this.warpPage(bizTypes, ids, ds);
        }

        // 分页附加数据
        Map<String, Object> ext = new HashMap<>();
        pageData.setExt(ext);
        // this.warpExt(CollectionUtils.isEmpty(bizTypes) ? null : bizTypes.get(0), (List) fieldBean, ext);
        // this.warpExt(bizTypes, (List) fieldBean, ext);
        // this.warpExt(bizTypes, (List) fieldBean, ids, ext);
        // this.warpExt(bizTypes, (List) fieldBean, ids, ds, ext);

        return pageData;
    }


    protected void warpDTO(Long id, D d) {

    }

    protected void warpDTO(Enum<?> bizType, Long id, D d) {

    }

    protected void warpDTO(List<Enum<?>> bizType, Long id, D d) {

    }

    protected void warpDTO(List<Long> ids, List<D> ds) {

    }

    protected void warpDTO(Enum<?> bizType, List<Long> ids, List<D> ds) {

    }

    protected void warpDTO(List<Enum<?>> bizType, List<Long> ids, List<D> ds) {

    }
//
//    protected void warpList(List<Long> ids, List<D> ds) {
//
//    }
//
//    protected void warpList(Enum<?> bizType, List<Long> ids, List<D> ds) {
//
//    }
//
//    protected void warpList(List<Enum<?>> bizType, List<Long> ids, List<D> ds) {
//
//    }

    protected void warpPage(List<Long> ids, List<D> ds) {

    }

    protected void warpPage(Enum<?> bizType, List<Long> ids, List<D> ds) {

    }

    protected void warpPage(List<Enum<?>> bizType, List<Long> ids, List<D> ds) {

    }

    //
//    protected void warpExt(Enum<?> bizType, List<FieldBean> fieldBeans, Map<String, Object> ext) {
//
//    }
//
//    protected void warpExt(List<Enum<?>> bizType, List<FieldBean> fieldBeans, Map<String, Object> ext) {
//
//    }
//
//    protected void warpExt(List<Enum<?>> bizType, List<FieldBean> fieldBeans, List<Long> ids, Map<String, Object> ext) {
//
//    }
//
//    protected void warpExt(List<Enum<?>> bizType, List<FieldBean> fieldBeans, List<Long> ids, List<D> ds, Map<String, Object> ext) {
//
//    }
//
    protected void warpDetail(Long id, D d) {

    }

    protected void warpDetail(Enum<?> bizType, Long id, D d) {

    }

    protected void warpDetail(List<Enum<?>> bizType, Long id, D d) {

    }

    protected void warpAttr(Enum<?> bizType, List<FieldBean> fieldBeans) {
    }

    protected void warpAttr(List<Enum<?>> bizType, List<FieldBean> fieldBeans) {
    }

    protected void preInsert(D d) {
    }

    protected void preInsert(List<D> ds) {
    }

    protected void postInsert(Long id, D d) {
    }

    protected void postInsert(List<Long> ids, List<D> ds) {
    }

    protected void preUpdate(Long id, D d) {

    }

    protected void preUpdate(List<Long> ids, List<D> ds) {

    }

    protected void postUpdate(Long id, D d) {
    }

    protected void postUpdate(List<Long> ids, List<D> ds) {

    }

    protected void preDelete(Long id) {

    }

    protected void preDelete(List<Long> ids) {

    }

    protected void postDelete(Long id) {
    }

    protected void postDelete(List<Long> ids) {

    }
}
