package org.easyframework.easysql.repository;


import org.easyframework.easysql.model.BaseModel;
import org.easyframework.easysql.model.FieldBean;
import org.easyframework.easysql.model.Property;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.easyframework.easysql.model.QueryParam.attr;
import static org.easyframework.easysql.model.QueryParam.id;

public interface BaseService<D extends BaseModel> extends QueryService<D>, ModifyService<D> {

    /**
     * 针对一个修改后的列表，判断是需要新增、修改还是删除
     * @param news      当前修改后的数据
     * @param listRules 查询规则
     */
    default <T extends BaseModel> void updateOrDelete(List<T> news, FieldBean... listRules) {
        // 1. 找出旧的数据
        List<FieldBean> fieldBeans = new ArrayList<>(Arrays.asList(listRules));
        fieldBeans.add(attr(BaseModel::getId));
        List<D> olds = this.list(fieldBeans);

        // 2. 计算出新添加的Id，和旧数据的Id
        List<Long> oldIds = olds.stream().map(BaseModel::getId).collect(Collectors.toList());
        List<Long> newIds = news.stream().map(BaseModel::getId).collect(Collectors.toList());

        // 4. 修改
        news.stream().filter(n -> oldIds.contains(n.getId())).forEach(this::update);
        // 3. 新增
        news.stream().filter(n -> !oldIds.contains(n.getId())).forEach(this::insert);
        // 5. 删除
        oldIds.removeAll(newIds);
        if (!oldIds.isEmpty()) {
            this.delete(id(oldIds));
        }
    }

    /**
     * 针对一个修改后的列表，判断是需要新增、修改还是删除
     * @param news              核对的数据
     * @param property          核对的字段
     * @param existsDataConds   已存在的数据的查询条件
     * @param <T>               数据类
     */
    default <T extends BaseModel> void updateOrDelete(List<D> news, Property<T, ?> property, FieldBean... existsDataConds) {
        // 1. 找出已经存在的数据
        List<FieldBean> fieldBeans = new ArrayList<>(Arrays.asList(existsDataConds));
        fieldBeans.add(attr(property));
        List<D> olds = this.list(fieldBeans);

        // 2. 找出需要新增的数据
        this.inserts(news.stream().filter(n -> olds.stream().noneMatch(o -> property.getValue(o).equals(property.getValue(n)))).collect(Collectors.toList()));

        // 3. 找出需要修改的数据
        olds.forEach(o -> {
            D d = news.stream().filter(n -> property.getValue(n).equals(property.getValue(o))).findAny().orElse(null);
            if (d != null) {
                d.setId(o.getId());
                this.update(d);
            }
        });

        // 4. 找出需要删除的数据
        List<Long> deleteIds = olds.stream().filter(n -> news.stream().noneMatch(o -> property.getValue(o).equals(property.getValue(n)))).map(BaseModel::getId).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(deleteIds)) {
            this.delete(id(deleteIds));
        }
    }
}