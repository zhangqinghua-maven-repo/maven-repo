package org.easyframework.easysql.exception;

public class EasysqlException extends RuntimeException {


    /**
     * 构造新实例。
     */
    public EasysqlException() {
    }

    /**
     * 用给定的异常信息构造新实例。
     *
     * @param errorMessage 异常信息。
     */
    public EasysqlException(String errorMessage) {
        super(errorMessage);
    }

    public EasysqlException(String errorMessage, Throwable cause) {
        super(errorMessage == null || errorMessage.equals("") ? cause.toString() : errorMessage, cause);
    }
}
