package org.easyframework.easysql.ddl.model;

import java.util.List;
import java.util.Optional;

/**
 * 数据库中已存在的表结构。
 */
public record TableMeta(String name, List<ColumnMeta> columns) {

    public boolean hasColumn(String columnName) {
        return findColumn(columnName).isPresent();
    }

    public Optional<ColumnMeta> findColumn(String columnName) {
        return columns.stream()
                .filter(column -> column.name().equals(columnName))
                .findAny();
    }
}
