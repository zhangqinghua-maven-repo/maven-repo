package org.easyframework.easysql.repository;

import org.easyframework.easysql.model.*;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.easyframework.easysql.model.QueryParam.*;

public interface QueryService<D extends BaseModel> {

    default Boolean exists() {
        return this.exists(eq(BaseModel::getIsDeleted, false));
    }

    default Boolean exists(Long id) {
        return this.exists(eq(BaseModel::getId, id));
    }

    default Boolean exists(Object param) {
        return this.exists(QueryParam.object2FieldBeans(param));
    }

    default Boolean exists(Object... params) {
        return this.exists(QueryParam.array2FieldBeans(params));
    }

    default Boolean exists(FieldBean fieldBean) {
        return this.exists(new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default Boolean exists(FieldBean... fieldBeans) {
        return this.exists(Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    Boolean exists(Collection<FieldBean> fieldBeans);


    default <R> R sum(Property<D, R> property, Long id) {
        return this.sum(property, eq(BaseModel::getId, id));
    }

    default <R> List<D> sum(Property<D, R> groupProperty, Property<D, R> sumProperty, Long id) {
        return this.sum(groupProperty, sumProperty, eq(BaseModel::getId, id));
    }

    default <R> R sum(Property<D, R> property, Object param) {
        return this.sum(property, QueryParam.object2FieldBeans(param));
    }

    default <R> List<D> sum(Property<D, R> groupProperty, Property<D, R> sumProperty, Object param) {
        return this.sum(groupProperty, sumProperty, QueryParam.object2FieldBeans(param));
    }

    default <R> R sum(Property<D, R> property, Object... params) {
        return this.sum(property, QueryParam.array2FieldBeans(params));
    }

    default <R> List<D> sum(Property<D, R> groupProperty, Property<D, R> sumProperty, Object... params) {
        return this.sum(groupProperty, sumProperty, QueryParam.array2FieldBeans(params));
    }

    default <R> R sum(Property<D, R> property, FieldBean fieldBean) {
        return this.sum(property, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default <R> List<D> sum(Property<D, R> groupProperty, Property<D, R> sumProperty, FieldBean fieldBean) {
        return this.sum(groupProperty, sumProperty, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default <R> R sum(Property<D, R> property, FieldBean... fieldBeans) {
        return this.sum(property, Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default <R> List<D> sum(Property<D, R> groupProperty, Property<D, R> sumProperty, FieldBean... fieldBeans) {
        return this.sum(groupProperty, sumProperty, Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default <R> R sum(Property<D, R> property, Collection<FieldBean> fieldBeans) {
        return this.sum(property.getName(), property.getType(), fieldBeans);
    }

    <R> R sum(String property, Class<R> propertyClz, Collection<FieldBean> fieldBeans);

    default <R> List<D> sum(Property<D, R> groupProperty, Property<D, R> sumProperty, Collection<FieldBean> fieldBeans) {
        return this.sum(groupProperty.getName(), sumProperty.getName(), fieldBeans);
    }

    default List<D> sum(String groupProperty, String sumProperty, Collection<FieldBean> fieldBeans) {
        return this.sum(groupProperty, sumProperty, sumProperty, fieldBeans);
    }

    List<D> sum(String groupProperty, String sumProperty, String valueProperty, Collection<FieldBean> fieldBeans);

    default Integer count() {
        return this.count(eq(BaseModel::getIsDeleted, false));
    }

    default Integer count(Long id) {
        return this.count(eq(BaseModel::getId, id));
    }

    default <R> List<D> count(Property<D, R> groupProperty, Property<D, R> countProperty, Long id) {
        return this.count(groupProperty, countProperty, eq(BaseModel::getId, id));
    }

    default Integer count(Object param) {
        return this.count(QueryParam.object2FieldBeans(param));
    }

    default <R> List<D> count(Property<D, R> groupProperty, Property<D, R> countProperty, Object param) {
        return this.count(groupProperty, countProperty, QueryParam.object2FieldBeans(param));
    }

    default Integer count(Object... params) {
        return this.count(QueryParam.array2FieldBeans(params));
    }

    default <R> List<D> count(Property<D, R> groupProperty, Property<D, R> countProperty, Object... params) {
        return this.count(groupProperty, countProperty, QueryParam.array2FieldBeans(params));
    }

    default Integer count(FieldBean fieldBean) {
        return this.count(new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default <R> List<D> count(Property<D, R> groupProperty, Property<D, R> countProperty, FieldBean fieldBean) {
        return this.count(groupProperty, countProperty, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default Integer count(FieldBean... fieldBeans) {
        return this.count(Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default <R> List<D> count(Property<D, R> groupProperty, Property<D, R> countProperty, FieldBean... fieldBeans) {
        return this.count(groupProperty, countProperty, Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default <R> List<D> count(Property<D, R> groupProperty, Property<D, R> countProperty, Collection<FieldBean> fieldBeans) {
        return this.count(groupProperty.getName(), countProperty.getName(), fieldBeans);
    }

    Integer count(Collection<FieldBean> fieldBeans);

    List<D> count(String groupProperty, String countProperty, Collection<FieldBean> fieldBeans);


    default D one() {
        return this.one(new ArrayList<>());
    }

    default D one(Enum<?> bizType) {
        return this.one(bizType, new ArrayList<>());
    }

    default D one(Long id) {
        return one(eq(D::getId, id));
    }

    default D one(Enum<?> bizType, Long id) {
        return one(bizType, eq(D::getId, id));
    }

    default D one(List<Enum<?>> bizType, Long id) {
        return one(bizType, eq(D::getId, id));
    }

    default D one(Object param) {
        return this.one(QueryParam.object2FieldBeans(param));
    }

    default D one(Enum<?> bizType, Object param) {
        return this.one(bizType, QueryParam.object2FieldBeans(param));
    }

    default D one(List<Enum<?>> bizType, Object param) {
        return this.one(bizType, QueryParam.object2FieldBeans(param));
    }

    default D one(Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.one(QueryParam.array2FieldBeans(params));
    }

    default D one(Enum<?> bizType, Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.one(bizType, QueryParam.array2FieldBeans(params));
    }

    default D one(List<Enum<?>> bizType, Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.one(bizType, QueryParam.array2FieldBeans(params));
    }

    default D one(FieldBean fieldBean) {
        return this.one(new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default D one(Enum<?> bizType, FieldBean fieldBean) {
        return this.one(bizType, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default D one(List<Enum<?>> bizType, FieldBean fieldBean) {
        return this.one(bizType, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default D one(FieldBean... fieldBeans) {
        return one(Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default D one(Enum<?> bizType, FieldBean... fieldBeans) {
        return one(bizType, Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default D one(List<Enum<?>> bizType, FieldBean... fieldBeans) {
        return one(bizType, Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default D one(List<FieldBean> fieldBeans) {
        return this.one(new ArrayList<>(), fieldBeans);
    }

    default D one(Enum<?> bizType, Collection<FieldBean> fieldBeans) {
        return this.one(Collections.singletonList(bizType), fieldBeans);
    }

    D one(List<Enum<?>> bizType, Collection<FieldBean> fieldBeans);


    default D oneornull() {
        return this.oneornull(new ArrayList<>(), new ArrayList<>());
    }

    default D oneornull(Enum<?> bizType) {
        return this.oneornull(bizType, new ArrayList<>());
    }

    default D oneornull(List<Enum<?>> bizType) {
        return this.oneornull(bizType, new ArrayList<>());
    }

    default D oneornull(Long id) {
        return oneornull(eq(D::getId, id));
    }

    default D oneornull(Enum<?> bizType, Long id) {
        return oneornull(bizType, eq(D::getId, id));
    }

    default D oneornull(List<Enum<?>> bizType, Long id) {
        return oneornull(bizType, eq(D::getId, id));
    }

    default D oneornull(Object param) {
        return this.oneornull(QueryParam.object2FieldBeans(param));
    }

    default D oneornull(Enum<?> bizType, Object param) {
        return this.oneornull(bizType, QueryParam.object2FieldBeans(param));
    }

    default D oneornull(List<Enum<?>> bizType, Object param) {
        return this.oneornull(bizType, QueryParam.object2FieldBeans(param));
    }

    default D oneornull(Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.oneornull(QueryParam.array2FieldBeans(params));
    }

    default D oneornull(Enum<?> bizType, Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.oneornull(bizType, QueryParam.array2FieldBeans(params));
    }

    default D oneornull(List<Enum<?>> bizType, Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.oneornull(bizType, QueryParam.array2FieldBeans(params));
    }

    default D oneornull(FieldBean fieldBean) {
        return this.oneornull(new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default D oneornull(Enum<?> bizType, FieldBean fieldBean) {
        return this.oneornull(bizType, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default D oneornull(List<Enum<?>> bizType, FieldBean fieldBean) {
        return this.oneornull(bizType, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default D oneornull(FieldBean... fieldBeans) {
        return oneornull(Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default D oneornull(Enum<?> bizType, FieldBean... fieldBeans) {
        return oneornull(bizType, Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default D oneornull(List<Enum<?>> bizType, FieldBean... fieldBeans) {
        return oneornull(bizType, Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default D oneornull(Collection<FieldBean> fieldBeans) {
        return this.oneornull(new ArrayList<>(), fieldBeans);
    }

    default D oneornull(Enum<?> bizType, Collection<FieldBean> fieldBeans) {
        return this.oneornull(Collections.singletonList(bizType), fieldBeans);
    }

    D oneornull(List<Enum<?>> bizType, Collection<FieldBean> fieldBeans);

    default D detail() {
        return this.detail(new ArrayList<>(), new ArrayList<>());
    }

    default D detail(Enum<?> bizType) {
        return this.detail(bizType, new ArrayList<>());
    }

    default D detail(List<Enum<?>> bizType) {
        return this.detail(bizType, new ArrayList<>());
    }

    default D detail(Long id) {
        return detail(eq(D::getId, id));
    }

    default D detail(Enum<?> bizType, Long id) {
        return detail(bizType, eq(D::getId, id));
    }

    default D detail(List<Enum<?>> bizType, Long id) {
        return detail(bizType, eq(D::getId, id));
    }

    default D detail(Object param) {
        return this.detail(QueryParam.object2FieldBeans(param));
    }

    default D detail(Enum<?> bizType, Object param) {
        return this.detail(bizType, QueryParam.object2FieldBeans(param));
    }

    default D detail(List<Enum<?>> bizType, Object param) {
        return this.detail(bizType, QueryParam.object2FieldBeans(param));
    }

    default D detail(Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.detail(QueryParam.array2FieldBeans(params));
    }

    default D detail(Enum<?> bizType, Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.detail(bizType, QueryParam.array2FieldBeans(params));
    }

    default D detail(List<Enum<?>> bizType, Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.detail(bizType, QueryParam.array2FieldBeans(params));
    }

    default D detail(FieldBean fieldBean) {
        return this.detail(new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default D detail(Enum<?> bizType, FieldBean fieldBean) {
        return this.detail(bizType, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default D detail(List<Enum<?>> bizType, FieldBean fieldBean) {
        return this.detail(bizType, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default D detail(FieldBean... fieldBeans) {
        return detail(Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default D detail(Enum<?> bizType, FieldBean... fieldBeans) {
        return detail(bizType, Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default D detail(List<Enum<?>> bizType, FieldBean... fieldBeans) {
        return detail(bizType, Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default D detail(Collection<FieldBean> fieldBeans) {
        return this.detail(new ArrayList<>(), fieldBeans);
    }

    default D detail(Enum<?> bizType, Collection<FieldBean> fieldBeans) {
        return this.detail(Collections.singletonList(bizType), fieldBeans);
    }

    D detail(List<Enum<?>> bizType, Collection<FieldBean> fieldBeans);

    default D detailornull() {
        return this.detailornull(new ArrayList<>(), new ArrayList<>());
    }

    default D detailornull(Enum<?> bizType) {
        return this.detailornull(bizType, new ArrayList<>());
    }

    default D detailornull(List<Enum<?>> bizType) {
        return this.detailornull(bizType, new ArrayList<>());
    }

    default D detailornull(Long id) {
        return detailornull(eq(D::getId, id));
    }

    default D detailornull(Enum<?> bizType, Long id) {
        return detailornull(bizType, eq(D::getId, id));
    }

    default D detailornull(List<Enum<?>> bizType, Long id) {
        return detailornull(bizType, eq(D::getId, id));
    }

    default D detailornull(Object param) {
        return this.detailornull(QueryParam.object2FieldBeans(param));
    }

    default D detailornull(Enum<?> bizType, Object param) {
        return this.detailornull(bizType, QueryParam.object2FieldBeans(param));
    }

    default D detailornull(List<Enum<?>> bizType, Object param) {
        return this.detailornull(bizType, QueryParam.object2FieldBeans(param));
    }

    default D detailornull(Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.detailornull(QueryParam.array2FieldBeans(params));
    }

    default D detailornull(Enum<?> bizType, Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.detailornull(bizType, QueryParam.array2FieldBeans(params));
    }

    default D detailornull(List<Enum<?>> bizType, Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.detailornull(bizType, QueryParam.array2FieldBeans(params));
    }

    default D detailornull(FieldBean fieldBean) {
        return this.detailornull(new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default D detailornull(Enum<?> bizType, FieldBean fieldBean) {
        return this.detailornull(bizType, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default D detailornull(List<Enum<?>> bizType, FieldBean fieldBean) {
        return this.detailornull(bizType, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default D detailornull(FieldBean... fieldBeans) {
        return detailornull(Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default D detailornull(Enum<?> bizType, FieldBean... fieldBeans) {
        return detailornull(bizType, Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default D detailornull(List<Enum<?>> bizType, FieldBean... fieldBeans) {
        return detailornull(bizType, Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    default D detailornull(Collection<FieldBean> fieldBeans) {
        return this.detailornull(new ArrayList<>(), fieldBeans);
    }

    default D detailornull(Enum<?> bizType, Collection<FieldBean> fieldBeans) {
        return this.detailornull(Collections.singletonList(bizType), fieldBeans);
    }

    D detailornull(List<Enum<?>> bizType, Collection<FieldBean> fieldBeans);

    default List<D> list() {
        return this.list(new ArrayList<>(), new ArrayList<>());
    }

    default List<D> list(Enum<?> bizType) {
        return this.list(bizType, new ArrayList<>());
    }

    default List<D> list(List<Enum<?>> bizType) {
        return this.list(bizType, new ArrayList<>());
    }

    default List<D> list(Object param) {
        return this.list(QueryParam.object2FieldBeans(param));
    }

    default List<D> list(Enum<?> bizType, Object param) {
        return this.list(bizType, QueryParam.object2FieldBeans(param));
    }

    default List<D> list(List<Enum<?>> bizType, Object param) {
        return this.list(bizType, QueryParam.object2FieldBeans(param));
    }

    default List<D> list(Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.list(QueryParam.array2FieldBeans(params));
    }

    default List<D> list(Enum<?> bizType, Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.list(bizType, QueryParam.array2FieldBeans(params));
    }

    default List<D> list(List<Enum<?>> bizType, Object... params) {
        // name,zhangqinghua,sex,male -> name = zhangqinghua, sex = male
        return this.list(bizType, QueryParam.array2FieldBeans(params));
    }

    default List<D> list(FieldBean fieldBean) {
        return this.list(new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default List<D> list(Enum<?> bizType, FieldBean fieldBean) {
        return this.list(bizType, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default List<D> list(List<Enum<?>> bizType, FieldBean fieldBean) {
        return this.list(bizType, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default List<D> list(FieldBean... fieldBeans) {
        return this.list(new ArrayList<>(Arrays.asList(fieldBeans)));
    }

    default List<D> list(Enum<?> bizType, FieldBean... fieldBeans) {
        return this.list(bizType, new ArrayList<>(Arrays.asList(fieldBeans)));
    }

    default List<D> list(List<Enum<?>> bizType, FieldBean... fieldBeans) {
        return this.list(bizType, new ArrayList<>(Arrays.asList(fieldBeans)));
    }

    default List<D> list(Collection<FieldBean> fieldBeans) {
        return this.list((Enum<?>) null, fieldBeans);
    }

    default List<D> list(Enum<?> bizType, Collection<FieldBean> fieldBeans) {
        return this.list(Collections.singletonList(bizType), fieldBeans);
    }

    List<D> list(List<Enum<?>> bizType, Collection<FieldBean> fieldBeans);


    default PageData<D> page() {
        return this.page(pageIndex(1), pageSize(10));
    }

    default PageData<D> page(Enum<?> bizType) {
        return this.page(bizType, pageIndex(1), pageSize(10));
    }

    default PageData<D> page(List<Enum<?>> bizType) {
        return this.page(bizType, pageIndex(1), pageSize(10));
    }

    default PageData<D> page(Object param) {
        return this.page(QueryParam.object2FieldBeans(param));
    }

    default PageData<D> page(Enum<?> bizType, Object param) {
        return this.page(bizType, QueryParam.object2FieldBeans(param));
    }

    default PageData<D> page(List<Enum<?>> bizType, Object param) {
        return this.page(bizType, QueryParam.object2FieldBeans(param));
    }

    default PageData<D> page(Object... params) {
        return this.page(QueryParam.array2FieldBeans(params));
    }

    default PageData<D> page(Enum<?> bizType, Object... params) {
        return this.page(bizType, QueryParam.array2FieldBeans(params));
    }

    default PageData<D> page(List<Enum<?>> bizType, Object... params) {
        return this.page(bizType, QueryParam.array2FieldBeans(params));
    }

//    default PageData<D> page(PageParam param) {
//        return this.page(QueryParam.object2FieldBeans(param));
//    }
//
//    default PageData<D> page(Enum<?> bizType, PageParam param) {
//        return this.page(bizType, QueryParam.object2FieldBeans(param));
//    }
//
//    default PageData<D> page(List<Enum<?>> bizType, PageParam param) {
//        return this.page(bizType, QueryParam.object2FieldBeans(param));
//    }

    default PageData<D> page(FieldBean fieldBean) {
        return this.page(new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default PageData<D> page(Enum<?> bizType, FieldBean fieldBean) {
        return this.page(bizType, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default PageData<D> page(List<Enum<?>> bizType, FieldBean fieldBean) {
        return this.page(bizType, new ArrayList<>(Collections.singleton(fieldBean)));
    }

    default PageData<D> page(FieldBean... fieldBeans) {
        return this.page(new ArrayList<>(Arrays.asList(fieldBeans)));
    }

    default PageData<D> page(Enum<?> bizType, FieldBean... fieldBeans) {
        return this.page(bizType, new ArrayList<>(Arrays.asList(fieldBeans)));
    }

    default PageData<D> page(List<Enum<?>> bizType, FieldBean... fieldBeans) {
        return this.page(bizType, new ArrayList<>(Arrays.asList(fieldBeans)));
    }

    default PageData<D> page(Collection<FieldBean> fieldBeans) {
        return this.page(new ArrayList<>(), fieldBeans);
    }

    default PageData<D> page(Enum<?> bizType, Collection<FieldBean> fieldBeans) {
        return this.page(Collections.singletonList(bizType), fieldBeans);
    }

    PageData<D> page(List<Enum<?>> bizType, Collection<FieldBean> fieldBeans);


}
