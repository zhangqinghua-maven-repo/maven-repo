// package org.easyframework.easysql.utils.reflect.exception;
//
//
// public class ReflectException extends RuntimeException {
//
//
//     /**
//      * 构造新实例。
//      */
//     public ReflectException() {
//     }
//
//     /**
//      * 用给定的异常信息构造新实例。
//      *
//      * @param errorMessage 异常信息。
//      */
//     public ReflectException(String errorMessage) {
//         super(errorMessage);
//     }
//
//     /**
//      * 用异常消息和表示异常原因的对象构造新实例。
//      *
//      * @param errorMessage 异常信息。
//      * @param cause        异常原因。
//      */
//     public ReflectException(String errorMessage, Throwable cause) {
//         super(errorMessage == null || errorMessage.equals("") ? cause.toString() : errorMessage, cause);
//     }
// }
