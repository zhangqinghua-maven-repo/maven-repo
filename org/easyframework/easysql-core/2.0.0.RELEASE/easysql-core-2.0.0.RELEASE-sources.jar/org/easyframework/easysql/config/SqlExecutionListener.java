package org.easyframework.easysql.config;

/**
 * SQL 执行监听器。
 * <p>
 * 下游项目实现此接口后通过 {@link org.easyframework.easysql.repository.impl.AbstractService#setSqlExecutionListener(SqlExecutionListener)}
 * 注册，即可在每次 SQL 执行前后插入自定义逻辑（如统计 SQL 调用次数、耗时等）。
 * <p>
 * 使用示例：
 * <pre>{@code
 * @PostConstruct
 * public void init() {
 *     AbstractService.setSqlExecutionListener(new SqlExecutionListener() {
 *         @Override
 *         public void before() {
 *             UserThreadLocal.plusSQLCount();
 *         }
 *         @Override
 *         public void after(long elapsedMs) {
 *             UserThreadLocal.plusSQLTime(elapsedMs);
 *         }
 *     });
 * }
 * }</pre>
 * <p>
 * 若未注册任何实现，则不做任何操作（零开销）。
 *
 * @author easysql
 * @since 2.0
 */
public interface SqlExecutionListener {

    /**
     * SQL 执行前回调（如统计调用次数）。
     *
     * method -> exists、sum、count、one、oneornull 之类的入口方法名
     */
    default void before(String method) {}

    /**
     * SQL 执行后回调（如记录耗时）。
     *
     * @param elapsedMs 本次 SQL 执行耗时，单位毫秒
     */
    default void after(String method, long elapsedMs) {}
}
