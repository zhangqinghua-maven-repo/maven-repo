package org.easyframework.easysql.ddl.enums;

public enum Type {
    /** 未指定，由框架根据 Java 字段类型自动推断 */
    NONE,

    // ========== 整数 ==========
    /** 字节（MySQL: int, PG: SMALLINT） */
    Byte,
    /** 短整数（MySQL: int, PG: SMALLINT） */
    Short,
    /** 整数（MySQL: int, PG: INTEGER） */
    INT,
    /** 长整数（MySQL: bigint, PG: BIGINT）—— 推荐用 {@link #LONG} */
    BIGINT,
    /** 长整数，语义等同于 BIGINT */
    LONG,

    // ========== 浮点数 ==========
    FLOAT,
    /** 双精度浮点 */
    DOUBLE,
    /** 精确小数（MySQL: decimal, PG: NUMERIC） */
    DECIMAL,

    // ========== 字符串 ==========
    /** 定长字符串 */
    CHAR,
    /** 变长字符串 */
    VARCHAR,
    /** 变长字符串（语义等同 VARCHAR，推荐使用） */
    STRING,
    /** 长文本（MySQL: TEXT, PG: TEXT） */
    TEXT,
    /** @deprecated 请用 {@link #TEXT}，PG 自动映射为 TEXT */
    @Deprecated MEDIUMTEXT,
    /** @deprecated 请用 {@link #TEXT}，PG 自动映射为 TEXT */
    @Deprecated LONGTEXT,

    // ========== 时间日期 ==========
    /**
     * 年份值（MySQL: year(4), PG: SMALLINT）
     * @deprecated 请用 {@link #INT}
     */
    @Deprecated YEAR,
    DATE, TIME, YEARMONTH,
    /** 日期时间（MySQL: datetime, PG: TIMESTAMP） */
    DATETIME,

    // ========== 跨数据库语义类型 ==========
    /** 布尔值（MySQL: tinyint(1), PG: BOOLEAN） */
    BOOL,
    /** UUID（MySQL: char(36), PG: UUID） */
    UUID,
    /** JSON 数据（MySQL: json, PG: JSONB） */
    JSON,
}
