package org.easyframework.easysql.config;

/**
 * 用户信息提供者接口。
 * <p>
 * 下游项目实现此接口并注册为 Spring Bean，统一提供当前操作用户信息。
 * 框架会在 insert/update/delete 等写操作时自动调用，填入 creator/modifier 字段。
 * <p>
 * 使用示例：
 * <pre>{@code
 * @Component
 * public class MyUserInfoProvider implements UserInfoProvider {
 *     @Override
 *     public String getUserInfo() {
 *         return UserThread.getUserEnum();
 *     }
 * }
 * }</pre>
 * <p>
 * 若未注册任何实现，默认返回 {@code "sys"}。
 *
 * @author easysql
 * @since 2.0
 */
@FunctionalInterface
public interface UserInfoProvider {

    /**
     * 获取当前操作用户标识（如用户名、用户ID等）。
     *
     * @return 用户标识字符串，不可为 null
     */
    String getUserInfo();
}
