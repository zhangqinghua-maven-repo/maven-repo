package org.easyframework.easysql.config;

import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
import org.springframework.boot.diagnostics.FailureAnalysis;

/**
 * 将 EasySQL 数据库启动异常转换成 Spring Boot 标准的 Description/Action 提示。
 */
public class DatabaseStartupFailureAnalyzer extends AbstractFailureAnalyzer<DatabaseStartupException> {

    @Override
    protected FailureAnalysis analyze(Throwable rootFailure, DatabaseStartupException cause) {
        return new FailureAnalysis(cause.getMessage(), cause.getAction(), cause);
    }
}
