package org.easyframework.easysql.config;

import org.easyframework.easysql.model.BaseModel;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * 实体类持有器。
 * <p>
 * 由 {@link EasySQLRegistrar} 从 {@code @EnableEasySQL} 注解填充，
 * 也可通过 {@link #addScanPackage(String)} 在 {@code @Configuration} 类中动态添加。
 * <p>
 * DDL 建表通过此类获取实体列表。
 *
 * <h3>动态配置扫描路径</h3>
 * <pre>{@code
 * @Configuration
 * public class EasySQLConfig {
 *     static {
 *         EasySQLEntities.addScanPackage("com.example.**.model");
 *     }
 * }
 * }</pre>
 */
public final class EasySQLEntities {

    private static final Set<Class<? extends BaseModel>> ENTITIES = new LinkedHashSet<>();
    private static final Set<String> SCAN_PACKAGES = new LinkedHashSet<>();

    private EasySQLEntities() {}

    /** 添加一个显式声明的实体类 */
    public static void addEntity(Class<? extends BaseModel> entity) {
        ENTITIES.add(entity);
    }

    /** 批量添加显式声明的实体类 */
    @SafeVarargs
    public static void addEntities(Class<? extends BaseModel>... entities) {
        for (Class<? extends BaseModel> e : entities) {
            ENTITIES.add(e);
        }
    }

    /** 添加类路径扫描包（JVM 模式使用） */
    public static void addScanPackage(String pkg) {
        if (pkg != null && !pkg.isEmpty()) {
            SCAN_PACKAGES.add(pkg);
        }
    }

    /** 获取所有已注册的实体类（不可变视图） */
    public static Set<Class<? extends BaseModel>> getEntities() {
        return Collections.unmodifiableSet(ENTITIES);
    }

    /** 获取所有扫描包 */
    public static Set<String> getScanPackages() {
        return Collections.unmodifiableSet(SCAN_PACKAGES);
    }

    /** 是否有显式注册的实体 */
    public static boolean hasExplicitEntities() {
        return !ENTITIES.isEmpty();
    }
}
