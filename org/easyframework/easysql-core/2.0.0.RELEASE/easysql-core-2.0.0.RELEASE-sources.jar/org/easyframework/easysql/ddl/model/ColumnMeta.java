package org.easyframework.easysql.ddl.model;

/**
 * 数据库中已存在的列结构，字段值已按当前方言标准化。
 */
public record ColumnMeta(
        String name,
        String type,
        String notnull,
        String def,
        String comment,
        boolean indexed) {

    public boolean deprecated() {
        return notnull.isEmpty() && comment.contains("（已废弃）");
    }

    public String deprecatedComment() {
        if (!comment.contains("（已废弃）") && !comment.isEmpty()) {
            String rawComment = comment.replace("COMMENT '", "").replace("'", "");
            return "COMMENT '" + rawComment + "（已废弃）'";
        }
        return comment;
    }
}
