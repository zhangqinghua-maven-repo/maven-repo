package org.easyframework.easysql.model;

import org.easyframework.easysql.config.EasySQLEntities;
import org.easyframework.easyutils.ReflectUtils;

import java.io.Serializable;
import java.lang.invoke.SerializedLambda;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;

/**
 * 属性提取器，支持方法引用（如 {@code SysUser::getUsername}）。
 * <p>
 * <b>解析策略（按优先级）：</b>
 * <ol>
 *   <li><b>SerializedLambda</b>：JVM 模式始终可用</li>
 *   <li><b>泛型接口反射</b>：从 {@code getGenericInterfaces()} 提取 {@code <T, R>}</li>
 *   <li><b>apply 方法签名</b>：从 {@code getMethods()} 中找非桥接 apply 方法</li>
 *   <li><b>实体注册表 + 标记值消歧</b>：遍历 {@link EasySQLEntities} 已注册实体，利用 lambda
 *       内部 {@code checkcast} 指令判定实体类型，再用标记值定位 getter。</li>
 * </ol>
 *
 * @param <T> 实体类型
 * @param <R> 属性类型
 */
public interface Property<T, R> extends Function<T, R>, Serializable {

    // ==================== 核心解析 ====================

    /**
     * 尝试通过 {@code writeReplace()} 获取 SerializedLambda。
     *
     * @return SerializedLambda 实例，若 writeReplace 不可用则返回 null
     */
    default SerializedLambda resolveLambda() {
        try {
            Method declaredMethod = this.getClass().getDeclaredMethod("writeReplace");
            declaredMethod.setAccessible(Boolean.TRUE);
            return (SerializedLambda) declaredMethod.invoke(this);
        } catch (NoSuchMethodException e) {
            return null;
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException("Failed to resolve SerializedLambda", e);
        }
    }

    /**
     * 降级方案：通过遍历 {@link EasySQLEntities} 已注册实体类找到 T。
     * <p>
     * 原理：lambda 内部会将 apply 参数强转为 T（即 {@code checkcast} 指令），
     * 如果实体类型不匹配会抛出 {@link ClassCastException}。利用此机制遍历所有已注册
     * 实体，唯一不会抛异常的即目标实体类型。
     */
    @SuppressWarnings("unchecked")
    default Class<T> resolveEntityClass() {
        Set<Class<? extends BaseModel>> entities = EasySQLEntities.getEntities();
        if (entities.isEmpty()) {
            throw new RuntimeException("No entities registered in EasySQLEntities. "
                    + "Use @EnableEasySQL(entities={...}) to register entity classes.");
        }
        List<Class<? extends BaseModel>> passed = new ArrayList<>();
        for (Class<? extends BaseModel> clz : entities) {
            try {
                Object marker = clz.getDeclaredConstructor().newInstance();
                this.apply((T) marker);
                passed.add(clz);
            } catch (ClassCastException e) {
                // 类型不匹配，继续尝试下一个
            } catch (Exception e) {
                // 无法实例化或其他错误，继续尝试下一个
            }
        }
        if (passed.isEmpty()) {
            throw new RuntimeException("Cannot determine entity class for "
                    + this.getClass().getName() + ". Tried " + entities.size()
                    + " registered entities, all failed.");
        }
        // 如果多个实体通过（如父子类），选择最具体的
        if (passed.size() == 1) {
            return (Class<T>) passed.get(0);
        }
        // 多个候选：排除能被其他候选赋值的（即父类）
        Class<? extends BaseModel> best = passed.get(0);
        for (Class<? extends BaseModel> c : passed) {
            if (c.isAssignableFrom(best) && c != best) {
                continue; // best 是 c 的子类，保留 best
            }
            if (best.isAssignableFrom(c) && best != c) {
                best = c; // c 是 best 的子类，选 c
            }
        }
        return (Class<T>) best;
    }

    // ==================== 工具方法 ====================

    /**
     * 将 getter/setter 方法名转为属性名。
     * {@code "getUsername" → "username"}
     */
    static String methodToProperty(String methodName) {
        String attr;
        if (methodName.startsWith("get") || methodName.startsWith("set")) {
            attr = methodName.substring(3);
        } else if (methodName.startsWith("is")) {
            attr = methodName.substring(2);
        } else {
            attr = methodName;
        }
        return Character.isLowerCase(attr.charAt(0))
                ? attr : Character.toLowerCase(attr.charAt(0)) + attr.substring(1);
    }

    /** 沿类层次查找字段（含父类）。 */
    private static Field findField(Class<?> clz, String fieldName) {
        Class<?> current = clz;
        while (current != null && current != Object.class) {
            try {
                return current.getDeclaredField(fieldName);
            } catch (NoSuchFieldException e) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    /** 为给定类型创建一个非 null 标记值。 */
    private static Object nonNullMarker(Class<?> type) {
        if (type == String.class) return "##EASYSQL_MARKER##";
        if (type == Long.class || type == long.class) return -99999999L;
        if (type == Integer.class || type == int.class) return -99999999;
        if (type == Boolean.class || type == boolean.class) return Boolean.TRUE;
        if (type == Double.class || type == double.class) return -99999999.0;
        if (type == Float.class || type == float.class) return -99999999.0f;
        if (type == Short.class || type == short.class) return (short) -9999;
        if (type == Byte.class || type == byte.class) return (byte) -99;
        if (type == Character.class || type == char.class) return 'X';
        if (type == java.time.LocalDateTime.class) return java.time.LocalDateTime.now();
        if (type == java.time.LocalDate.class) return java.time.LocalDate.now();
        if (type == java.time.LocalTime.class) return java.time.LocalTime.now();
        try {
            return type.getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            return new Object();
        }
    }

    /**
     * 在实体类上通过标记值消歧定位 getter（不需要提前知道返回类型 R）。
     * <ol>
     *   <li>收集所有候选 getter（无参、以 get/is 开头）</li>
     *   <li>唯一候选 → 直接返回</li>
     *   <li>多个候选 → 逐个字段设标记值，调用 {@link #apply(Object)} 匹配</li>
     * </ol>
     */
    @SuppressWarnings("unchecked")
    private String resolveGetterByMarkers(Class<?> clz) {
        // 1. 收集所有候选 getter（无参、非 static、以 get/is 开头）
        List<Method> candidates = new ArrayList<>();
        for (Method m : clz.getMethods()) {
            if (m.getParameterCount() != 0) continue;
            if (java.lang.reflect.Modifier.isStatic(m.getModifiers())) continue;
            String name = m.getName();
            if (!name.startsWith("get") && !name.startsWith("is")) continue;
            if ("getClass".equals(name)) continue;
            if (m.getDeclaringClass() == Object.class) continue;
            candidates.add(m);
        }

        if (candidates.isEmpty()) {
            throw new RuntimeException("No getter found on " + clz.getName());
        }

        // 2. 唯一候选 → 直接返回
        if (candidates.size() == 1) {
            return candidates.get(0).getName();
        }

        // 3. 多个候选 → 标记值消歧
        try {
            Object marker = clz.getDeclaredConstructor().newInstance();
            for (Method getter : candidates) {
                String propName = methodToProperty(getter.getName());
                Field field = findField(clz, propName);
                if (field == null) continue;
                // 跳过 static 或 final 字段（如 serialVersionUID）
                int mod = field.getModifiers();
                if (java.lang.reflect.Modifier.isStatic(mod)
                        || java.lang.reflect.Modifier.isFinal(mod)) continue;

                Object markerValue = nonNullMarker(field.getType());
                field.setAccessible(true);
                Object oldValue = field.get(marker);
                field.set(marker, markerValue);
                try {
                    Object result = this.apply((T) marker);
                    if (Objects.equals(result, markerValue)) {
                        return getter.getName();
                    }
                } finally {
                    field.set(marker, oldValue);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(
                    "Cannot disambiguate getter via marker values on " + clz.getName(), e);
        }

        // 4. 消歧失败
        StringBuilder sb = new StringBuilder();
        for (Method m : candidates) sb.append(m.getName()).append("(), ");
        if (sb.length() > 2) sb.setLength(sb.length() - 2);
        throw new RuntimeException("Cannot determine which getter is referenced. "
                + "Multiple candidates on " + clz.getName() + ": [" + sb + "]. "
                + "Consider using string-based property name instead.");
    }

    // ==================== Property API ====================

    /**
     * Order::getOrderStatus → "orderStatus"
     */
    default String getName() {
        // 1. 优先：SerializedLambda（普通 JVM 方法引用）
        SerializedLambda sl = resolveLambda();
        if (sl != null) {
            return methodToProperty(sl.getImplMethodName());
        }

        // 2. 次选：泛型接口 / apply 方法签名反射
        try {
            Class<T> clz = getTypeArg(0);
            Class<R> type = getTypeArg(1);
            // 收集候选 getter（按返回类型过滤）
            List<Method> candidates = new ArrayList<>();
            for (Method m : clz.getMethods()) {
                if (m.getParameterCount() != 0) continue;
                if (m.getReturnType() != type) continue;
                String name = m.getName();
                if (!name.startsWith("get") && !name.startsWith("is")) continue;
                if ("getClass".equals(name)) continue;
                if ("pclass".equals(name)) continue;
                if (m.getDeclaringClass() == Object.class) continue;
                candidates.add(m);
            }
            if (candidates.size() == 1) {
                return methodToProperty(candidates.get(0).getName());
            }
            // 多个候选则标记值消歧
            T marker = clz.getDeclaredConstructor().newInstance();
            for (Method getter : candidates) {
                String propName = methodToProperty(getter.getName());
                Field field = findField(clz, propName);
                if (field == null) continue;
                Object markerValue = nonNullMarker(field.getType());
                field.setAccessible(true);
                Object oldValue = field.get(marker);
                field.set(marker, markerValue);
                try {
                    if (Objects.equals(this.apply(marker), markerValue)) {
                        return methodToProperty(getter.getName());
                    }
                } finally {
                    field.set(marker, oldValue);
                }
            }
            throw new RuntimeException("Cannot disambiguate getter on " + clz.getName());
        } catch (RuntimeException e) {
            // 反射提取类型失败 → 降级到实体注册表方案
        } catch (Exception e) {
            // 其他异常 → 降级到实体注册表方案
        }

        // 3. 最终降级：实体注册表 + 标记值消歧
        Class<T> clz = resolveEntityClass();
        String getterName = resolveGetterByMarkers(clz);
        return methodToProperty(getterName);
    }

    /**
     * Order::getOrderStatus → OrderStatus.class
     */
    @SuppressWarnings("unchecked")
    default Class<R> getType() {
        // 1. SerializedLambda
        SerializedLambda sl = resolveLambda();
        if (sl != null) {
            String sig = sl.getImplMethodSignature();
            sig = sig.substring(3, sig.length() - 1);
            String typeName = sig.replaceAll("/", ".");
            try {
                return (Class<R>) Class.forName(typeName);
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }

        // 2. 反射提取
        try {
            return getTypeArg(1);
        } catch (RuntimeException e) {
            // 降级
        }

        // 3. 降级：实体注册表 + getter 返回类型
        Class<T> clz = resolveEntityClass();
        String getterName = resolveGetterByMarkers(clz);
        try {
            Method getter = clz.getMethod(getterName);
            return (Class<R>) getter.getReturnType();
        } catch (NoSuchMethodException e) {
            throw new RuntimeException("Getter not found: " + getterName + " on " + clz.getName(), e);
        }
    }

    /**
     * Order::getOrderStatus → Order.class
     */
    @SuppressWarnings("unchecked")
    default Class<T> getClz() {
        // 1. SerializedLambda
        SerializedLambda sl = resolveLambda();
        if (sl != null) {
            String imt = sl.getInstantiatedMethodType();
            imt = imt.substring(2);
            imt = imt.substring(0, imt.lastIndexOf(";)"));
            String clzName = imt.replaceAll("/", ".");
            try {
                return (Class<T>) Class.forName(clzName);
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }

        // 2. 反射提取
        try {
            return getTypeArg(0);
        } catch (RuntimeException e) {
            // 降级
        }

        // 3. 降级：实体注册表
        return resolveEntityClass();
    }

    /**
     * 获取属性值。
     * <pre>{@code
     *   PointProduct product = new PointProduct();
     *   product.setId(3545L);
     *   Property<PointProduct, Long> id = PointProduct::getId;
     *   System.out.println(id.getClz());          // class PointProduct
     *   System.out.println(id.getValue(product)); // 3545
     * }</pre>
     */
    @SuppressWarnings("unchecked")
    default R getValue(Object obj) {
        try {
            Field field = ReflectUtils.fields(this.getClz()).stream()
                    .filter(f -> f.getName().equals(getName()))
                    .findAny().orElse(null);
            if (field == null) return null;
            field.setAccessible(true);
            return (R) field.get(obj);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 从泛型接口或 apply 方法签名中提取第 index 个类型参数。
     * <pre>{@code
     *   Property<SysUser, String> → index=0 → SysUser.class
     *   Property<SysUser, String> → index=1 → String.class
     * }</pre>
     */
    @SuppressWarnings("unchecked")
    private <X> Class<X> getTypeArg(int index) {
        // 1. 尝试从泛型接口获取
        for (Type iface : this.getClass().getGenericInterfaces()) {
            if (iface instanceof ParameterizedType pt && pt.getRawType() == Property.class) {
                Type arg = pt.getActualTypeArguments()[index];
                if (arg instanceof Class<?> c) {
                    return (Class<X>) c;
                }
                if (arg instanceof ParameterizedType pt2) {
                    return (Class<X>) pt2.getRawType();
                }
            }
        }
        // 2. 降级：从 apply 方法签名提取类型参数
        for (Method m : this.getClass().getMethods()) {
            if (!"apply".equals(m.getName()) || m.getParameterCount() != 1) continue;
            Class<?> paramType = m.getParameterTypes()[0];
            Class<?> returnType = m.getReturnType();
            // 跳过桥接方法（参数和返回值都是 Object 的是桥接方法）
            if (paramType == Object.class && returnType == Object.class) continue;
            return index == 0 ? (Class<X>) paramType : (Class<X>) returnType;
        }
        throw new RuntimeException("Cannot determine type parameter " + index
                + " for " + this.getClass().getName());
    }
}
