package org.easyframework.easysql.mapper;

/**
 * Generates IDs from the Unix millisecond timestamp and a JVM-local sequence.
 *
 * <p>The six decimal suffix digits provide up to one million IDs per
 * millisecond in one JVM. Synchronization makes the timestamp/sequence pair
 * unique across concurrent threads.</p>
 */
final class TimestampIdGenerator {

    private static final long SEQUENCE_LIMIT = 1_000_000L;

    private long lastTimestamp = -1L;
    private long sequence;

    synchronized long nextId() {
        long timestamp = System.currentTimeMillis();
        if (timestamp < lastTimestamp) {
            throw new IllegalStateException("Clock moved backwards");
        }

        if (timestamp == lastTimestamp) {
            if (sequence + 1 >= SEQUENCE_LIMIT) {
                do {
                    Thread.onSpinWait();
                    timestamp = System.currentTimeMillis();
                } while (timestamp <= lastTimestamp);
                sequence = 0L;
            } else {
                sequence++;
            }
        } else {
            lastTimestamp = timestamp;
            sequence = 0L;
        }

        lastTimestamp = timestamp;
        return Math.addExact(Math.multiplyExact(timestamp, SEQUENCE_LIMIT), sequence);
    }
}
