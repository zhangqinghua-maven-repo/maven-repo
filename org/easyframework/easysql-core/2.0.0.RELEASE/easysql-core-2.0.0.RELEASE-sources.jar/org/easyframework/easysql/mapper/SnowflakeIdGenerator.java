package org.easyframework.easysql.mapper;

import java.util.concurrent.atomic.AtomicLong;

/** Lock-free Snowflake ID generator. */
final class SnowflakeIdGenerator {

    private static final long EPOCH = 1609459200000L;
    private static final long SEQUENCE_MASK = 4095L;

    private final AtomicLong lastTimestamp = new AtomicLong(-1L);
    private final AtomicLong sequence = new AtomicLong();

    long nextId() {
        while (true) {
            long now = System.currentTimeMillis();
            long last = lastTimestamp.get();
            if (now < last) {
                throw new IllegalStateException("Clock moved backwards");
            }
            if (now == last) {
                long nextSequence = sequence.incrementAndGet() & SEQUENCE_MASK;
                if (nextSequence != 0) return ((now - EPOCH) << 22) | nextSequence;
                while (System.currentTimeMillis() <= last) Thread.onSpinWait();
                lastTimestamp.set(System.currentTimeMillis());
                sequence.set(0);
                continue;
            }
            if (lastTimestamp.compareAndSet(last, now)) {
                sequence.set(0);
                return (now - EPOCH) << 22;
            }
        }
    }
}
