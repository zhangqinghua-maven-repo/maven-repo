package org.easyframework.easysql.repository;

import org.easyframework.easysql.model.BaseModel;
import org.easyframework.easysql.model.FieldBean;
import org.easyframework.easysql.model.QueryParam;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.easyframework.easysql.model.QueryParam.eq;

public interface ModifyService<D extends BaseModel> {

    @Transactional
    Long insert(Object param);

    @Transactional
    Long insert(Object... params);

    @Transactional
    default Long insert(FieldBean fieldBean) {
        return this.insert(new ArrayList<>(Collections.singleton(fieldBean)));
    }

    @Transactional
    default Long insert(FieldBean... fieldBeans) {
        return this.insert(new ArrayList<>(Arrays.asList(fieldBeans)));
    }

    @Transactional
    Long insert(Collection<FieldBean> fieldBeans);

    /**
     * 批量插入
     * 10000/s
     * 暂时没有 preInsert、postInsert
     */
    @Transactional
    void inserts(Collection<D> ds);

    @Transactional
    default Boolean update(Long id) {
        return this.update(eq(BaseModel::getId, id));
    }

    @Transactional
    Boolean update(Object param);

    @Transactional
    default Boolean update(Object... params) {
        return this.update(QueryParam.array2FieldBeans(params));
    }

    @Transactional
    default Boolean update(FieldBean fieldBean) {
        return this.update(new ArrayList<>(Collections.singleton(fieldBean)));
    }

    @Transactional
    default Boolean update(FieldBean... fieldBeans) {
        return this.update(Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    /**
     * 修改数据
     * 1. 可以修改多条数据
     * 1. 支持多条件匹配
     * 1. 修改的数据属性，值一致
     * <p>
     * data1: id -> 1, name -> zhangsan
     * data2: id -> 2, name -> zhangsan
     * <p>
     * todo 修改和删除涉及到批量的情况，后续要针对性处理
     */
    @Transactional
    Boolean update(Collection<FieldBean> fieldBeans);

    @Transactional
    void updates(Collection<D> ds);

    @Transactional
    default Boolean delete(Long id) {
        return this.delete(Collections.singletonList(id));
    }

    @Transactional
    default Boolean delete(Object param) {
        return this.delete(QueryParam.object2FieldBeans(param));
    }

    @Transactional
    default Boolean delete(Object... params) {
        return this.delete(QueryParam.array2FieldBeans(params));
    }

    @Transactional
    default Boolean delete(FieldBean fieldBean) {
        return this.delete(new ArrayList<>(Collections.singleton(fieldBean)));
    }

    @Transactional
    default Boolean delete(FieldBean... fieldBeans) {
        return this.delete(Stream.of(fieldBeans).collect(Collectors.toList()));
    }

    /**
     * 删除数据
     * - is_deleted = 'y'
     * - 对多个条件进行匹配
     * todo 修改和删除涉及到批量的情况，后续要针对性处理
     */
    @Transactional
    Boolean delete(Collection<FieldBean> fieldBeans);

    @Transactional
    Boolean delete(List<Long> ids);
}
