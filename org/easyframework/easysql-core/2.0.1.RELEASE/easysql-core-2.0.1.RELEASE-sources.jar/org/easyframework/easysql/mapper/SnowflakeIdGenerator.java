package org.easyframework.easysql.mapper;

import java.util.Objects;
import java.util.function.LongSupplier;

/**
 * Generates standard 64-bit Snowflake IDs.
 *
 * <p>The layout is 41 timestamp bits, 10 worker bits, and 12 sequence bits.
 * Applications running more than one instance must assign each live instance
 * a distinct {@code easysql.id.worker-id} in the range 0-1023.</p>
 */
final class SnowflakeIdGenerator {

    static final long EPOCH = 1609459200000L; // 2021-01-01T00:00:00Z
    static final long MAX_WORKER_ID = 1023L;

    private static final long SEQUENCE_MASK = 4095L;
    private static final long WORKER_ID_SHIFT = 12L;
    private static final long TIMESTAMP_SHIFT = 22L;
    private static final long MAX_TIMESTAMP = (1L << 41) - 1L;

    private final long workerId;
    private final LongSupplier currentTimeMillis;

    private long lastTimestamp = -1L;
    private long sequence;

    SnowflakeIdGenerator(long workerId) {
        this(workerId, System::currentTimeMillis);
    }

    SnowflakeIdGenerator(long workerId, LongSupplier currentTimeMillis) {
        if (workerId < 0 || workerId > MAX_WORKER_ID) {
            throw new IllegalArgumentException("workerId must be between 0 and " + MAX_WORKER_ID);
        }
        this.workerId = workerId;
        this.currentTimeMillis = Objects.requireNonNull(currentTimeMillis, "currentTimeMillis");
    }

    synchronized long nextId() {
        long timestamp = currentTimeMillis.getAsLong();
        if (timestamp < lastTimestamp) {
            throw new IllegalStateException(
                    "Clock moved backwards by " + (lastTimestamp - timestamp) + "ms");
        }

        if (timestamp == lastTimestamp) {
            sequence = (sequence + 1L) & SEQUENCE_MASK;
            if (sequence == 0L) {
                timestamp = waitUntilNextMillis(lastTimestamp);
            }
        } else {
            sequence = 0L;
        }

        long elapsed = timestamp - EPOCH;
        if (elapsed < 0L || elapsed > MAX_TIMESTAMP) {
            throw new IllegalStateException("Timestamp is outside the supported Snowflake range: " + timestamp);
        }

        lastTimestamp = timestamp;
        return (elapsed << TIMESTAMP_SHIFT) | (workerId << WORKER_ID_SHIFT) | sequence;
    }

    private long waitUntilNextMillis(long timestamp) {
        long current;
        do {
            Thread.onSpinWait();
            current = currentTimeMillis.getAsLong();
        } while (current <= timestamp);
        return current;
    }
}
