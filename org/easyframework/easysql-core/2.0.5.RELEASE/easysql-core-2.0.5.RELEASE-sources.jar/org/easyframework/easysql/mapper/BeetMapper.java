package org.easyframework.easysql.mapper;

import org.easyframework.easysql.annotations.Column;
import org.easyframework.easysql.ddl.dialect.DatabaseDialect;
import org.easyframework.easysql.ddl.enums.Type;
import org.easyframework.easysql.ddl.util.SQLUtils;
import org.easyframework.easysql.exception.EasysqlException;
import org.easyframework.easysql.model.BaseModel;
import org.easyframework.easysql.model.FieldBean;
import org.easyframework.easysql.model.PageData;
import org.easyframework.easysql.model.QueryParam.QueryType;
import org.easyframework.easyutils.ReflectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class BeetMapper extends org.easyframework.easysql.model.QueryParam {

    private static final Logger log = LoggerFactory.getLogger(BeetMapper.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    @Lazy
    private DatabaseDialect dialect;

    // ==================== ID Generator ====================

    private final SnowflakeIdGenerator idGenerator;

    public BeetMapper(@Value("${easysql.id.worker-id:0}") long workerId) {
        this.idGenerator = new SnowflakeIdGenerator(workerId);
    }

    // ==================== Field Metadata Cache ====================

    /** entityClass -> @Column 字段列表（反射结果缓存，运行时不变） */
    private static final ConcurrentMap<Class<?>, List<Field>> FIELD_CACHE = new ConcurrentHashMap<>();
    /** entityClass -> @Column 字段名列表 */
    private static final ConcurrentMap<Class<?>, List<String>> COLUMN_CACHE = new ConcurrentHashMap<>();
    /** entityClass -> (fieldName -> Field) 快速查找 */
    private static final ConcurrentMap<Class<?>, Map<String, Field>> NAME_FIELD_CACHE = new ConcurrentHashMap<>();
    private static final Pattern SAFE_IDENTIFIER = Pattern.compile("[A-Za-z_][A-Za-z0-9_]*");
    private static final Pattern SAFE_JSON_EXPRESSION = Pattern.compile(
            "(?i)(json_extract|json_unquote)\\(\\s*[`\"]?[A-Za-z_][A-Za-z0-9_]*[`\"]?\\s*,\\s*'\\$\\.[A-Za-z0-9_\\.\\[\\]]+'\\s*\\)"
            + "|[`\"]?[A-Za-z_][A-Za-z0-9_]*[`\"]?\\s*->>?\\s*'\\$\\.[A-Za-z0-9_\\.\\[\\]]+'");

    // ==================== JSON Serialization ====================

    /** Field -> true 表示该字段应作为 JSON 处理 */
    private static final ConcurrentMap<Field, Boolean> JSON_FIELD_CACHE = new ConcurrentHashMap<>();

    /**
     * 通过反射调用 JSON 库（Jackson / fastjson2），避免框架强制依赖特定 JSON 实现。
     * 若 classpath 上两者都没有，JSON 序列化/反序列化会静默跳过。
     */
    private static final class JsonHelper {
        private static final Object MAPPER;       // Jackson ObjectMapper 实例，或 null
        private static final Method WRITE_AS_STRING;
        private static final Method READ_VALUE;
        private static final Method FASTJSON_WRITE_AS_STRING;
        private static final Method FASTJSON_READ_VALUE;

        static {
            Object mapper = null;
            Method write = null;
            Method read = null;
            Method fastjsonWrite = null;
            Method fastjsonRead = null;

            // 1) 优先 Jackson
            try {
                Class<?> omClass = Class.forName("com.fasterxml.jackson.databind.ObjectMapper");
                mapper = omClass.getDeclaredConstructor().newInstance();
                write = omClass.getMethod("writeValueAsString", Object.class);
                read = omClass.getMethod("readValue", String.class, Class.class);
                try {
                    omClass.getMethod("findAndRegisterModules").invoke(mapper);
                } catch (Exception ignored) {
                    // Java time support is optional; use the fallback JSON library when needed.
                }
            } catch (Exception ignored) {
                // Jackson not available
            }

            // 2) 准备 fastjson2 回退（静态方法，无需实例）
            try {
                Class<?> jsonClass = Class.forName("com.alibaba.fastjson2.JSON");
                fastjsonWrite = jsonClass.getMethod("toJSONString", Object.class);
                fastjsonRead = jsonClass.getMethod("parseObject", String.class, Class.class);
            } catch (Exception ignored) {
                // fastjson2 not available
            }

            if (write == null && fastjsonWrite == null) {
                log.warn("No JSON library found on classpath. "
                         + "JSON fields will NOT be serialized — add jackson-databind or fastjson2 to your dependencies.");
            }

            MAPPER = mapper;
            WRITE_AS_STRING = write;
            READ_VALUE = read;
            FASTJSON_WRITE_AS_STRING = fastjsonWrite;
            FASTJSON_READ_VALUE = fastjsonRead;
        }

        static boolean available() {
            return WRITE_AS_STRING != null || FASTJSON_WRITE_AS_STRING != null;
        }

        static String toJson(Object value) {
            if (MAPPER != null) {
                try {
                    return (String) WRITE_AS_STRING.invoke(MAPPER, value);
                } catch (Exception jacksonFailure) {
                    if (FASTJSON_WRITE_AS_STRING == null) {
                        throw new EasysqlException("Failed to serialize object to JSON", jacksonFailure);
                    }
                }
            }
            try {
                if (FASTJSON_WRITE_AS_STRING != null) {
                    return (String) FASTJSON_WRITE_AS_STRING.invoke(null, value);
                }
            } catch (Exception fastjsonFailure) {
                throw new EasysqlException("Failed to serialize object to JSON", fastjsonFailure);
            }
            throw new EasysqlException("Failed to serialize object to JSON");
        }

        static Object fromJson(String json, Class<?> type) {
            if (MAPPER != null) {
                try {
                    return READ_VALUE.invoke(MAPPER, json, type);
                } catch (Exception jacksonFailure) {
                    if (FASTJSON_READ_VALUE == null) {
                        throw new EasysqlException("Failed to deserialize JSON to " + type.getSimpleName(), jacksonFailure);
                    }
                }
            }
            try {
                if (FASTJSON_READ_VALUE != null) {
                    return FASTJSON_READ_VALUE.invoke(null, json, type);
                }
            } catch (Exception fastjsonFailure) {
                throw new EasysqlException("Failed to deserialize JSON to " + type.getSimpleName(), fastjsonFailure);
            }
            throw new EasysqlException("Failed to deserialize JSON to " + type.getSimpleName());
        }
    }

    // ==================== SQL Building Helpers ====================

    /**
     * 通过反射调用 PostgreSQL PGobject，避免框架强制依赖 PG 驱动。
     * 若 classpath 上没有 PG 驱动，JSON 值直接作为字符串传递（MySQL 场景）。
     */
    private static final class PgHelper {
        private static final Constructor<?> CONSTRUCTOR;
        private static final Method SET_TYPE;
        private static final Method SET_VALUE;
        private static final Method GET_VALUE;
        private static final Class<?> PG_CLASS;

        static {
            Constructor<?> ctor = null;
            Class<?> pgClass = null;
            Method setType = null, setValue = null, getValue = null;
            try {
                pgClass = Class.forName("org.postgresql.util.PGobject");
                ctor = pgClass.getDeclaredConstructor();
                setType = pgClass.getMethod("setType", String.class);
                setValue = pgClass.getMethod("setValue", String.class);
                getValue = pgClass.getMethod("getValue");
            } catch (Exception ignored) {
                // PG driver not on classpath (e.g. MySQL-only projects)
            }
            PG_CLASS = pgClass;
            CONSTRUCTOR = ctor;
            SET_TYPE = setType;
            SET_VALUE = setValue;
            GET_VALUE = getValue;
        }

        static boolean available() { return CONSTRUCTOR != null; }

        /** 将 JSON 字符串包装为 PGobject("jsonb", json)，以满足 PostgreSQL JDBC 的类型要求 */
        static Object wrapJson(String json) {
            try {
                Object pg = CONSTRUCTOR.newInstance();
                SET_TYPE.invoke(pg, "jsonb");
                SET_VALUE.invoke(pg, json);
                return pg;
            } catch (Exception e) {
                throw new EasysqlException("Failed to wrap JSON value for PostgreSQL", e);
            }
        }

        /** 从 PGobject 中提取原始字符串值（用于读取 jsonb 列） */
        static String getStringValue(Object pgObject) {
            try {
                return (String) GET_VALUE.invoke(pgObject);
            } catch (Exception e) {
                throw new EasysqlException("Failed to extract value from PGobject", e);
            }
        }

        /** 判断对象是否为 PGobject 实例 */
        static boolean isPgObject(Object value) {
            return PG_CLASS != null && PG_CLASS.isInstance(value);
        }
    }

    /**
     * Build WHERE clause and collect parameters from FieldBeans.
     */
    private static class WhereResult {
        String sql;
        List<Object> params;

        WhereResult(String sql, List<Object> params) {
            this.sql = sql;
            this.params = params;
        }
    }

    private WhereResult buildWhere(Collection<FieldBean> fieldBeans, Class<?> clz) {
        StringBuilder where = new StringBuilder();
        List<Object> params = new ArrayList<>();
        List<Field> fields = ReflectUtils.fields(clz);

        // 1. Add isDeleted filter if not present
        if (fieldBeans.stream().noneMatch(f -> f != null && "isDeleted".equals(f.getName()))) {
            where.append(dialect.quote("is_deleted")).append(" = ?");
            params.add(false);
        }

        // 2. Process each field bean
        for (FieldBean fb : fieldBeans) {
            if (fb == null) continue;
            if (!validQueryColumn(fb, fields)) continue;

            String columnName = resolveColumnName(fb);
            appendCondition(where, params, fb, columnName, clz);
        }

        return new WhereResult(where.toString(), params);
    }

    private String resolveColumnName(FieldBean fb) {
        String name = fb.getName();
        if (name == null) return null;
        if (isSafeJsonExpression(name)) {
            return name;
        }
        if (!isSafeIdentifier(name)) {
            throw new EasysqlException("Unsafe query column: " + name);
        }
        return dialect.quote(SQLUtils.toColumnName(name));
    }

    @SuppressWarnings("unchecked")
    private void appendCondition(StringBuilder where, List<Object> params, FieldBean fb, String col, Class<?> clz) {
        if (col == null) return;
        QueryType qt = fb.getQueryType();
        if (qt == null) return;

        // Skip ORDER, FIELD, UPDATE, PAGE types - they're handled separately
        if (qt == QueryType.ASC || qt == QueryType.DESC || qt == QueryType.FIELD
            || qt == QueryType.UPDATE || qt == QueryType.PAGE_SIZE || qt == QueryType.PAGE_INDEX) {
            return;
        }

        String prefix = where.length() > 0 ? " AND " : "";

        switch (qt) {
            case EQ:
                where.append(prefix).append(col).append(" = ?");
                params.add(toJdbcParamValue(fb.getValue()));
                break;
            case NOT_EQ:
                where.append(prefix).append(col).append(" != ?");
                params.add(toJdbcParamValue(fb.getValue()));
                break;
            case LIKE:
                if (StringUtils.isEmpty(fb.getValue() == null ? null : fb.getValue().toString())) return;
                String lv = fb.getValue().toString();
                if (!lv.contains("%") && !lv.contains("_")) {
                    lv = "%" + lv + "%";
                }
                where.append(prefix).append(col).append(" LIKE ?");
                params.add(lv);
                break;
            case NOT_LIKE:
                String nlv = fb.getValue().toString();
                if (!nlv.contains("%") && !nlv.contains("_")) {
                    nlv = "%" + nlv + "%";
                }
                where.append(prefix).append(col).append(" NOT LIKE ?");
                params.add(nlv);
                break;
            case GT:
                where.append(prefix).append(col).append(" > ?");
                params.add(toJdbcParamValue(fb.getValue()));
                break;
            case GE:
                where.append(prefix).append(col).append(" >= ?");
                params.add(toJdbcParamValue(fb.getValue()));
                break;
            case LT:
                where.append(prefix).append(col).append(" < ?");
                params.add(toJdbcParamValue(fb.getValue()));
                break;
            case LE:
                where.append(prefix).append(col).append(" <= ?");
                params.add(toJdbcParamValue(fb.getValue()));
                break;
            case IS_NULL:
                where.append(prefix).append(col).append(" IS NULL");
                break;
            case NOT_NULL:
                where.append(prefix).append(col).append(" IS NOT NULL");
                break;
            case IN:
                Collection<?> inVals = (Collection<?>) fb.getValue();
                if (inVals.isEmpty()) {
                    where.append(prefix).append(col).append(" IN (-111545)");
                    return;
                }
                where.append(prefix).append(col).append(" IN (");
                where.append(inVals.stream().map(v -> "?").collect(Collectors.joining(",")));
                where.append(")");
                inVals.stream().map(BeetMapper::toJdbcParamValue).forEach(params::add);
                break;
            case NOT_IN:
                Collection<?> notInVals = (Collection<?>) fb.getValue();
                if (notInVals.isEmpty()) {
                    where.append(prefix).append("1=1");
                    return;
                }
                where.append(prefix).append(col).append(" NOT IN (");
                where.append(notInVals.stream().map(v -> "?").collect(Collectors.joining(",")));
                where.append(")");
                notInVals.stream().map(BeetMapper::toJdbcParamValue).forEach(params::add);
                break;
            case OVERLAPS:
                where.append(prefix).append(dialect.jsonOverlaps(col, SQLUtils.escapeJsonSpecialChars(fb.getValue().toString())));
                break;
            case NOT_OVERLAPS:
                where.append(prefix).append("NOT (").append(dialect.jsonOverlaps(col, SQLUtils.escapeJsonSpecialChars(fb.getValue().toString()))).append(")");
                break;
            case CONTAINS:
                where.append(prefix).append(dialect.jsonContains(col, SQLUtils.escapeJsonSpecialChars(fb.getValue().toString())));
                break;
            case NOT_CONTAINS:
                where.append(prefix).append("NOT ").append(dialect.jsonContains(col, SQLUtils.escapeJsonSpecialChars(fb.getValue().toString())));
                break;
            case OR:
                if (fb.getValues() == null) return;
                List<FieldBean> orBeans = new ArrayList<>(fb.getValues());
                orBeans.removeIf(o -> o == null || (o.getValue() == null && o.getQueryType() != QueryType.EXISTS
                    && o.getQueryType() != QueryType.NOT_EXISTS && o.getQueryType() != QueryType.AND
                    && o.getQueryType() != QueryType.IN && o.getQueryType() != QueryType.NOT_IN));
                if (orBeans.isEmpty()) return;
                StringBuilder orSql = new StringBuilder();
                for (int i = 0; i < orBeans.size(); i++) {
                    FieldBean ob = orBeans.get(i);
                    StringBuilder subWhere = new StringBuilder();
                    appendCondition(subWhere, params, ob, resolveColumnName(ob), clz);
                    if (subWhere.length() > 0) {
                        if (i > 0) orSql.append(" OR ");
                        orSql.append(subWhere);
                    }
                }
                if (orSql.length() > 0) {
                    where.append(prefix).append("(").append(orSql).append(")");
                }
                break;
            case AND:
                if (fb.getValues() == null) return;
                List<FieldBean> andBeans = new ArrayList<>(fb.getValues());
                andBeans.removeIf(Objects::isNull);
                if (andBeans.isEmpty()) return;
                StringBuilder andSql = new StringBuilder();
                for (FieldBean ab : andBeans) {
                    StringBuilder subWhere = new StringBuilder();
                    appendCondition(subWhere, params, ab, resolveColumnName(ab), clz);
                    if (subWhere.length() > 0) {
                        if (andSql.length() > 0) andSql.append(" AND ");
                        andSql.append(subWhere);
                    }
                }
                if (andSql.length() > 0) {
                    where.append(prefix).append("(").append(andSql).append(")");
                }
                break;
            case EXISTS:
                appendExists(where, params, fb, true);
                break;
            case NOT_EXISTS:
                appendExists(where, params, fb, false);
                break;
        }
    }

    private void appendExists(StringBuilder where, List<Object> params, FieldBean fb, boolean exists) {
        FieldBean.ExistsFieldBean efb = fb.getExistsFieldBean();
        if (efb == null) return;

        String joinTable = SQLUtils.toTableName(efb.getJoinClz().getSuperclass() != BaseModel.class
            ? efb.getJoinClz().getSuperclass().getSimpleName()
            : efb.getJoinClz().getSimpleName());
        String joinCol = dialect.quote(SQLUtils.toColumnName(efb.getJoinName()));

        WhereResult subWhere = buildWhere(efb.getFieldBeans(), efb.getJoinClz());
        subWhere.sql = subWhere.sql + " AND " + joinCol + " = "
                + dialect.quote(joinTable) + "." + dialect.quote(SQLUtils.toColumnName(efb.getForeignName()));

        String prefix = where.length() > 0 ? " AND " : "";
        where.append(prefix).append(exists ? "EXISTS" : "NOT EXISTS")
             .append(" (SELECT 1 FROM ").append(dialect.quote(joinTable))
             .append(" WHERE ").append(subWhere.sql).append(") ");
        params.addAll(subWhere.params);
    }

    private String buildOrderBy(Collection<FieldBean> fieldBeans) {
        StringBuilder orderBy = new StringBuilder();
        for (FieldBean fb : fieldBeans) {
            if (fb == null) continue;
            if (fb.getQueryType() == QueryType.ASC) {
                Object val = fb.getValue();
                if (val instanceof Collection) {
                    for (String col : (Collection<String>) val) {
                        if (orderBy.length() > 0) orderBy.append(", ");
                        orderBy.append(orderByColumn(col)).append(" ASC");
                    }
                } else if (fb.getName() != null) {
                    if (orderBy.length() > 0) orderBy.append(", ");
                    orderBy.append(orderByColumn(fb.getName())).append(" ASC");
                }
            } else if (fb.getQueryType() == QueryType.DESC) {
                Object val = fb.getValue();
                if (val instanceof Collection) {
                    for (String col : (Collection<String>) val) {
                        if (orderBy.length() > 0) orderBy.append(", ");
                        orderBy.append(orderByColumn(col)).append(" DESC");
                    }
                } else if (fb.getName() != null) {
                    if (orderBy.length() > 0) orderBy.append(", ");
                    orderBy.append(orderByColumn(fb.getName())).append(" DESC");
                }
            }
        }
        return orderBy.toString();
    }

    private String orderByColumn(String name) {
        if (isSafeJsonExpression(name)) return name;
        validateIdentifier(name);
        return dialect.quote(SQLUtils.toColumnName(name));
    }

    // ==================== Row Mapping ====================

    private <T> RowMapper<T> createRowMapper(Class<T> clz) {
        List<Field> entityFields = getEntityFields(clz);

        return (ResultSet rs, int rowNum) -> {
            try {
                T instance = clz.getDeclaredConstructor().newInstance();
                ResultSetMetaData meta = rs.getMetaData();
                for (int i = 1; i <= meta.getColumnCount(); i++) {
                    String colName = meta.getColumnLabel(i); // column alias or name
                    // Convert column name to field name (snake_case -> camelCase)
                    String fieldName = SQLUtils.toFieldName(colName);
                    for (Field f : entityFields) {
                        if (f.getName().equals(fieldName)) {
                            f.setAccessible(true);
                            Object value = rs.getObject(i);
                            if (value != null) {
                                // JSON 反序列化
                                value = fromJdbcValue(f, value);
                                // Type conversion
                                if (f.getType() == LocalDateTime.class && value instanceof java.sql.Timestamp) {
                                    value = ((java.sql.Timestamp) value).toLocalDateTime();
                                } else if (f.getType() == Long.class && value instanceof Number) {
                                    value = ((Number) value).longValue();
                                } else if (f.getType() == Integer.class && value instanceof Number) {
                                    value = ((Number) value).intValue();
                                }
                                f.set(instance, value);
                            }
                            break;
                        }
                    }
                }
                return instance;
            } catch (Exception e) {
                throw new EasysqlException("Failed to map row to " + clz.getSimpleName(), e);
            }
        };
    }

    // ==================== Public API ====================

    public <T> Boolean exists(Collection<FieldBean> fieldBeans, Class<T> clz) {
        fieldBeans = filterFieldBeans(fieldBeans);
        WhereResult wr = buildWhere(fieldBeans, clz);
        String tableName = SQLUtils.toTableName(getPclass(clz).getSimpleName());
        String sql = "SELECT COUNT(1) FROM " + dialect.quote(tableName) + " WHERE " + wr.sql;
        SqlLogSession session = null;
        if (SqlLogSession.isDebugEnabled()) {
            session = new SqlLogSession(tableName, sql, wr.params.toArray());
        }
        Integer count = jdbcTemplate.queryForObject(sql, wr.params.toArray(), Integer.class);
        if (session != null) {
            session.logResult(count, false);
        }
        return count != null && count > 0;
    }

    public <R, T> R findSum(String property, Collection<FieldBean> fieldBeans, Class<R> propertyClz, Class<T> clz) {
        fieldBeans = filterFieldBeans(fieldBeans);
        WhereResult wr = buildWhere(fieldBeans, clz);
        String tableName = SQLUtils.toTableName(getPclass(clz).getSimpleName());
        String sql = "SELECT SUM(" + SQLUtils.toColumnName(property) + ") FROM " + dialect.quote(tableName) + " WHERE " + wr.sql;
        SqlLogSession session = null;
        if (SqlLogSession.isDebugEnabled()) {
            session = new SqlLogSession(tableName, sql, wr.params.toArray());
        }
        R result = jdbcTemplate.queryForObject(sql, wr.params.toArray(), propertyClz);
        if (session != null) {
            session.logResult(result, false);
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    public <D, R, T> List<D> findSum(String groupProperty, String sumProperty, String valueProperty,
                                      Collection<FieldBean> fieldBeans, Class<D> dclz, Class<T> tclz) {
        fieldBeans = filterFieldBeans(fieldBeans);
        String sumCol = SQLUtils.toColumnName(sumProperty);
        String groupCol = SQLUtils.toColumnName(groupProperty);
        WhereResult wr = buildWhere(fieldBeans, tclz);
        String tableName = SQLUtils.toTableName(getPclass(tclz).getSimpleName());
        String sql = "SELECT " + groupCol + ", " + dialect.ifNull("SUM(" + sumCol + ")", "0") + " " + valueProperty
                     + " FROM " + dialect.quote(tableName) + " WHERE " + wr.sql + " GROUP BY " + groupCol;
        SqlLogSession session = null;
        if (SqlLogSession.isDebugEnabled()) {
            session = new SqlLogSession(tableName, sql, wr.params.toArray());
        }
        List<D> result = (List<D>) jdbcTemplate.query(sql, wr.params.toArray(), createRowMapper(dclz));
        if (session != null) {
            session.logResult(result, false);
        }
        return result;
    }

    public <T> Integer findCount(Collection<FieldBean> fieldBeans, Class<T> clz) {
        fieldBeans = filterFieldBeans(fieldBeans);
        WhereResult wr = buildWhere(fieldBeans, clz);
        String tableName = SQLUtils.toTableName(getPclass(clz).getSimpleName());
        String sql = "SELECT COUNT(1) FROM " + dialect.quote(tableName) + " WHERE " + wr.sql;
        SqlLogSession session = null;
        if (SqlLogSession.isDebugEnabled()) {
            session = new SqlLogSession(tableName, sql, wr.params.toArray());
        }
        Integer count = jdbcTemplate.queryForObject(sql, wr.params.toArray(), Integer.class);
        if (session != null) {
            session.logResult(count, false);
        }
        return count == null ? 0 : count;
    }

    @SuppressWarnings("unchecked")
    public <D, T> List<D> findCount(String groupProperty, String countProperty,
                                     Collection<FieldBean> fieldBeans, Class<D> dclz, Class<T> tclz) {
        fieldBeans = filterFieldBeans(fieldBeans);
        String countCol = SQLUtils.toColumnName(countProperty);
        String groupCol = SQLUtils.toColumnName(groupProperty);
        WhereResult wr = buildWhere(fieldBeans, tclz);
        String tableName = SQLUtils.toTableName(getPclass(tclz).getSimpleName());
        String sql = "SELECT " + groupCol + ", COUNT(1) " + countCol
                     + " FROM " + dialect.quote(tableName) + " WHERE " + wr.sql + " GROUP BY " + groupCol;
        SqlLogSession session = null;
        if (SqlLogSession.isDebugEnabled()) {
            session = new SqlLogSession(tableName, sql, wr.params.toArray());
        }
        List<D> result = (List<D>) jdbcTemplate.query(sql, wr.params.toArray(), createRowMapper(dclz));
        if (session != null) {
            session.logResult(result, false);
        }
        return result;
    }

    public <T> T findOne(Collection<FieldBean> fieldBeans, Class<T> clz) {
        fieldBeans = filterFieldBeans(fieldBeans);
        WhereResult wr = buildWhere(fieldBeans, clz);
        String orderBy = buildOrderBy(fieldBeans);
        String tableName = SQLUtils.toTableName(getPclass(clz).getSimpleName());

        // Determine columns
        List<String> columns = getSelectColumns(fieldBeans, clz);

        String sql = "SELECT " + String.join(", ", columns)
                     + " FROM " + dialect.quote(tableName) + " WHERE " + wr.sql;
        if (!orderBy.isEmpty()) sql += " ORDER BY " + orderBy;
        sql += " LIMIT 1";

        SqlLogSession session = null;
        if (SqlLogSession.isDebugEnabled()) {
            session = new SqlLogSession(tableName, sql, wr.params.toArray());
        }
        List<T> results = jdbcTemplate.query(sql, wr.params.toArray(), createRowMapper(clz));
        if (session != null) {
            session.logResult(results.isEmpty() ? null : results.get(0), false);
        }
        return results.isEmpty() ? null : results.get(0);
    }

    @SuppressWarnings("unchecked")
    public <T> List<T> findList(Collection<FieldBean> fieldBeans, Class<T> clz) {
        fieldBeans = filterFieldBeans(fieldBeans);

        // Check if page request
        if (fieldBeans.stream().anyMatch(f -> f.getQueryType() == QueryType.PAGE_INDEX)) {
            return (List<T>) findPage(fieldBeans, clz).getData();
        }

        WhereResult wr = buildWhere(fieldBeans, clz);
        String orderBy = buildOrderBy(fieldBeans);
        String tableName = SQLUtils.toTableName(getPclass(clz).getSimpleName());
        List<String> columns = getSelectColumns(fieldBeans, clz);

        // Page size limit
        FieldBean psBean = fieldBeans.stream()
            .filter(f -> f.getQueryType() == QueryType.PAGE_SIZE && f.getValue() != null)
            .findAny().orElse(null);

        String sql = "SELECT " + String.join(", ", columns)
                     + " FROM " + dialect.quote(tableName) + " WHERE " + wr.sql;
        if (!orderBy.isEmpty()) {
            sql += " ORDER BY " + orderBy;
        } else {
            sql += " ORDER BY id DESC";
        }
        if (psBean != null) sql += " LIMIT " + psBean.getValue();

        SqlLogSession session = null;
        if (SqlLogSession.isDebugEnabled()) {
            session = new SqlLogSession(tableName, sql, wr.params.toArray());
        }
        List<T> result = jdbcTemplate.query(sql, wr.params.toArray(), createRowMapper(clz));
        if (session != null) {
            session.logResult(result, false);
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    public <T> PageData<T> findPage(Collection<FieldBean> fieldBeans, Class<T> clz) {
        fieldBeans = filterFieldBeans(fieldBeans);
        WhereResult wr = buildWhere(fieldBeans, clz);
        String orderBy = buildOrderBy(fieldBeans);
        String tableName = SQLUtils.toTableName(getPclass(clz).getSimpleName());
        List<String> columns = getSelectColumns(fieldBeans, clz);

        long pageSize = fieldBeans.stream()
            .filter(f -> f.getQueryType() == QueryType.PAGE_SIZE)
            .findFirst()
            .map(f -> Long.parseLong(f.getValue() + ""))
            .orElse(10L);
        long pageNumber = fieldBeans.stream()
            .filter(f -> f.getQueryType() == QueryType.PAGE_INDEX)
            .findFirst()
            .map(f -> Long.parseLong(f.getValue() + ""))
            .orElse(1L);

        // Count
        String countSql = "SELECT COUNT(1) FROM " + dialect.quote(tableName) + " WHERE " + wr.sql;
        SqlLogSession countSession = null;
        if (SqlLogSession.isDebugEnabled()) {
            countSession = new SqlLogSession(tableName, countSql, wr.params.toArray());
        }
        Long total = jdbcTemplate.queryForObject(countSql, wr.params.toArray(), Long.class);
        if (countSession != null) {
            countSession.logResult(total, false);
        }
        int totalCount = total == null ? 0 : total.intValue();
        int totalPage = totalCount == 0 ? 0 : (int) Math.ceil((double) totalCount / pageSize);

        // Select
        long offset = (pageNumber - 1) * pageSize;
        String sql = "SELECT " + String.join(", ", columns)
                     + " FROM " + dialect.quote(tableName) + " WHERE " + wr.sql;
        if (!orderBy.isEmpty()) {
            sql += " ORDER BY " + orderBy;
        } else {
            sql += " ORDER BY id DESC";
        }
        sql += " " + dialect.limitClause(offset, pageSize);

        SqlLogSession selectSession = null;
        if (SqlLogSession.isDebugEnabled()) {
            selectSession = new SqlLogSession(tableName, sql, wr.params.toArray());
        }
        List<T> list = jdbcTemplate.query(sql, wr.params.toArray(), createRowMapper(clz));
        if (selectSession != null) {
            selectSession.logResult(list, false);
        }
        return new PageData<>((int) pageSize, (int) pageNumber, totalPage, totalCount, list);
    }

    public <T> void insert(BaseModel entity, Class<T> pclz) {
        Class<?> clz = getPclass(pclz);
        String tableName = SQLUtils.toTableName(clz.getSimpleName());
        List<String> columns = getEntityColumns(clz);
        List<Field> fields = getEntityFields(clz);

        if (entity.getId() == null) {
            entity.setId(idGenerator.nextId());
        }

        StringBuilder sql = new StringBuilder("INSERT INTO ").append(dialect.quote(tableName)).append("(");
        sql.append(columns.stream().map(c -> dialect.quote(SQLUtils.toColumnName(c))).collect(Collectors.joining(", ")));
        sql.append(") VALUES (");

        List<Object> values = new ArrayList<>();
        for (int i = 0; i < fields.size(); i++) {
            if (i > 0) sql.append(", ");
            sql.append("?");
            Field field = fields.get(i);
            Object val = getFieldValue(field, entity);
            values.add(toJdbcValue(field, val));
        }
        sql.append(")");

        SqlLogSession session = null;
        if (SqlLogSession.isDebugEnabled()) {
            session = new SqlLogSession(tableName, sql.toString(), values.toArray());
        }
        int rows = jdbcTemplate.update(sql.toString(), values.toArray());
        if (session != null) {
            session.logResult(rows, true);
        }
        if (rows < 1) {
            throw new EasysqlException("新增数据异常");
        }
    }

    public <D extends BaseModel> void inserts(Collection<D> ds, Class<D> pclz) {
        if (ds == null || ds.isEmpty()) return;

        Class<?> clz = getPclass(pclz);
        String tableName = SQLUtils.toTableName(clz.getSimpleName());
        List<String> columns = getEntityColumns(clz);

        StringBuilder insert = new StringBuilder("INSERT INTO ").append(dialect.quote(tableName)).append("(");
        insert.append(columns.stream().map(c -> dialect.quote(SQLUtils.toColumnName(c))).collect(Collectors.joining(", ")));
        insert.append(") VALUES ");

        List<Object> allValues = new ArrayList<>();
        for (BaseModel d : ds) {
            if (d.getId() == null) {
                d.setId(idGenerator.nextId());
            }
            insert.append("(");
            for (int i = 0; i < columns.size(); i++) {
                if (i > 0) insert.append(", ");
                String col = columns.get(i);
                Object value = getJdbcValueByName(d, col);
                if ("id".equals(col) && value == null) {
                    value = d.getId();
                }
                if (value == null) {
                    insert.append("DEFAULT");
                } else {
                    insert.append("?");
                    allValues.add(value);
                }
            }
            insert.append("),");
        }
        insert.deleteCharAt(insert.length() - 1);

        SqlLogSession session = null;
        if (SqlLogSession.isDebugEnabled()) {
            session = new SqlLogSession(tableName, insert.toString(), allValues.toArray());
        }
        int rows = jdbcTemplate.update(insert.toString(), allValues.toArray());
        if (session != null) {
            session.logResult(rows, true);
        }
    }

    public <T> boolean update(Collection<FieldBean> fieldBeans, BaseModel update, Class<T> pclz) {
        fieldBeans = filterFieldBeans(fieldBeans);
        Class<?> clz = getPclass(pclz);
        String tableName = SQLUtils.toTableName(clz.getSimpleName());
        List<Field> fields = getEntityFields(clz);
        Set<String> explicitNullFields = fieldBeans.stream()
                .filter(f -> f.getQueryType() == QueryType.UPDATE && f.getValue() == null)
                .map(FieldBean::getName)
                .collect(Collectors.toSet());

        // Build SET clause
        StringBuilder setClause = new StringBuilder();
        List<Object> setValues = new ArrayList<>();
        for (Field field : fields) {
            if ("id".equals(field.getName())) continue;
            Object val = getFieldValue(field, update);
            if (val != null || explicitNullFields.contains(field.getName())) {
                if (setClause.length() > 0) setClause.append(", ");
                setClause.append(dialect.quote(SQLUtils.toColumnName(field.getName())));
                if (val == null) {
                    setClause.append(" = NULL");
                } else {
                    setClause.append(" = ?");
                    setValues.add(toJdbcValue(field, val));
                }
            }
        }
        if (setClause.length() == 0) return false;

        // Build WHERE clause
        WhereResult wr = buildWhere(fieldBeans, clz);

        String sql = "UPDATE " + dialect.quote(tableName) + " SET " + setClause + " WHERE " + wr.sql;
        List<Object> allParams = new ArrayList<>();
        allParams.addAll(setValues);
        allParams.addAll(wr.params);

        SqlLogSession session = null;
        if (SqlLogSession.isDebugEnabled()) {
            session = new SqlLogSession(tableName, sql, allParams.toArray());
        }
        int rows = jdbcTemplate.update(sql, allParams.toArray());
        if (session != null) {
            session.logResult(rows, true);
        }
        return rows > 0;
    }

    public <D extends BaseModel> void updates(Collection<D> ds, Class<D> pclz) {
        if (ds == null || ds.isEmpty()) return;

        Class<?> clz = getPclass(pclz);
        String tableName = SQLUtils.toTableName(clz.getSimpleName());
        List<String> allColumns = getEntityColumns(clz).stream()
            .filter(c -> !"id".equals(c))
            .collect(Collectors.toList());

        // 按 SET 子句分组，每组用同一个 SQL + batchUpdate
        Map<String, List<Object[]>> batches = new LinkedHashMap<>();

        for (D d : ds) {
            Long id = d.getId();
            if (id == null) continue;

            StringBuilder setClause = new StringBuilder();
            List<Object> params = new ArrayList<>();
            for (String column : allColumns) {
                Object value = getJdbcValueByName(d, column);
                if (value != null) {
                    if (setClause.length() > 0) setClause.append(", ");
                    setClause.append(dialect.quote(SQLUtils.toColumnName(column))).append(" = ?");
                    params.add(value);
                }
            }
            if (setClause.length() == 0) continue;
            params.add(id);

            String sql = "UPDATE " + dialect.quote(tableName) + " SET " + setClause + " WHERE id = ?";
            batches.computeIfAbsent(sql, k -> new ArrayList<>()).add(params.toArray());
        }

        for (Map.Entry<String, List<Object[]>> entry : batches.entrySet()) {
            SqlLogSession session = null;
            if (SqlLogSession.isDebugEnabled()) {
                session = new SqlLogSession(tableName, entry.getKey(), entry.getValue().get(0));
            }
            int[] results = jdbcTemplate.batchUpdate(entry.getKey(), entry.getValue());
            if (session != null) {
                int total = 0;
                for (int r : results) total += r;
                session.logResult(total, true);
            }
        }
    }

    // ==================== Helpers ====================

    private List<FieldBean> filterFieldBeans(Collection<FieldBean> fieldBeans) {
        if (fieldBeans == null) return new ArrayList<>();
        return fieldBeans.stream().filter(Objects::nonNull).collect(Collectors.toList());
    }

    private Class<?> getPclass(Class<?> clz) {
        Class<?> superClz = clz.getSuperclass();
        return (superClz != null && superClz != Object.class && superClz != BaseModel.class
                && BaseModel.class.isAssignableFrom(superClz)) ? superClz : clz;
    }

    private List<String> getEntityColumns(Class<?> clz) {
        return COLUMN_CACHE.computeIfAbsent(clz, k ->
            getEntityFields(k).stream().map(Field::getName).collect(Collectors.toList()));
    }

    private List<Field> getEntityFields(Class<?> clz) {
        return FIELD_CACHE.computeIfAbsent(clz, k ->
            ReflectUtils.fields(k).stream()
                .filter(f -> f.getAnnotation(Column.class) != null)
                .collect(Collectors.toList()));
    }

    private <T> List<String> getSelectColumns(Collection<FieldBean> fieldBeans, Class<T> clz) {
        List<String> selectCols = new ArrayList<>();
        for (FieldBean fb : fieldBeans) {
            if (fb != null && fb.getQueryType() == QueryType.FIELD && fb.getValue() instanceof Collection) {
                selectCols.addAll((Collection<String>) fb.getValue());
            }
        }
        // If no columns specified, select all entity columns
        if (selectCols.isEmpty()) {
            selectCols = new ArrayList<>(getEntityColumns(clz));
        }
        // Filter out columns not in entity
        List<Field> entityFields = getEntityFields(clz);
        selectCols.removeIf(c -> entityFields.stream().noneMatch(f -> f.getName().equals(c)));
        // Wrap with dialect quoting
        return selectCols.stream().map(c -> dialect.quote(SQLUtils.toColumnName(c))).collect(Collectors.toList());
    }

    private Object getFieldValue(Field field, Object entity) {
        try {
            field.setAccessible(true);
            return field.get(entity);
        } catch (Exception e) {
            return null;
        }
    }

    private Object getFieldValueByName(Object entity, String fieldName) {
        Class<?> clz = entity.getClass();
        Map<String, Field> nameMap = NAME_FIELD_CACHE.computeIfAbsent(clz, k -> {
            Map<String, Field> m = new HashMap<>();
            for (Field f : ReflectUtils.fields(k)) {
                m.put(f.getName(), f);
            }
            return m;
        });
        Field f = nameMap.get(fieldName);
        if (f == null) return null;
        try {
            f.setAccessible(true);
            return f.get(entity);
        } catch (Exception e) {
            return null;
        }
    }

    // ==================== JSON Value Conversion ====================

    /**
     * 将实体字段值转为 JDBC 参数值。
     * 若字段的 @Column 声明了 type = Type.JSON，则序列化为 JSON 字符串。
     */
    private static Object toJdbcValue(Field field, Object value) {
        if (value == null) return null;
        // 枚举 → name() 字符串
        if (value instanceof Enum<?> e) return e.name();
        if (isJsonField(field)) {
            if (!JsonHelper.available()) return value;
            String json = JsonHelper.toJson(value);
            // PostgreSQL: 必须用 PGobject("jsonb", json)，不能传裸字符串
            return PgHelper.available() ? PgHelper.wrapJson(json) : json;
        }
        return value;
    }

    /** 将查询参数值转为 JDBC 兼容类型（枚举 → 字符串），与 {@link #toJdbcValue(Field, Object)} 保持一致 */
    private static Object toJdbcParamValue(Object value) {
        if (value instanceof Enum<?> e) return e.name();
        return value;
    }

    /** 按字段名取值并转为 JDBC 参数值 */
    private Object getJdbcValueByName(Object entity, String fieldName) {
        Object value = getFieldValueByName(entity, fieldName);
        if (value == null) return null;
        Field field = NAME_FIELD_CACHE.get(entity.getClass()).get(fieldName);
        return field != null ? toJdbcValue(field, value) : value;
    }

    /**
     * 将 JDBC 返回值转为实体字段值。
     * 若字段的 @Column 声明了 type = Type.JSON 且 DB 返回的是字符串，则反序列化为目标类型。
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    static Object fromJdbcValue(Field field, Object value) {
        if (value == null) return null;
        // PGobject → 提取原始字符串（PostgreSQL jsonb 列返回 PGobject 而非 String）
        if (PgHelper.isPgObject(value)) {
            value = PgHelper.getStringValue(value);
        }
        // 枚举：DB 返回字符串 → 枚举常量（CHAR 类型可能尾部填充空格，需 trim）
        if (field.getType().isEnum() && value instanceof String enumName) {
            return Enum.valueOf((Class<Enum>) field.getType(), enumName.trim());
        }
        if (isJsonField(field) && value instanceof String json) {
            if (!JsonHelper.available()) return value;
            return JsonHelper.fromJson(json, field.getType());
        }
        return value;
    }

    private static boolean isJsonField(Field field) {
        return JSON_FIELD_CACHE.computeIfAbsent(field, f -> {
            Column col = f.getAnnotation(Column.class);
            if (col == null) return false;
            // 显式声明了 JSON
            if (col.type() == Type.JSON) return true;
            // type 为 NONE 时，若字段类型不是已知基础类型，自动视为 JSON（与 DDL 兜底逻辑一致）
            if (col.type() == Type.NONE && !isBasicJdbcType(f.getType())) return true;
            return false;
        });
    }

    /**
     * 判断是否为已知的基础 JDBC 类型（与 {@code ddlType()} 中的类型推断一致）。
     * 非基础类型的复杂对象（如自定义 DTO）视为 JSON。
     */
    private static boolean isBasicJdbcType(Class<?> type) {
        if (type == String.class || type == Character.class || type.isEnum()) return true;
        if (type == Byte.class || type == Short.class || type == Integer.class || type == Long.class) return true;
        if (type == Float.class || type == Double.class || type == java.math.BigDecimal.class) return true;
        if (type == Boolean.class) return true;
        if (type == java.time.LocalDate.class || type == java.time.LocalTime.class
                || type == java.time.LocalDateTime.class || type == java.util.Date.class
                || type == java.time.YearMonth.class) return true;
        return false;
    }

    private static boolean validQueryColumn(FieldBean fieldBean, List<Field> fields) {
        if (fieldBean.getQueryType() == QueryType.AND || fieldBean.getQueryType() == QueryType.OR
            || fieldBean.getQueryType() == QueryType.EXISTS || fieldBean.getQueryType() == QueryType.NOT_EXISTS) {
            return true;
        }
        if (fieldBean.getValue() == null) return false;
        String name = fieldBean.getName();
        if (name == null) return false;
        if (isSafeJsonExpression(name)) return true;
        if (!isSafeIdentifier(name)) {
            throw new EasysqlException("Unsafe query column: " + name);
        }
        return fields.stream().anyMatch(f -> f.getName().equals(name));
    }

    private static void validateIdentifier(String name) {
        if (!isSafeIdentifier(name)) {
            throw new EasysqlException("Unsafe query column: " + name);
        }
    }

    private static boolean isSafeIdentifier(String name) {
        return name != null && SAFE_IDENTIFIER.matcher(name).matches();
    }

    private static boolean isSafeJsonExpression(String name) {
        return name != null && SAFE_JSON_EXPRESSION.matcher(name).matches();
    }
}
