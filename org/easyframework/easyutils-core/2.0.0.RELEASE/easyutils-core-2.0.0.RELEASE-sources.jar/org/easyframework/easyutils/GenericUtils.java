package org.easyframework.easyutils;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 泛型工具类
 *
 * 注意：
 * 1. 无法获取自身的泛型 例如有 OrderService<Order> 则无法通过 OrderService.class 获取 Order.class
 *    只能 通过它的子类 OrderServiceImpl.class 获取 Order.class
 */
public class GenericUtils {
    /**
     * 查询类的泛型
     * 场景1：class     OrderService<Order>
     *
     * 场景2：interface BaseService<D> {
     *            PageData<D> page();
     *        }
     *        interface OrderService extends BaseService<Order>
     *
     *
     * @param clz           类 class OrderService<Order>
     * @param genericName   泛型缩写    D
     * @return Order.class
     */
    public static Class<?> findGeneric(Class<?> clz, String genericName) {

        return null;
    }

    /**
     * 获取类的父类的泛型
     * @param clz   class OrderServiceImplements extends OrderService<D>
     * @return Order.class
     */
    public static Class<?> findGeneric(Class<?> clz) {
        if (clz == null) return null;

        // 1. 获取泛型类型 org.easyframework.easysql.repository.impl.OrderService<com.easybyte.purchase.structure.service.easysql.dto.OrderDTO>
        Type generictype = clz.getGenericSuperclass();

        if (!(generictype instanceof ParameterizedType))
            return null;

        // 2. 强转参数类型 org.easyframework.easysql.repository.impl.OrderService<com.easybyte.purchase.structure.service.easysql.dto.OrderDTO>
        ParameterizedType parameterizedType = (ParameterizedType) generictype;

        // 3. 获取泛型  com.easybyte.purchase.structure.service.easysql.dto.OrderDTO
        Type[] types = parameterizedType.getActualTypeArguments();

        // 4. 返回第一个泛型
        if (types.length == 0) return null;
        return (Class<?>) types[0];
    }

    /**
     * 获取类的父类的泛型
     * @param clz   class OrderService extends AbstractService<Order>
     * @return Order.class
     */
    public static Class<?> findSuperGeneric(Class<?> clz) {
        return findGeneric(clz.getSuperclass());
    }

    /**
     * 获取此类的实现的接口的所有的泛型
     * interface TestService<S, L>
     * interface BaseService<D, T>     extends    TestService<D, T>
     * interface OrderService<A, D, T> extends    BaseService<D, T>
     * class     OrderServiceImpl      implements OrderService<Member, Product, Order>
     *
     * input : TestService.class
     * return: []
     *
     * input : BaseService.class
     * return: []
     *
     * input : OrderService.class
     * return: []
     *
     * input : OrderServiceImpl.class
     * return: [class org.easyframework.easyutils.test.Member, class org.easyframework.easyutils.test.Product, class org.easyframework.easyutils.test.Order]
     */
    public static List<Class<?>> findInterfaceGenerics(Class<?> clz) {
        if (clz == null) return null;
        List<Class<?>> generics = new ArrayList<>();

        /*
         * 1. 查询此类所实现的接口
         *    interface BaseService<D>
         *    interface OrderService     extends BaseService<Order>
         *    class     OrderServiceImpl implements OrderService
         *
         *    OrderService.class
         * -> org.easyframework.easyutils.test.BaseService<org.easyframework.easyutils.test.Order>
         *
         *    OrderServiceImpl.class
         * -> org.easyframework.easyutils.test.OrderService
         *
         *
         *
         */
        Type[] genericInterfaces = clz.getGenericInterfaces();

        /*
         * 2. 遍历每一个接口，判断它是否拥有泛型
         *    interface BaseService<D>
         *    interface OrderService     extends BaseService<Order> 拥有泛型
         *    class     OrderServiceImpl implements OrderService    没有泛型
         *
         */
        for (Type type : genericInterfaces) {
            // 拥有泛型 extends BaseService<Order>
            if (type instanceof ParameterizedType) {
                Type[] arguments = ((ParameterizedType) type).getActualTypeArguments();
                for (Type argument : arguments) {
                    if (argument instanceof Class) generics.add(((Class<?>) argument));
                }
            }
        }

        /*
         * 3. 查询接口实现的父接口，递归此过程
         */
        for (Class<?> superInterface : superInterfaces(genericInterfaces)) {
            generics.addAll(findInterfaceGenerics(superInterface));
        }
        return generics;
    }

    /**
     * 查找接口的父接口
     */
    private static List<Class<?>> superInterfaces(Type[] genericInterfaces) {
        List<Class<?>> interfaces = new ArrayList<>();
        for (Type type : genericInterfaces) {
            if (type instanceof ParameterizedType) {
                interfaces.add((Class<?>) ((ParameterizedType) type).getRawType());
            } else {
                interfaces.addAll(Arrays.asList(((Class<?>) type).getInterfaces()));
            }
        }
        return interfaces;
    }
}
