package org.easyframework.easyutils;

/** Internal contract implemented by runtime-generated simple Bean mappers. */
public interface GeneratedMapper {
    Object map(Object source);
}
