package org.easyframework.easyutils;

import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.security.InvalidParameterException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.MonthDay;
import java.time.Year;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Configuration-free JVM object mapper.
 *
 * <p>The first conversion for a source/target type pair creates a cached
 * mapper plan. Repeated calls only execute cached readers, writers and
 * conversion metadata, while the API remains {@code map(source, Target.class)}.</p>
 */
public final class BeanMapper {
    private static final ConcurrentHashMap<Class<?>, Field[]> FIELDS = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<Class<?>, Map<String, Field>> FIELDS_BY_NAME = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<Class<?>, Constructor<?>> CONSTRUCTORS = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<Class<?>, ConcurrentHashMap<Class<?>, MapperPlan>> PLANS = new ConcurrentHashMap<>();
    private static final AtomicLong GENERATED_MAPPER_SEQUENCE = new AtomicLong();
    private static final GeneratedClassLoader GENERATED_CLASS_LOADER = new GeneratedClassLoader(BeanMapper.class.getClassLoader());
    private static final Set<Class<?>> SIMPLE_TYPES = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            String.class, byte.class, Byte.class, char.class, Character.class,
            int.class, Integer.class, long.class, Long.class, short.class, Short.class,
            float.class, Float.class, double.class, Double.class, boolean.class, Boolean.class
    )));
    private static final Set<Class<?>> DATE_TYPES = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            Date.class, java.sql.Date.class, java.sql.Time.class, java.sql.Timestamp.class,
            Year.class, Month.class, MonthDay.class, YearMonth.class,
            LocalDate.class, LocalTime.class, LocalDateTime.class, Instant.class
    )));
    private static final String[] DATE_PATTERNS = {
            "yyyyMMddHHmmss", "yyyyMMddHHmm", "yyyy-MM-dd'T'HH:mm:ss.SSS",
            "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd",
            "yyyyMMddHH", "yyyyMMdd", "yyyyMM", "yyyy-MM", "yyyy", "HH:mm:ss", "HH:mm"
    };
    private static final ThreadLocal<Map<String, SimpleDateFormat>> DATE_FORMATS =
            ThreadLocal.withInitial(BeanMapper::newDateFormats);
    private static final DateTimeFormatter DEFAULT_DATE_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private BeanMapper() { }

    public static void copyAll(Object from, Object to) { copyProperties(from, to, CopyMode.ALL); }
    public static void copyNonNull(Object from, Object to) { copyProperties(from, to, CopyMode.NON_NULL); }
    public static void copyNotNull(Object from, Object to) { copyNonNull(from, to); }
    public static void fillNulls(Object from, Object to) { copyProperties(from, to, CopyMode.FILL_NULLS); }

    public static <T> List<T> map(Collection<?> sources, Class<T> destClz) {
        List<T> result = new ArrayList<>(sources == null ? 0 : sources.size());
        if (sources != null) for (Object source : sources) result.add(map(source, destClz));
        return result;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static <T> T map(Object source, Class<T> destClz) {
        if (source == null) return null;
        if (destClz == null) throw new InvalidParameterException("对象转换失败，未指定目标类型");
        Class<?> sourceType = source.getClass();
        if (sourceType == destClz || destClz.isAssignableFrom(sourceType)) return (T) deepClone(source);
        if (destClz == String.class) {
            String date = dateToString(source);
            return (T) (date == null ? String.valueOf(source) : date);
        }
        if (source instanceof Object[]) {
            Map<String, Object> values = arrayToMap((Object[]) source);
            return Map.class.isAssignableFrom(destClz) ? (T) values : mapMapToObject(values, destClz);
        }
        if (source instanceof Map) {
            if (Map.class.isAssignableFrom(destClz)) {
                Map target = instantiateMap(destClz, ((Map) source).size());
                target.putAll((Map) source);
                return (T) target;
            }
            return mapMapToObject((Map<?, ?>) source, destClz);
        }
        if (isSimpleType(destClz)) return convertSimple(source, destClz);
        if (isNumericType(destClz)) return (T) convertNumber(source, destClz);
        if (isDateType(destClz)) return (T) convertDate(source, destClz);
        if (destClz.isEnum()) return (T) Enum.valueOf((Class<Enum>) destClz, String.valueOf(source));
        if (Map.class.isAssignableFrom(destClz)) {
            Field[] fields = fieldsOf(sourceType);
            Map<String, Object> target = instantiateMap(destClz, fields.length);
            for (Field field : fields) target.put(field.getName(), readField(field, source));
            return (T) target;
        }
        return (T) planFor(sourceType, destClz).map(source);
    }

    private static void copyProperties(Object from, Object to, CopyMode mode) {
        if (from == null || to == null) return;
        for (FieldBinding binding : planFor(from.getClass(), to.getClass()).bindings) {
            Object value = binding.read(from);
            if (mode == CopyMode.NON_NULL && value == null) continue;
            if (mode == CopyMode.FILL_NULLS && binding.readTarget(to) != null) continue;
            if (value != null || !binding.targetType.isPrimitive()) binding.write(to, binding.convert(value));
        }
    }

    @SuppressWarnings("unchecked")
    private static <T> T mapMapToObject(Map<?, ?> source, Class<T> destClz) {
        return (T) planFor(source.getClass(), destClz).map(source);
    }

    private static MapperPlan planFor(Class<?> sourceType, Class<?> targetType) {
        ConcurrentHashMap<Class<?>, MapperPlan> targetPlans = PLANS.get(sourceType);
        if (targetPlans == null) {
            ConcurrentHashMap<Class<?>, MapperPlan> candidate = new ConcurrentHashMap<>();
            ConcurrentHashMap<Class<?>, MapperPlan> existing = PLANS.putIfAbsent(sourceType, candidate);
            targetPlans = existing == null ? candidate : existing;
        }
        MapperPlan plan = targetPlans.get(targetType);
        if (plan != null) {
            return plan;
        }
        return targetPlans.computeIfAbsent(targetType, ignored -> buildPlan(new MapperKey(sourceType, targetType)));
    }

    private static MapperPlan buildPlan(MapperKey key) {
        GeneratedMapper generatedMapper = tryCreateGeneratedMapper(key);
        if (generatedMapper != null) {
            return new MapperPlan(generatedMapper, null, new FieldBinding[0]);
        }
        List<FieldBinding> bindings = new ArrayList<>();
        Map<String, Field> sourceFields = Map.class.isAssignableFrom(key.sourceType)
                ? Collections.emptyMap() : fieldsByName(key.sourceType);
        for (Field target : fieldsOf(key.targetType)) {
            Field sourceField;
            if (Map.class.isAssignableFrom(key.sourceType)) {
                sourceField = null;
            } else {
                sourceField = sourceFields.get(target.getName());
                if (sourceField == null) continue;
            }
            bindings.add(new FieldBinding(sourceField, target, findSetter(key.targetType, target),
                    target.getType(), ReflectUtils.listArgType(target)));
        }
        return new MapperPlan(null, constructorFor(key.targetType), bindings.toArray(new FieldBinding[0]));
    }

    private static GeneratedMapper tryCreateGeneratedMapper(MapperKey key) {
        if (!isGenerationCompatible(key)) {
            return null;
        }
        try {
            String sourceName = Type.getInternalName(key.sourceType);
            String targetName = Type.getInternalName(key.targetType);
            String mapperName = "org/easyframework/easyutils/generated/BeanMapperGenerated" + GENERATED_MAPPER_SEQUENCE.incrementAndGet();
            ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS);
            writer.visit(Opcodes.V21, Opcodes.ACC_PUBLIC | Opcodes.ACC_FINAL, mapperName, null,
                    "java/lang/Object", new String[]{Type.getInternalName(GeneratedMapper.class)});

            MethodVisitor constructor = writer.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null);
            constructor.visitCode();
            constructor.visitVarInsn(Opcodes.ALOAD, 0);
            constructor.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
            constructor.visitInsn(Opcodes.RETURN);
            constructor.visitMaxs(0, 0);
            constructor.visitEnd();

            MethodVisitor map = writer.visitMethod(Opcodes.ACC_PUBLIC, "map", "(Ljava/lang/Object;)Ljava/lang/Object;", null, null);
            map.visitCode();
            map.visitTypeInsn(Opcodes.NEW, targetName);
            map.visitInsn(Opcodes.DUP);
            map.visitMethodInsn(Opcodes.INVOKESPECIAL, targetName, "<init>", "()V", false);
            map.visitVarInsn(Opcodes.ASTORE, 2);
            for (GeneratedProperty property : generatedProperties(key)) {
                map.visitVarInsn(Opcodes.ALOAD, 2);
                map.visitVarInsn(Opcodes.ALOAD, 1);
                map.visitTypeInsn(Opcodes.CHECKCAST, sourceName);
                map.visitMethodInsn(Opcodes.INVOKEVIRTUAL, sourceName, property.getter.getName(),
                        Type.getMethodDescriptor(property.getter), false);
                map.visitMethodInsn(Opcodes.INVOKEVIRTUAL, targetName, property.setter.getName(),
                        Type.getMethodDescriptor(property.setter), false);
            }
            map.visitVarInsn(Opcodes.ALOAD, 2);
            map.visitInsn(Opcodes.ARETURN);
            map.visitMaxs(0, 0);
            map.visitEnd();
            writer.visitEnd();

            Class<?> mapperClass = GENERATED_CLASS_LOADER.define(writer.toByteArray());
            return (GeneratedMapper) mapperClass.getDeclaredConstructor().newInstance();
        } catch (ReflectiveOperationException | LinkageError e) {
            return null;
        }
    }

    private static boolean isGenerationCompatible(MapperKey key) {
        if (!Modifier.isPublic(key.sourceType.getModifiers()) || !Modifier.isPublic(key.targetType.getModifiers())) {
            return false;
        }
        if (key.sourceType.getClassLoader() != BeanMapper.class.getClassLoader()
                || key.targetType.getClassLoader() != BeanMapper.class.getClassLoader()) {
            return false;
        }
        try {
            key.targetType.getConstructor();
        } catch (NoSuchMethodException e) {
            return false;
        }
        return generatedProperties(key) != null;
    }

    private static List<GeneratedProperty> generatedProperties(MapperKey key) {
        List<GeneratedProperty> properties = new ArrayList<>();
        Map<String, Field> sourceFields = fieldsByName(key.sourceType);
        for (Field targetField : fieldsOf(key.targetType)) {
            Field sourceField = sourceFields.get(targetField.getName());
            if (sourceField == null) {
                continue;
            }
            if (sourceField.getType() != targetField.getType()
                    || Collection.class.isAssignableFrom(targetField.getType())) {
                return null;
            }
            Method getter = findGetter(key.sourceType, sourceField);
            Method setter = findSetter(key.targetType, targetField);
            if (getter == null || setter == null || !Modifier.isPublic(getter.getModifiers())
                    || !Modifier.isPublic(setter.getModifiers())) {
                return null;
            }
            properties.add(new GeneratedProperty(getter, setter));
        }
        return properties;
    }

    private static Method findGetter(Class<?> type, Field field) {
        String suffix = Character.toUpperCase(field.getName().charAt(0)) + field.getName().substring(1);
        try {
            return type.getMethod("get" + suffix);
        } catch (NoSuchMethodException ignored) {
            if (field.getType() == boolean.class || field.getType() == Boolean.class) {
                try {
                    return type.getMethod("is" + suffix);
                } catch (NoSuchMethodException ignoredAgain) {
                    return null;
                }
            }
            return null;
        }
    }

    private static Field[] fieldsOf(Class<?> type) { return FIELDS.computeIfAbsent(type, BeanMapper::findFields); }

    private static Field[] findFields(Class<?> type) {
        List<Field> result = new ArrayList<>();
        for (Class<?> current = type; current != null && current != Object.class; current = current.getSuperclass()) {
            for (Field field : current.getDeclaredFields()) {
                int modifiers = field.getModifiers();
                if (Modifier.isStatic(modifiers) || Modifier.isFinal(modifiers) || field.isSynthetic()) continue;
                makeAccessible(field);
                result.add(0, field);
            }
        }
        return result.toArray(new Field[0]);
    }

    private static Map<String, Field> fieldsByName(Class<?> type) {
        return FIELDS_BY_NAME.computeIfAbsent(type, ignored -> {
            Map<String, Field> fields = new HashMap<>();
            for (Field field : fieldsOf(type)) fields.put(field.getName(), field);
            return fields;
        });
    }

    private static Constructor<?> constructorFor(Class<?> type) {
        return CONSTRUCTORS.computeIfAbsent(type, BeanMapper::findConstructor);
    }

    private static Constructor<?> findConstructor(Class<?> type) {
        try {
            Constructor<?> constructor = type.getDeclaredConstructor();
            makeAccessible(constructor);
            return constructor;
        } catch (ReflectiveOperationException e) {
            throw new InvalidParameterException("对象转换异常，目标对象需要无参构造函数: " + type.getName());
        }
    }

    private static Method findSetter(Class<?> type, Field field) {
        String name = field.getName();
        try {
            return type.getMethod("set" + Character.toUpperCase(name.charAt(0)) + name.substring(1), field.getType());
        } catch (NoSuchMethodException ignored) {
            return null;
        }
    }


    private static Object readField(Field field, Object source) {
        try { return field.get(source); } catch (IllegalAccessException e) { throw conversionFailure(e); }
    }

    private static void writeField(Field field, Object target, Object value) {
        try { field.set(target, value); } catch (IllegalAccessException e) { throw conversionFailure(e); }
    }

    private static void makeAccessible(java.lang.reflect.AccessibleObject object) {
        if (!object.trySetAccessible()) throw new InvalidParameterException("对象转换异常，成员不可访问: " + object);
    }

    private static Object convertValue(Object value, Class<?> targetType, Class<?> listElementType) {
        if (value == null) return null;
        if (listElementType != null && value instanceof Collection) return map((Collection<?>) value, listElementType);
        if (targetType.isInstance(value) || (targetType.isPrimitive() && primitiveWrapper(targetType) == value.getClass())) return value;
        return map(value, targetType);
    }

    private static boolean isSimpleType(Class<?> type) { return SIMPLE_TYPES.contains(type); }
    private static boolean isNumericType(Class<?> type) { return type == BigDecimal.class || type == BigInteger.class; }
    private static boolean isDateType(Class<?> type) { return DATE_TYPES.contains(type); }

    @SuppressWarnings("unchecked")
    private static <T> T convertSimple(Object value, Class<T> type) {
        if (type == String.class) return (T) String.valueOf(value);
        if (type == char.class || type == Character.class) return (T) Character.valueOf(String.valueOf(value).charAt(0));
        if (type == byte.class || type == Byte.class) return (T) Byte.valueOf(String.valueOf(value));
        if (type == short.class || type == Short.class) return (T) Short.valueOf(String.valueOf(value));
        if (type == int.class || type == Integer.class) return (T) Integer.valueOf(String.valueOf(value));
        if (type == long.class || type == Long.class) return (T) Long.valueOf(String.valueOf(value));
        if (type == float.class || type == Float.class) return (T) Float.valueOf(String.valueOf(value));
        if (type == double.class || type == Double.class) return (T) Double.valueOf(String.valueOf(value));
        if (type == boolean.class || type == Boolean.class) return (T) Boolean.valueOf(String.valueOf(value));
        throw new InvalidParameterException("不支持的基础类型: " + type.getName());
    }

    private static Object convertNumber(Object value, Class<?> type) {
        String text = String.valueOf(value);
        return type == BigInteger.class ? new BigInteger(text) : new BigDecimal(text);
    }

    private static Object convertDate(Object value, Class<?> targetType) {
        if (targetType.isInstance(value)) return value;
        if (targetType == YearMonth.class) return YearMonth.parse(String.valueOf(value), DateTimeFormatter.ofPattern("yyyy-MM"));
        if (targetType == Year.class) return Year.parse(String.valueOf(value));
        if (targetType == Month.class) return Month.valueOf(String.valueOf(value).toUpperCase());
        if (targetType == MonthDay.class) return MonthDay.parse(String.valueOf(value));
        Instant instant = toInstant(value);
        ZoneId zone = ZoneId.systemDefault();
        if (targetType == Instant.class) return instant;
        if (targetType == Date.class) return Date.from(instant);
        if (targetType == java.sql.Timestamp.class) return java.sql.Timestamp.from(instant);
        if (targetType == java.sql.Date.class) return java.sql.Date.valueOf(instant.atZone(zone).toLocalDate());
        if (targetType == java.sql.Time.class) return java.sql.Time.valueOf(instant.atZone(zone).toLocalTime());
        if (targetType == LocalDate.class) return instant.atZone(zone).toLocalDate();
        if (targetType == LocalTime.class) return instant.atZone(zone).toLocalTime();
        if (targetType == LocalDateTime.class) return instant.atZone(zone).toLocalDateTime();
        throw new InvalidParameterException("不支持的日期类型: " + targetType.getName());
    }

    private static Instant toInstant(Object value) {
        ZoneId zone = ZoneId.systemDefault();
        if (value instanceof Instant) return (Instant) value;
        if (value instanceof Date) return ((Date) value).toInstant();
        if (value instanceof LocalDateTime) return ((LocalDateTime) value).atZone(zone).toInstant();
        if (value instanceof LocalDate) return ((LocalDate) value).atStartOfDay(zone).toInstant();
        if (value instanceof LocalTime) return ((LocalTime) value).atDate(LocalDate.of(1970, 1, 1)).atZone(zone).toInstant();
        String text = String.valueOf(value);
        if (text.length() >= 19 && (text.charAt(10) == ' ' || text.charAt(10) == 'T')) {
            try {
                return LocalDateTime.parse(text.replace(' ', 'T'), DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                        .atZone(zone)
                        .toInstant();
            } catch (java.time.format.DateTimeParseException ignored) { }
        }
        for (String pattern : DATE_PATTERNS) {
            if (pattern.replace("'", "").length() != text.length()) {
                continue;
            }
            try { return DATE_FORMATS.get().get(pattern).parse(text).toInstant(); }
            catch (ParseException ignored) { }
        }
        throw new InvalidParameterException("对象转换失败，不支持的日期值: " + text);
    }

    private static String dateToString(Object value) {
        ZoneId zone = ZoneId.systemDefault();
        if (value instanceof Date) return DEFAULT_DATE_TIME.format(((Date) value).toInstant().atZone(zone));
        if (value instanceof LocalDateTime) return DEFAULT_DATE_TIME.format((LocalDateTime) value);
        if (value instanceof LocalDate) return value.toString();
        if (value instanceof LocalTime) return DateTimeFormatter.ofPattern("HH:mm:ss").format((LocalTime) value);
        if (value instanceof Instant) return DEFAULT_DATE_TIME.format(((Instant) value).atZone(zone));
        return null;
    }

    private static Map<String, SimpleDateFormat> newDateFormats() {
        Map<String, SimpleDateFormat> formats = new LinkedHashMap<>();
        for (String pattern : DATE_PATTERNS) {
            SimpleDateFormat format = new SimpleDateFormat(pattern);
            format.setLenient(false);
            formats.put(pattern, format);
        }
        return formats;
    }

    @SuppressWarnings("unchecked")
    private static <T> T deepClone(T source) {
        if (source == null || isSimpleType(source.getClass()) || isNumericType(source.getClass())
                || isDateType(source.getClass()) || source.getClass().isEnum()) return source;
        Class<?> type = source.getClass();
        if (type.isArray()) {
            int length = Array.getLength(source);
            Object result = Array.newInstance(type.getComponentType(), length);
            for (int index = 0; index < length; index++) Array.set(result, index, deepClone(Array.get(source, index)));
            return (T) result;
        }
        if (source instanceof Collection) {
            Collection<Object> result = new ArrayList<>(((Collection<?>) source).size());
            for (Object item : (Collection<?>) source) result.add(deepClone(item));
            return (T) result;
        }
        if (source instanceof Map) {
            Map<Object, Object> result = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : ((Map<?, ?>) source).entrySet()) result.put(deepClone(entry.getKey()), deepClone(entry.getValue()));
            return (T) result;
        }
        Object result = newInstance(type);
        for (Field field : fieldsOf(type)) writeField(field, result, deepClone(readField(field, source)));
        return (T) result;
    }

    @SuppressWarnings("unchecked")
    private static <T> T newInstance(Class<T> type) {
        try {
            return (T) constructorFor(type).newInstance();
        } catch (ReflectiveOperationException e) {
            throw conversionFailure(e);
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> instantiateMap(Class<?> type, int expectedSize) {
        if (type.isInterface() || Modifier.isAbstract(type.getModifiers())) return new LinkedHashMap<>(capacity(expectedSize));
        return (Map<String, Object>) newInstance(type);
    }

    private static int capacity(int size) { return Math.max(16, size * 4 / 3 + 1); }

    private static Map<String, Object> arrayToMap(Object[] values) {
        if (values.length % 2 != 0) throw new InvalidParameterException("参数需成对存在: " + Arrays.toString(values));
        Map<String, Object> result = new LinkedHashMap<>(capacity(values.length / 2));
        for (int index = 0; index < values.length; index += 2) {
            if (values[index] == null) throw new InvalidParameterException("属性名不能为空: " + Arrays.toString(values));
            result.put(String.valueOf(values[index]), values[index + 1]);
        }
        return result;
    }

    private static Class<?> primitiveWrapper(Class<?> type) {
        if (type == boolean.class) return Boolean.class;
        if (type == byte.class) return Byte.class;
        if (type == char.class) return Character.class;
        if (type == short.class) return Short.class;
        if (type == int.class) return Integer.class;
        if (type == long.class) return Long.class;
        if (type == float.class) return Float.class;
        if (type == double.class) return Double.class;
        return type;
    }

    private static InvalidParameterException conversionFailure(Throwable cause) {
        return new InvalidParameterException("对象转换异常: " + cause.getMessage());
    }

    private enum CopyMode { ALL, NON_NULL, FILL_NULLS }
    private record MapperKey(Class<?> sourceType, Class<?> targetType) { }
    private record GeneratedProperty(Method getter, Method setter) { }

    private static final class GeneratedClassLoader extends ClassLoader {
        private GeneratedClassLoader(ClassLoader parent) {
            super(parent);
        }

        private synchronized Class<?> define(byte[] bytecode) {
            return defineClass(null, bytecode, 0, bytecode.length);
        }
    }

    private static final class MapperPlan {
        private final GeneratedMapper generatedMapper;
        private final Constructor<?> constructor;
        private final FieldBinding[] bindings;
        private MapperPlan(GeneratedMapper generatedMapper, Constructor<?> constructor, FieldBinding[] bindings) {
            this.generatedMapper = generatedMapper;
            this.constructor = constructor;
            this.bindings = bindings;
        }
        private Object map(Object source) {
            if (generatedMapper != null) {
                return generatedMapper.map(source);
            }
            Object target;
            try {
                target = constructor.newInstance();
            } catch (ReflectiveOperationException e) {
                throw conversionFailure(e);
            }
            for (FieldBinding binding : bindings) {
                Object value = binding.read(source);
                if (value != null || !binding.targetType.isPrimitive()) binding.write(target, binding.convert(value));
            }
            return target;
        }
    }

    private static final class FieldBinding {
        private final Field sourceField;
        private final Field targetField;
        private final Method targetSetter;
        private final Class<?> targetType;
        private final Class<?> listElementType;
        private FieldBinding(Field sourceField, Field targetField, Method targetSetter,
                             Class<?> targetType, Class<?> listElementType) {
            this.sourceField = sourceField;
            this.targetField = targetField;
            this.targetSetter = targetSetter;
            this.targetType = targetType;
            this.listElementType = listElementType;
        }
        private Object read(Object source) {
            return sourceField == null ? ((Map<?, ?>) source).get(targetField.getName()) : readField(sourceField, source);
        }
        private Object readTarget(Object target) { return readField(targetField, target); }
        private void write(Object target, Object value) {
            try {
                if (targetSetter != null) {
                    targetSetter.invoke(target, value);
                } else {
                    targetField.set(target, value);
                }
            } catch (ReflectiveOperationException e) {
                throw conversionFailure(e);
            }
        }
        private Object convert(Object value) {
            if (value == null) return null;
            if (listElementType != null && value instanceof Collection) return BeanMapper.map((Collection<?>) value, listElementType);
            if (targetType.isInstance(value) || (targetType.isPrimitive() && primitiveWrapper(targetType) == value.getClass())) return value;
            return BeanMapper.map(value, targetType);
        }
    }
}
